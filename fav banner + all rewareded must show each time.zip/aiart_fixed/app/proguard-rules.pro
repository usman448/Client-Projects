# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
-keepclassmembers class fqcn.of.javascript.interface.for.webview {
   public *;
}

# Uncomment this to preserve the line number information for
# debugging stack traces.
-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
-renamesourcefileattribute SourceFile


# With R8 full mode generic signatures are stripped for classes that are not
# kept. Suspend functions are wrapped in continuations where the type argument
# is used.
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation

## R8 full mode strips generic signatures from return types if not kept.
-if interface * { @retrofit2.http.* public *** *(...); }
-keep,allowoptimization,allowshrinking,allowobfuscation class <3>
#
## With R8 full mode generic signatures are stripped for classes that are not kept.
-keep,allowobfuscation,allowshrinking class retrofit2.Response

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn android.media.LoudnessCodecController$OnLoudnessCodecUpdateListener
-dontwarn android.media.LoudnessCodecController


# Keep the Billing Client classes
-keep class com.android.billingclient.** { *; }

# Do not warn for these classes
-dontwarn com.android.billingclient.**

# keep everything in this package from being removed or renamed
-keep class com.android.billingclient.api.** { *; }

# keep everything in this package from being renamed only
-keepnames class com.android.billingclient.api.** { *; }

-keep class com.google.android.gms.internal.consent_sdk.** { <fields>; }
-keepattributes *Annotation*
-keepattributes Signature


# AdMob Ads
-dontwarn com.google.android.gms.**
-keep class com.google.android.gms.** { *; }
-keep class com.google.firebase.** { *; }

-keepclassmembers class com.google.android.gms.** {
    public static *;
}
-keep public class com.google.ads.** {
    public *;
}
-keep public class com.google.android.gms.ads.** {
    public *;
}
-keep class com.ironsource.mediationsdk.** {
    *;
}
-keep class com.ironsource.adapters.** {
    *;
}
-keep class com.google.ads.mediation.ironsource.** {
    *;
}
-keep class com.google.ads.mediation.admob.AdMobAdapter {
    *;
}
-keep class com.google.ads.mediation.AdUrlAdapter {
    *;
}
# pangle
-keep class com.bytedance.sdk.** { *; }
-keep class com.pgl.sys.ces.* {*;}

#vungle
-keep class com.vungle.** {*;}
-keep interface com.vungle.** {*;}

# Applovin
-keep class com.applovin.** { *; }
-keep interface com.applovin.** { *; }

# Mintegral
-keep class com.mbridge.msdk.** {*;}

# facebook
-keep class com.facebook.* {*;}
-keep interface com.facebook.* {*;}