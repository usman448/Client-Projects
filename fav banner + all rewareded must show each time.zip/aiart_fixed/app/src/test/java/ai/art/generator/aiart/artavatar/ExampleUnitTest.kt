package ai.art.generator.aiart.artavatar

import org.junit.Test

import org.junit.Assert.*
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
        val twelveHourTime = "12:12:05 PM"
        val twentyFourHourTime = convertTo24HourFormat(twelveHourTime)
        //println("24-hour format: $twentyFourHourTime")

        removeElement(intArrayOf(3,2,2,3),3)
    }

    private fun convertTo24HourFormat(time: String): String {
        val inputFormat = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault())
        val outputFormat = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.getDefault())
        val parsedTime = LocalTime.parse(time, inputFormat)
        return outputFormat.format(parsedTime)
    }

    private fun removeElement(nums: IntArray, removeNumber: Int): Int {
        val totalSize = nums.size
        val newNumbers = nums.filter { it != removeNumber }.toIntArray()
        /*val newList = IntArray(totalSize)
        for(i  in newNumbers.indices){
            newList[i] = newNumbers[i]
        }
        for(i in 0 until (totalSize - newNumbers.size)){
            newList[newNumbers.size+i] = 0
            println("Print Index Value ${2+i}")
            println(newList[2+i])
        }
        println(newNumbers.size)
        for(i in newList.indices){
            println(newList[i])
        }*/
        for(i in newNumbers.indices){
            println(newNumbers[i])
        }
        return newNumbers.size
    }
}