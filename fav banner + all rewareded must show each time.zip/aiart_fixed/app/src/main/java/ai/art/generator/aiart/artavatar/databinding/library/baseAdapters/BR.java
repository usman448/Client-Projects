package ai.art.generator.aiart.artavatar.databinding.library.baseAdapters;

public class BR {
  public static final int _all = 0;

  public static final int viewModel = 1;
}
