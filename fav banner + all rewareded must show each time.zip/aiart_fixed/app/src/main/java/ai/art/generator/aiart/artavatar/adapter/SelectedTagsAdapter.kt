package ai.art.generator.aiart.artavatar.adapter

import ai.art.generator.aiart.artavatar.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class ItemSelectedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val itemName: TextView = itemView.findViewById(R.id.itemName)
    val tagRemoveImg: ImageView = itemView.findViewById(R.id.tagRemoveImg)
}

class SelectedTagsAdapter(var items: ArrayList<String> = ArrayList()) : RecyclerView.Adapter<ItemSelectedViewHolder>() {

    var onRemoveItemClick: ((String) -> Unit)? = null
    var listEmptyCheck: (() -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemSelectedViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.selected_tag_item_layout, parent, false)
        return ItemSelectedViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemSelectedViewHolder, position: Int) {
        val currentItem = items[position]

        // Set item name
        holder.itemName.text = currentItem

        // Set click listener to handle item selection
        holder.tagRemoveImg.setOnClickListener {
            removeItem(currentItem)
            onRemoveItemClick?.invoke(currentItem)
        }

    }

    override fun getItemCount(): Int {
        return items.size
    }


    fun setData(items: ArrayList<String>) {
        this.items = ArrayList()
        this.items = items
        notifyDataSetChanged()
    }

    fun addItem(item: String) {
        items = items.apply { add(item) }
        notifyDataSetChanged()
    }

    fun clearAllSelection() {
        items = ArrayList()
        listEmptyCheck?.invoke()
        notifyDataSetChanged()
    }

    fun removeItem(item: String) {
        items = items.apply { remove(item) }
        if (items.isEmpty()) listEmptyCheck?.invoke()
        notifyDataSetChanged()

    }
}
