package ai.art.generator.aiart.artavatar.adapter

import ai.art.generator.aiart.artavatar.R
import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

@SuppressLint("NotifyDataSetChanged")
class TagSelectionAdapter(private var items: Array<String>) : RecyclerView.Adapter<TagSelectionAdapter.ItemViewHolder>() {

    val selectedItems = HashSet<String>()
    var onItemClock: ((String, Boolean) -> Unit)? = null

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemName: TextView = itemView.findViewById(R.id.itemName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.tag_item_layout, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val currentItem = items[position]

        // Set item name
        holder.itemName.text = currentItem

        // Highlight the item if it is selected
        if (selectedItems.contains(currentItem)) {
            setItemSelectedState(holder)
        } else {
            setItemUnselectedState(holder)
        }

        // Set click listener to handle item selection
        holder.itemView.setOnClickListener {
            toggleSelection(currentItem)
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    // Method to toggle the selection state of an item
    private fun toggleSelection(item: String) {
        if (selectedItems.contains(item)) {
            selectedItems.remove(item)
            onItemClock?.invoke(item, true)
        } else {
            onItemClock?.invoke(item, false)
            selectedItems.add(item)
        }
    }

    // Method to set the selected state of an item
    private fun setItemSelectedState(holder: ItemViewHolder) {
        holder.itemView.background = ContextCompat.getDrawable(holder.itemView.context, R.drawable.border_tags)
        holder.itemName.setTextColor(ContextCompat.getColor(holder.itemName.context, R.color.black))
    }

    // Method to set the unselected state of an item
    private fun setItemUnselectedState(holder: ItemViewHolder) {
        holder.itemView.background = ContextCompat.getDrawable(holder.itemView.context, R.drawable.un_select_border_tags)
        holder.itemName.setTextColor(ContextCompat.getColor(holder.itemName.context, R.color.tagTextColor))
    }

    fun unSelected(item: String) {
        if (selectedItems.contains(item)) {
            selectedItems.remove(item)
            notifyDataSetChanged()
        }
    }

    // Method to get the list of selected items
    fun getSelectedItems(): List<String> {
        return items.filter { selectedItems.contains(it) }
    }

    fun clearAllSelection() {
        selectedItems.clear()
        notifyDataSetChanged()
    }

    fun setData(tagsList: Array<String>) {
        this.items = tagsList
        Log.d("TAG", "TagsList:ListAdAdapter ${items.size}")
        notifyDataSetChanged()
    }
}

