package ai.art.generator.aiart.artavatar.model

import android.content.Context
import java.util.Locale

object SharedPreferenceHelper {
    private const val PREF_FIRST_TIME = "first_time"

    fun isFirstTimeLaunch(context: Context): Boolean {
        val prefs = context.getSharedPreferences("SPLASH_FLAG", Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_FIRST_TIME, true)
    }

    fun setFirstTimeLaunch(context: Context, isFirstTime: Boolean) {
        val prefs = context.getSharedPreferences("SPLASH_FLAG", Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_FIRST_TIME, isFirstTime).apply()
    }


    private const val RATING_DONE = "rating_done"

    fun isRatingDone(context: Context): Boolean {
        val prefs = context.getSharedPreferences("RATING_FLAG", Context.MODE_PRIVATE)
        return prefs.getBoolean(RATING_DONE, false)
    }

    fun setIsRatingDone(context: Context, isDone: Boolean) {
        val prefs = context.getSharedPreferences("RATING_FLAG", Context.MODE_PRIVATE)
        prefs.edit().putBoolean(RATING_DONE, isDone).apply()
    }

    private const val APP_LANGUAGE = "app_language"


    fun setAppLanguage(context: Context, language: String) {
        val prefs = context.getSharedPreferences("RATING_FLAG", Context.MODE_PRIVATE)
        prefs.edit().putString(APP_LANGUAGE, language).apply()
    }

    fun getAppLanguage(context: Context): String? {
        val prefs = context.getSharedPreferences("RATING_FLAG", Context.MODE_PRIVATE)
        return prefs.getString(APP_LANGUAGE, Locale.getDefault().language)
    }
}
