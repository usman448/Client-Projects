package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentLoaderBottomBinding
import ai.art.generator.aiart.artavatar.viewmodel.LoaderViewModel
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Shader.TileMode
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.hm.admanagerx.isPremium
class LoaderBottomFragment : DialogFragment() {
    private lateinit var binding: FragmentLoaderBottomBinding
    private val viewModel: LoaderViewModel by activityViewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var progress = 0

    override fun onStart() {
        super.onStart()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog?.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        lp.gravity = Gravity.CENTER_VERTICAL
        dialog?.window!!.attributes = lp
        dialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.WHITE))
        dialog?.window?.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val main = LinearLayout(activity)
        main.orientation = LinearLayout.VERTICAL
        return super.onCreateDialog(savedInstanceState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentLoaderBottomBinding.inflate(inflater, container, false)
        observer()
        updateProgress()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val configuration = resources.configuration
        val isDarkTheme = configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        if (isDarkTheme) {
            // Perform actions for dark theme
            binding.animationView.setAnimation(R.raw.loading_animation)
            binding.animationView.speed = 4F
        } else {
            // Perform actions for light theme
            binding.animationView.setAnimation(R.raw.light_loading_animation)
            binding.animationView.speed = 3F
        }

        binding.tryNowButton.setOnClickListener {
            requireActivity().startActivity(Intent(requireActivity(), PremiumActivity::class.java))
        }
    }

    private fun observer(){
        viewModel.dismissLoader.observe(viewLifecycleOwner){
            if(progress >= 100)
                this.dismiss()
        }
    }

    private fun getGradientText(text: String): Spannable {
        val spannable = SpannableString(text)

        // Set Try text color to white
        spannable.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(requireContext(), R.color.black)),
            0, 3, // Start and end indexes of "Try"
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        // Apply gradient to the rest of the text
        val gradientColors = intArrayOf(
            ContextCompat.getColor(requireContext(), R.color.gradient1),
            ContextCompat.getColor(requireContext(), R.color.gradient2),
            ContextCompat.getColor(requireContext(), R.color.gradient3)
        )

        val paint: TextPaint = binding.tryFastTextview.paint
        val width = paint.measureText("Try Fast Processing")

        val textShader: Shader = LinearGradient(
            0f, 0f, width, binding.tryFastTextview.textSize, gradientColors, null, TileMode.CLAMP
        )

        spannable.setSpan(
            object : CharacterStyle() {
                override fun updateDrawState(ds: TextPaint) {
                    ds.shader = textShader
                }
            },
            4, text.length, // Start and end indexes after "Try "
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        return spannable
    }

    fun setProgressComplete() {
        binding.progressBar.progress = 100
        progress = 100
    }

    private fun updateProgress() {
        progress += 4

        // Ensure the progress does not exceed the maximum value
        if (progress > binding.progressBar.max) {
            progress = binding.progressBar.max
        }

        //binding.progressBar.progress = progress

        if(progress < 40) {
            binding.loaderText.text = context?.getString(R.string.analysing_input_prompt)
        } else if(progress < 80){
            binding.loaderText.text = context?.getString(R.string.generating_images)
        } else{
            binding.loaderText.text = context?.getString(R.string.adding_clarity_to_images)

        }

        if (progress < 80) {
            // Schedule the next update after 2 seconds
            handler.postDelayed({
                updateProgress()
            }, 800)
        }
        val animator = ValueAnimator.ofInt(binding.progressBar.progress, progress)
        animator.addUpdateListener { animation ->
            binding.progressBar.progress = animation.animatedValue as Int
        }
        animator.duration = 400 // Adjust duration as needed
        animator.interpolator = LinearInterpolator()
        animator.start()
    }

    override fun onResume() {
        super.onResume()
        //set gradient text color
        if(!requireActivity().isPremium()){
            binding.tryFastButtonLayout.visibility = View.VISIBLE
            binding.tryFastTextview.text = getGradientText(resources.getString(R.string.tryFastProcessing))
        }else{
            binding.tryFastButtonLayout.visibility = View.GONE
        }
    }
}