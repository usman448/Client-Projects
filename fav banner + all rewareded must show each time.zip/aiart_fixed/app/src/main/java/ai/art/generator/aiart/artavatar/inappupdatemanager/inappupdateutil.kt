package ai.art.generator.aiart.artavatar.inappupdatemanager

import android.content.Context
import android.content.IntentSender
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import ai.art.generator.aiart.artavatar.inappupdatemanager.SnackbarUtils.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.isForceUpdate
import recovermessages.restoredeleteddata.recoverdata.notifyme.inappupdatemanager.UpdateScreenEnum

object InAppUpdateUtil {

    private const val TAG = "InAppUpdateUtil"
    var appUpdateManager: AppUpdateManager? = null

    private fun getAppUpdateManager(context: Context): AppUpdateManager {
        if (appUpdateManager == null) {
            appUpdateManager = AppUpdateManagerFactory.create(context)
        }
        return appUpdateManager!!
    }

    private fun determineUpdateType(updateType: String): Int? {
        return when (updateType) {
            InAppUpdateEnum.FORCE.type, InAppUpdateEnum.IMMEDIATE.type -> AppUpdateType.IMMEDIATE
            InAppUpdateEnum.FLEXIBLE.type -> AppUpdateType.FLEXIBLE
            InAppUpdateEnum.NORMAL.type -> null
            else -> AppUpdateType.FLEXIBLE
        }
    }

    fun Context.checkForUpdate(
        view: View? = null,
        fromScreen: Int = UpdateScreenEnum.MAIN_SCREEN.value,
        updateType: String = isForceUpdate,
        activityResultLauncher: ActivityResultLauncher<IntentSenderRequest>,
        onUpdateAvailable: ((AppUpdateInfo) -> Unit)? = null,
        onUpdateNotAvailable: (() -> Unit)? = null,
        onUpdateFailed: (() -> Unit)? = null
    ) {
        //adDebugLog("checkForUpdate: Starting update check")
        appUpdateManager = getAppUpdateManager(this)
        val appUpdateInfoTask = appUpdateManager?.appUpdateInfo

        appUpdateInfoTask?.addOnSuccessListener { appUpdateInfo ->
//            adDebugLog("Update check successful")
//            adDebugLog("Update availability: ${appUpdateInfo.updateAvailability()}")
//            adDebugLog("Update priority: ${appUpdateInfo.updatePriority()}")
//            adDebugLog("Update staleness days: ${appUpdateInfo.clientVersionStalenessDays()}")
//            adDebugLog("Update available version code: ${appUpdateInfo.availableVersionCode()}")

            if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED && fromScreen == UpdateScreenEnum.MAIN_SCREEN.value) {
                // adDebugLog("Update downloaded, showing Snackbar")
                showInAppUpdateSnackbar(view)
            } else {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                    // adDebugLog("Update available")


                    val type = determineUpdateType(updateType)

                    type?.let { inAppUpdateType ->
                        try {
                            appUpdateManager?.startUpdateFlowForResult(
                                appUpdateInfo,
                                activityResultLauncher,
                                AppUpdateOptions.newBuilder(inAppUpdateType)
                                    .setAllowAssetPackDeletion(true).build()
                            )
                        } catch (e: IntentSender.SendIntentException) {
                            e.printStackTrace()
                            // adDebugLog("Error starting update flow: ${e.message}")
                            onUpdateFailed?.invoke()
                        }
                    }

                    onUpdateAvailable?.invoke(appUpdateInfo)
                } else {
                    //adDebugLog("No update available")
                    onUpdateNotAvailable?.invoke()
                }
            }
        }?.addOnCanceledListener {
            //adDebugLog("Update check canceled")
            onUpdateFailed?.invoke()
        }?.addOnFailureListener { exception ->
            // adDebugLog("Update check failed: ${exception.message}")
            onUpdateFailed?.invoke()
        }
    }

    fun Context.resumeUpdate(
        updateType: String = isForceUpdate,
        activityResultLauncher: ActivityResultLauncher<IntentSenderRequest>,
        onResumeFailed: (() -> Unit)? = null
    ) {
        appUpdateManager = getAppUpdateManager(this)
        appUpdateManager?.appUpdateInfo?.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                // adDebugLog("Resuming update")
                try {
                    val type = determineUpdateType(updateType)
                    type?.let {
                        appUpdateManager?.startUpdateFlowForResult(
                            appUpdateInfo,
                            activityResultLauncher,
                            AppUpdateOptions.newBuilder(it).setAllowAssetPackDeletion(true).build()
                        )
                    }
                } catch (e: IntentSender.SendIntentException) {
                    e.printStackTrace()
                    //  adDebugLog("Error resuming update flow: ${e.message}")
                    onResumeFailed?.invoke()
                }
            }
        }?.addOnFailureListener { exception ->
            //  adDebugLog("Error checking update info: ${exception.message}")
            onResumeFailed?.invoke()
        }
    }

    fun Context.registerUpdateListener(view: View? = null) {
        appUpdateManager = getAppUpdateManager(this)
        appUpdateManager?.registerListener { state ->
            when (state.installStatus()) {
                InstallStatus.DOWNLOADING -> {
                    // adDebugLog("UpdateListener=> DOWNLOADING")
                }

                InstallStatus.DOWNLOADED -> {
                    // adDebugLog("UpdateListener=> DOWNLOADED")
                    showInAppUpdateSnackbar(view)
                }

                InstallStatus.FAILED -> {
                    // adDebugLog("UpdateListener=> FAILED")
                }

                InstallStatus.CANCELED -> {
                    // adDebugLog("UpdateListener=> CANCELED")
                }

                InstallStatus.INSTALLING -> {
                    // adDebugLog("UpdateListener=> INSTALLING")
                }

                InstallStatus.INSTALLED -> {
                    //  adDebugLog("UpdateListener=> INSTALLED")
                }

                else -> {
                    //  adDebugLog("UpdateListener => Other status: ${state.installStatus()}")
                }
            }
        }
    }

     private fun showInAppUpdateSnackbar(view: View?) {
        try {
            view?.showSnackBar {
                getAppUpdateManager(view.context).completeUpdate()
            }
        } catch (e: Exception) {
            // adDebugLog(e.message.toString())
        }
    }

    fun unregisterUpdateListener() {
        appUpdateManager?.unregisterListener {}
    }
}


