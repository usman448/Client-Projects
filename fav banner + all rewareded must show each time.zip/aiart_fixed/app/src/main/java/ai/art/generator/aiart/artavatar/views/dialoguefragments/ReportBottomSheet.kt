package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ReportLayoutBinding
import ai.art.generator.aiart.artavatar.utilities.Helper.showToast
import ai.art.generator.aiart.artavatar.utilities.enableRateFeedButton
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.hm.admanagerx.isOnline

class ReportBottomSheet(private val reportFeedback: (String) -> Unit): BottomSheetDialogFragment() {
    private lateinit var binding: ReportLayoutBinding
    private var mContext: Context? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    override fun onStart() {
        super.onStart()
        (dialog as BottomSheetDialog).behavior.state = BottomSheetBehavior.STATE_EXPANDED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle2)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = ReportLayoutBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mContext?.let {
            binding?.let { bind ->
                bind.etReportMessage.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

                    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

                    override fun afterTextChanged(p0: Editable?) {
                        p0?.let {
                            if (it.isEmpty()) {
                                bind.tvReportBtn.enableRateFeedButton(false)
                            } else {
                                bind.tvReportBtn.enableRateFeedButton(true)
                            }
                        }
                    }

                })
                bind.tvCancelBtn.setOnClickListener {
                    dismiss()
                }
                bind.tvReportBtn.setOnClickListener {
                    if (bind.etReportMessage.text.isEmpty())
                        return@setOnClickListener

                    mContext?.let {
                        if (it.isOnline()) {
                            reportFeedback.invoke(bind.etReportMessage.text.toString())
                            dismiss()
                        } else {
                            showToast(it, getString(R.string.please_check_the_internet_connection))
                        }
                    }
                }
            }
        }
    }

}