package ai.art.generator.aiart.artavatar.utilities

import android.os.Handler
import android.os.Looper

class RapidClicker(private val threshold: Long) {

    companion object {
        private const val WHAT = 8675309
    }

    private val handler: Handler = Handler(Looper.getMainLooper())

    fun publish(runnable: Runnable) {
        if (handler.hasMessages(WHAT)) {
            return
        }
        runnable.run()
        handler.sendMessageDelayed(handler.obtainMessage(WHAT), threshold)
    }

    fun clear() {
        handler.removeCallbacksAndMessages(null)
    }

}