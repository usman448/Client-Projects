package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentShowcaseItemBottomBinding
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_IMAGE_URL
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_SELECTED_IMAGE
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_SHOWCASE_POSITION
import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import retrofit2.http.POST

class ShowcaseItemBottomFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentShowcaseItemBottomBinding
    private lateinit var imageUrl: String
    private lateinit var prompt: String
    private var position: Int? = 0
    private var mContext: Context? = null
    var onShowCaseClickListener: (() -> Unit)? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)

        arguments?.let {
            imageUrl = it.getString(ARG_IMAGE_URL).toString()
            prompt = it.getString(ARG_SELECTED_IMAGE).toString()
            position = it.getInt(ARG_SHOWCASE_POSITION)
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val context =
            mContext ?: throw IllegalStateException("mContext is null, cannot create dialog")

        return BottomSheetDialog(context, theme).apply {
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.peekHeight = context.resources.displayMetrics.heightPixels
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentShowcaseItemBottomBinding.inflate(inflater, container, false)
        updateUI()
        clickListeners()
        mContext?.sendFirebaseEvents("showcase_item_clicked_${position?.plus(1)}")
        return binding.root
    }

    private fun clickListeners() {

        binding.tryButton.setOnClickListener {
            mContext?.sendFirebaseEvents("showcase_item_try_this_btn_clicked")
            //mContext?.sendFirebaseEvents("showcase_try", Bundle())
            onShowCaseClickListener?.invoke()
            this.dismiss()
        }
    }

    private fun updateUI() {
        binding.showcaseItemShimmer.startShimmer()
        loadWithRetry(
            mContext,
            binding.imageView,
            imageUrl,
            500,
            500,
            binding.showcaseItemShimmer,
            false
        )
        binding.prompt.text = prompt
    }

    companion object {
        @JvmStatic
        fun newInstance(imageUrl: String, prompt: String, position: Int) =
            ShowcaseItemBottomFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_IMAGE_URL, imageUrl)
                    putString(ARG_SELECTED_IMAGE, prompt)
                    putInt(ARG_SHOWCASE_POSITION, position)
                }
            }
    }
}