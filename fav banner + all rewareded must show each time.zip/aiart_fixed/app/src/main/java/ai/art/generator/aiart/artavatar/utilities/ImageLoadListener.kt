package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import ai.art.generator.aiart.artavatar.viewmodel.LoaderViewModel
import com.facebook.shimmer.ShimmerFrameLayout
import java.util.logging.Handler

class ImageLoadListener(
    private val context: Context,
    private val imageView: ImageView,
    private val imageUrl: String?,
    private val height: Int,
    private val width: Int,
    private val shimmer: ShimmerFrameLayout?,
    private val isResult: Boolean,
    private val bitmap: Bitmap?
) : RequestListener<Drawable> {

    override fun onLoadFailed(
        e: GlideException?,
        model: Any?,
        target: Target<Drawable>?,
        isFirstResource: Boolean
    ): Boolean {
        if (e.toString().contains("java.net.Socket", ignoreCase = true)) {
            shimmer?.stopShimmer()
            shimmer?.hideShimmer()
            if (isResult) {
                val loaderViewModel =
                    ViewModelProvider(context as ViewModelStoreOwner)[LoaderViewModel::class.java]
                loaderViewModel.closeLoading()
            }
        } else {

                imageView.postDelayed({
                    if(bitmap != null){
                        Helper.loadBitmap(context, imageView, bitmap, shimmer)
                    }else {
                        loadWithRetry(
                            context,
                            imageView,
                            imageUrl,
                            height,
                            width,
                            shimmer,
                            isResult
                        )
                    }
                }, 2000)
        }
        return false // Return false to not display the placeholder or error image
    }

    override fun onResourceReady(
        resource: Drawable?,
        model: Any?,
        target: Target<Drawable>?,
        dataSource: DataSource?,
        isFirstResource: Boolean
    ): Boolean {
        shimmer?.stopShimmer()
        shimmer?.hideShimmer()
        if (isResult) {
            val loaderViewModel =
                ViewModelProvider(context as ViewModelStoreOwner)[LoaderViewModel::class.java]
            loaderViewModel.closeLoading()
        }
        return false
    }
}
