package ai.art.generator.aiart.artavatar.inappupdatemanager

import ai.art.generator.aiart.artavatar.R
import android.annotation.SuppressLint
import android.view.View
import com.google.android.material.snackbar.Snackbar

object SnackbarUtils {
    private var snackBar: Snackbar? = null

    @SuppressLint("RestrictedApi")
    fun View.showSnackBar(onRestart: () -> Unit) {
        try {
            snackBar = Snackbar.make(
                this,
                context.getString(R.string.new_version_ready),
                Snackbar.LENGTH_INDEFINITE
            )
            snackBar?.setAction(context.getString(R.string.install)) {
                onRestart.invoke()
                snackBar?.dismiss()
            }
            snackBar?.anchorView=this
            snackBar?.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}