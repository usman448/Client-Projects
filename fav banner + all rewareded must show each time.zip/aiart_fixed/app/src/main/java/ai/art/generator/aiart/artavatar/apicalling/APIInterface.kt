package ai.art.generator.aiart.artavatar.apicalling

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface APIInterface {

    //test end point
  //  @POST("sd_ai_x.php")
    @POST("sd_ai.php")
    suspend fun createPostX(@Body body: String): Response<String>
}