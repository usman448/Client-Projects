package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.ShowcaseAdapter
import ai.art.generator.aiart.artavatar.utilities.Helper
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TestingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_testing)

        val imageItems = Helper.showCaseList(this)
        val sublist = imageItems.subList(0, 9)
        val adapter = ShowcaseAdapter(this)
        adapter.updateItems(sublist)

        val layoutManager = GridLayoutManager(this, 2)
        adapter.setSpanSizeLookup(layoutManager)

        val recyclerView = findViewById<RecyclerView>(R.id.showcase_recyclerview)
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter
    }
}