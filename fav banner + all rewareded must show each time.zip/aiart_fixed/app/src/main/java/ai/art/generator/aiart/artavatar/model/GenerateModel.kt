package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep

@Keep
data class GenerateModel(
    var model: String = "stable-diffusion-v1-6",
    var modelName: String = "Articraft AI V3",
    var style: String = "",
    var aspectRatio: String = "1:1",
    var prompt: String? = "",
    var negative_prompt: String? = "",
    var negative_prompt_tags: String? = "",
    var cfgScale: Int = 7,
    var deNoising: String = "20",
    var hdQuality: String = "no",
    var width: String = "1024",
    var height: String = "1024",
)
