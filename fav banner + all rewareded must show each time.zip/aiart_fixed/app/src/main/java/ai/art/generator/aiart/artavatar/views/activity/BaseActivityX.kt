package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.utilities.AppX
import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity

open class BaseActivityX : AppCompatActivity() {
    var mContext: Context? = null
    override fun attachBaseContext(base: Context) {
        mContext = base
        super.attachBaseContext(AppX.localeManager?.setLocale(base))
    }

    override fun applyOverrideConfiguration(overrideConfiguration: Configuration?) {
        if (overrideConfiguration != null) {
            val uiMode = overrideConfiguration.uiMode
            overrideConfiguration.setTo(baseContext.resources.configuration)
            overrideConfiguration.uiMode = uiMode
        }
        super.applyOverrideConfiguration(overrideConfiguration)
    }
}