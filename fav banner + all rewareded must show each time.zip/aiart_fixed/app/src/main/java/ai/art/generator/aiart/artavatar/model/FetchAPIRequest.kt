package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep


@Keep
data class FetchAPIRequest(
    val key: String,
    val request_id: String
)
