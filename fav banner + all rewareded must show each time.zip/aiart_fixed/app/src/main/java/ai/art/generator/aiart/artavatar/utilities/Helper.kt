package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.model.LanguageModel
import ai.art.generator.aiart.artavatar.model.ShowcaseItem
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.StylesID
import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources
import androidx.browser.customtabs.CustomTabsIntent
import androidx.constraintlayout.helper.widget.Flow
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.analytics.FirebaseAnalytics
import com.hm.admanagerx.isPremium
import java.util.Locale

object Helper {
    fun isActivityAlive(context: Context?): Boolean {
        if (context is Activity) {
            return !context.isFinishing && !context.isDestroyed
        }
        return false
    }

    fun loadWithRetry(
        context: Context?,
        imageView: ImageView,
        imageUrl: String?,
        height: Int,
        width: Int,
        shimmer: ShimmerFrameLayout?,
        isResult: Boolean,
    ) {

        context?.let {

            //if ((it as Activity).isDestroyed || it.isFinishing) return@let
            Log.i("loadStyleImageInfo", "loadWithRetry: W:$width   H:$height")
            Glide.with(it).load(imageUrl).centerCrop()
                .apply(RequestOptions().override(width, height))
                .placeholder(R.drawable.placeholder).listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean,
                    ): Boolean {
                        Log.i("loadStyleImageInfo", "onLoadFailed: URL:$imageUrl   Error:$e")
                        //if (it.isDestroyed || it.isFinishing) return false
                        shimmer?.stopShimmer()
                        shimmer?.hideShimmer()
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (isActivityAlive(context)) {
                                Glide.with(context)
                                    .load(imageUrl)
                                    .listener(this) // Reuse the listener
                                    .into(imageView)
                            }
                        }, 0)
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean,
                    ): Boolean {
                        Log.i("loadStyleImageInfo", "onResource ready: $resource")
                        //if (it.isDestroyed || it.isFinishing) return false
                        shimmer?.stopShimmer()
                        shimmer?.hideShimmer()
                        return false
                    }

                }).into(imageView)
        }

    }

    fun loadBitmap(
        context: Context,
        imageView: ImageView,
        image: Bitmap?,
        shimmer: ShimmerFrameLayout?,
    ) {

        Glide.with(context).load(image).apply(RequestOptions().override(1024, 1024))
            .placeholder(R.drawable.black)
//            .listener(ImageLoadListener(context, imageView, null, 0, 0, shimmer, false, image))
            .into(imageView)
    }

    fun addWaterMark(context: Context?, imageUrl: String): Bitmap? {
        if (context?.isPremium() == true) {
            return Glide.with(context).asBitmap().load(imageUrl).submit().get()
        } else {

            context?.let {
                try {
                    val originalImage = Glide.with(context).asBitmap().load(imageUrl).submit().get()
                    val watermark =
                        BitmapFactory.decodeResource(context.resources, R.drawable.water_mark)
                    val desiredWidth = spToPx(context, 125.8F) // Set your desired width
                    val desiredHeight = spToPx(context, 42.7F) // Set your desired height
                    val resizedWatermark =
                        Bitmap.createScaledBitmap(watermark, desiredWidth, desiredHeight, false)

                    val watermarkedImage = Bitmap.createBitmap(
                        originalImage.width, originalImage.height, Bitmap.Config.ARGB_8888
                    )

                    val canvas = Canvas(watermarkedImage)
                    canvas.drawBitmap(originalImage, 0f, 0f, null)

                    val marginX = 20 // Set the left margin
                    val marginY = 20 // Set the top margin
                    val left = marginX.toFloat()
                    val top =
                        watermarkedImage.height - (resizedWatermark.height + marginY).toFloat()
                    canvas.drawBitmap(resizedWatermark, left, top, null)
                    Log.i(TAG, "addWaterMark: Bitmap: $watermarkedImage")
                    return watermarkedImage
                } catch (e: Exception) {
                    Log.i(TAG, "addWaterMark: Exception: ${e.message}")
                    return null
                }

            }
        }
        return null
    }

    fun getAspectRatio(width: Int, height: Int): Float {
        // Ensure height is not zero to avoid division by zero error
        if (height == 0) {
            return 1.0f // Default to 1.0 if height is zero
        }
        return width.toFloat() / height.toFloat()
    }

    fun spToPx(context: Context, sp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, sp, context.resources.displayMetrics
        ).toInt()
    }

    fun setCustomFont(context: Context, textView: TextView) {
        try {
            val typeface = ResourcesCompat.getFont(context, R.font.cadiz_medium)
            textView.typeface = typeface
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun createTags(
        context: Context, text: String, layout: ConstraintLayout, flow: Flow, drawable: Int,
    ): TextView {
        val textView = TextView(context)
        textView.text = text
        textView.background = AppCompatResources.getDrawable(context, drawable)
        textView.setPadding(
            spToPx(context, 15F), spToPx(context, 7F), spToPx(context, 15F), spToPx(context, 7F)
        )

        val textViewId = View.generateViewId()
        textView.id = textViewId

        layout.addView(textView)

        flow.addView(textView)

        return textView
    }

    fun Context.setStylePrompt(style: String): String {
        return when (style) {
            "No style" -> ""
            "Rapturous" -> getString(R.string.euphoric)
            "Dream Like" -> getString(R.string.fantasy)
            "Cyberpunk" -> getString(R.string.cyberpunk)
            "Studio Ghibli" -> getString(R.string.studio_ghibli)
            "Cartoon" -> getString(R.string.disney)
            "Comic" -> getString(R.string.gta)
            "Kawaii Chibi" -> getString(R.string.kawaii_chibi)
            "Anime" -> getString(R.string.anime_v2)
            "Color Splash" -> getString(R.string.color_splash)
            "Color Splash V2" -> getString(R.string.color_splash_v2)
            "Cosmos" -> getString(R.string.cosmos)
            "Coloring Book" -> getString(R.string.coloring_book)
            "Coloring Book v2" -> getString(R.string.coloring_book_v2)
            "Scatter" -> getString(R.string.scatter)
            "Chalk Drawing" -> getString(R.string.chalk_drawing)
            "Psychedelia" -> getString(R.string.psychedelia)
            "Extraterrestrial" -> getString(R.string.extraterrestrial)
            "Macro photography" -> getString(R.string.macro_photography)
            "Product photography" -> getString(R.string.product_photography)
            "Polaroid" -> getString(R.string.polaroid)
            "Fauvist" -> getString(R.string.fauvist)
            "Pop Art" -> getString(R.string.pop_art)
            "Pop Art V2" -> getString(R.string.pop_art_2)
            "Street Art" -> getString(R.string.street_art)
            "Bizarre" -> getString(R.string.bizarre)
            "Architectural" -> getString(R.string.architectural)
            "Cubist" -> getString(R.string.cubist)
            "Japanese" -> getString(R.string.japanese)
            "Pencil Sketch" -> getString(R.string.pencil_sketch)
            "Vector Art" -> getString(R.string.vector_art)
            "Painting" -> getString(R.string.painting)
            "Acrylic Painting" -> getString(R.string.acrylic_painting)
            "Monochrome" -> getString(R.string.monochrome)
            "Paper Art" -> getString(R.string.paper_art)
            "Glass painting" -> getString(R.string.glass_painting)
            "Sticker" -> getString(R.string.sticker)
            "Clip Art" -> getString(R.string.clip_art)
            "Goth" -> getString(R.string.goth)
            "Horror" -> getString(R.string.horror)
            "Metallic" -> getString(R.string.metallic)
            "Fire" -> getString(R.string.fire)
            "Rainbow" -> getString(R.string.rainbow)
            "Sculpture" -> getString(R.string.sculpture)
            "Clay" -> getString(R.string.clay)
            "Square Glass" -> getString(R.string.square_glass)
            "Glass Globe" -> getString(R.string.glass_globe)
            "Logo" -> getString(R.string.logo)
            "Vector Art V2" -> getString(R.string.vector_art_2)
            "Wooly" -> getString(R.string.wooly)
            "Mosaic" -> getString(R.string.mosaic)
            "3D Model" -> "3d-model"
            "Origami" -> "origami"
            "Anime" -> "anime"
            "Cinematic" -> "cinematic"
            "Comic Book" -> "comic-book"
            "Digital Art" -> "digital-art"
            "Enhance" -> "enhance"
            "Fantasy Art" -> "fantasy-art"
            "Isometric" -> "isometric"
            "Line Art" -> "line-art"
            "Low Poly" -> "low-poly"
            "Modeling Compound" -> "modeling-compound"
            "Neon Punk" -> "neon-punk"
            "Analog Film" -> "analog-film"
            "Photo Graphic" -> "photographic"
            "Pixel Art" -> "pixel-art"
            "Tile Texture" -> "tile-texture"
            else -> style
        }
    }

    fun loadStyleImage(
        context: Context?,
        imageView: ImageView,
        style: String,
        shimmer: ShimmerFrameLayout?
    ) {
        val imageUrl = "https://ai.trustedtoolsutilities.com/ai_styles/${style}.webp"
        Log.i("loadStyleImageInfo", "loadStyleImage: $style")
        loadWithRetry(context, imageView, imageUrl, 300, 300, shimmer, false)
    }

    fun styleImagesX(styleName: String): String {
        return when (styleName) {
            "No style" -> "forbidden"
            "Rapturous" -> "rapturous"
            "Dream Like" -> "dream_like"
            "Cyberpunk" -> "cyber_punk"
            "Studio Ghibli" -> "studio_ghibli"
            "Cartoon" -> "cartoon"
            "Comic" -> "comic"
            "Kawaii Chibi" -> "kawaii_chibi"
            "Anime" -> "anime"
            "Color Splash" -> "color_splash"
            "Color Splash V2" -> "vibrant"
            "Cosmos" -> "cosmic"
            "Coloring Book" -> "coloring_book"
            "Coloring Book v2" -> "coloring_book_two"
            "Scatter" -> "scatter"
            "Chalk Drawing" -> "chalk_drawing"
            "Psychedelia" -> "psychedelia"
            "Extraterrestrial" -> "extraterrestrial"
            "Macro photography" -> "macro_photography"
            "Product photography" -> "product_photography"
            "Polaroid" -> "polaroid"
            "Fauvist" -> "fauvist"
            "Pop Art" -> "pop_art"
            "Pop Art V2" -> "pop_art_two"
            "Street Art" -> "street_art"
            "Bizarre" -> "bizarre"
            "Architectural" -> "architectural"
            "Cubist" -> "cubist"
            "Japanese" -> "japanese"
            "Pencil Sketch" -> "sketch"
            "Vector Art" -> "vector_art"
            "Painting" -> "painting"
            "Acrylic Painting" -> "acrylic_painting"
            "Monochrome" -> "monochrome"
            "Paper Art" -> "paper_art"
            "Glass painting" -> "glass_art"
            "Sticker" -> "sticker"
            "Clip Art" -> "clip_art"
            "Goth" -> "goth"
            "Horror" -> "horror"
            "Metallic" -> "metallic"
            "Fire" -> "fire"
            "Rainbow" -> "rainbow"
            "Sculpture" -> "sculpture"
            "Clay" -> "clay"
            "Square Glass" -> "square_glass"
            "Glass Globe" -> "glass_globe"
            "Logo" -> "logo"
            "Vector Art V2" -> "vector_art_two"
            "Wooly" -> "wool"
            "Mosaic" -> "mosaic"
            "3D Model" -> "3d-model"
            "Origami" -> "origami"
            "Cinematic" -> "cinematic"
            "Comic Book" -> "comic-book"
            "Digital Art" -> "digital-art"
            "Enhance" -> "enhance"
            "Fantasy Art" -> "fantasy-art"
            "Isometric" -> "isometric"
            "Line Art" -> "line-art"
            "Low Poly" -> "low-poly"
            "Modeling Compound" -> "modeling-compound"
            "Neon Punk" -> "neon-punk"
            "Analog Film" -> "analog-film"
            "Photo Graphic" -> "photographic"
            "Pixel Art" -> "pixel-art"
            "Tile Texture" -> "tile-texture"
            "Articraft AI V3" -> "articraft_ai_v3"
            "Articraft AI V2" -> "articraft_ai_v2"
            "Articraft AI V1" -> "articraft_ai_v1"
            "stable-diffusion-v1-6" -> "articraft_ai_v3"
            "stable-diffusion-xl-1024-v0-9" -> "articraft_ai_v2"
            "stable-diffusion-xl-1024-v1-0" -> "articraft_ai_v1"
            "CARTOON V1" -> "cartoon_v1"
            "Realistic" -> "realistic"
            "Unreal Engine" -> "unreal_engine"
            "Anime V1" -> "anime_v1"
            "Meina Mix" -> "meina_mix"
            "Deliberate" -> "deliberate"
            "Epic Realism" -> "epic_realism"
            "Portrait" -> "portrait"
            "Disney" -> "disney"
            "NIJI CUTE" -> "niji_cute"
            else -> styleName
        }
    }

    fun showCaseList(context: Context): List<ShowcaseItem> {

        return listOf(
            //23
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "A dreamlike world where a super cute cartoon Goku baby roams, surrounded by surreal and fantastical creatures. Rendered in stunning 8k resolution by the talented Milk Winkelmann, this cinematic masterpiece will transport you to a whole new realm of cuteness.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_23.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //2
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "In the midst of the arid desert, a vibrant sports car stands out with its bold and eye-catching design, ready to conquer any terrain.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_2.webp",
                guidance_scale = 7F,
                stylePreset = "anime",
                steps = 15,
                samples = 1
            ),
            //9
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Generate a striking cell-shaded portrait inspired by Borderlands 3 concept art and the visionary styles of artists such as Josan Gonzalez, Wlop, James Jean, Victor Ngai, David Rubin, Mike Mignola, Laurie Greasley, and Artgerm. Imagine a cybernetic James Cameron character infused with post-grunge aesthetics and alien features.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_9.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //20
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Thai anime boy with man bun 90s grunge style while smiling green eyes green air force ones sneakers ripped jeans Muay Thai pose Mountain View background small floating bolders",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_20.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //50
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "A girl wearing hat hyper realistic, full body, detailed clothing, highly detailed, cinematic lighting, stunningly beautiful, intricate, sharp focus, 1. 8, 85mm, (centered image composition), (professionally color graded), ((bright soft diffused light)), volumetric fog, trending on instagram, trending on tumblr, HDR 4K, 8K",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-ffe5db23-8beb-47c4-bdac-06305e2346a8.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //5
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Steampunk Cat lying in the sun",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_5.webp",
                guidance_scale = 7F,
                stylePreset = "Comic Book",
                steps = 15,
                samples = 1
            ),
            //4
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Generate a real Face Image, portrait of a young woman with striking features. She has long, wavy brown hair, creating a playful yet serene frame for her face. The lighting in the image is soft, with a beach in the background that provides a dreamy atmosphere. Highlights in her hair catch the light, adding depth and dimension to the portrait.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_4.webp",
                guidance_scale = 7F,
                stylePreset = "Photo Graphic",
                steps = 15,
                samples = 1
            ),
            //24
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Portrait of a Beautiful Young Woman, Native American, Face, Decorated with Tattoos, Indian Jewelry, Native American Winter Clothes, Winter, Shade, Stroke, Perspective, Shadow, Contrast, Oil Painting, Composition, High Quality,",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_24.webp",
                guidance_scale = 7F,
                stylePreset = "Photo Graphic",
                steps = 15,
                samples = 1
            ),
            //47
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "dark blue night,snow queen holding the lighting candle in a small shining heart sharp bottle,red dress, beautiful face, long black hair blowing in the wind, sad,pain, tears, pray,indestructible force, highly concentration,many shining heart around with green,yellow, purple different lighting colors, blessing, love,cartoon scenes, masterpiece,mysterious east magic, stars, high quality, 8K Ultra HD, Imagine a vibrant canvas illuminated by a cascade of colorful binary code, forming the silhouette  of a captivating woman, The dynamic lines and patterns, reminiscent of a digital dance, weave together to create a harmonious fusion of technology and art, The binary code, in hues ranging from electric blues to radiant reds and vivid greens, breathes life into the woman's form, Her silhouette emerges as a synthesis of the digital and the organic, a testament to the seamless integration of technology and beauty in your masterful creation, by yukisakura, high detailed,",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_47.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //40
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Generate a real face, Real Men with tattoo modern dressed",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_40.webp",
                num_inference_steps = "20",
                stylePreset = "Photo Graphic",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //42
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Generate a real face, Design a personal for mr, i am 33 years old and Arabian muslim from Egypt I have short hair and beard",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_42.webp",
                num_inference_steps = "20",
                stylePreset = "Photo Graphic",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //6
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Cute Cat ridding a Vespa. Cartoon style. Vibrant colours. UHD.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_6.webp",
                guidance_scale = 7F,
                stylePreset = "Digital Art",
                steps = 15,
                samples = 1
            ),
            //7
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Picture an elegant beauty salon with a unique touch. The backdrop features a striking fuchsia lip-shaped chair as the centerpiece, surrounded by lush artificial cherry blossom trees. White walls create a bright and modern atmosphere, while an elegant golden lamp hangs from the ceiling, casting soft illumination in the background. Welcome to a space where beauty and elegance converge!",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_7.webp",
                guidance_scale = 7F,
                stylePreset = "enhance",
                steps = 15,
                samples = 1
            ),
            //8
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Illustration of a cyberpunk hacker in a virtual reality setting, surrounded by holographic code, futuristic UI, and virtual landscapes, Surreal Cyberpunk Art Style, Influenced by Deviantart and Ghost in the Shell anime, Camera: POV, Lens: Augmented Reality Lens, Render Style: Isometric Assets, 4K resolution, (((Cyberpunk)))",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_8.webp",
                guidance_scale = 7F,
                stylePreset = "Fantasy Art",
                steps = 15,
                samples = 1
            ),
            //3
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "The landscape is a fusion of ancient ruins straddling Angel Falls in Venezuela, (((unexplored))), the super-ancient technological civilization that flourished there, otherworldly, fantasy, and breathtaking views, insanely detailed, (((masterpiece))), best quality, 8k, ultra high res, High contrast and low saturation, (((Anatomy-based character design))), by BoochaN",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_3.webp",
                guidance_scale = 7F,
                stylePreset = "cinematic",
                steps = 15,
                samples = 1
            ),
            //10
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "Partially collapsed skyscraper post apocalypse wasteland",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_10.webp",
                guidance_scale = 7F,
                stylePreset = "Low Poly",
                steps = 15,
                samples = 1
            ),
            //11
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "In the midst of the arid desert, a vibrant sports car stands out with its bold and eye-catching design, ready to conquer any terrain.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_11.webp",
                guidance_scale = 7F,
                stylePreset = "Modeling Compound",
                steps = 15,
                samples = 1
            ),
            //12
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Experience the electrifying energy of a neon bull, brought to life in a stunning 3D render. With ultra-realistic details and a luminescent glow, this bull will transport you to a world of vibrant colors and intricate designs.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_12.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //13
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "In a world where sci-fi meets ancient Japan, a storm trooper dons a vintagepunk samurai armor. The dark grey background sets the mood as the blue and golden lighting adds a touch of beauty to the scene. The stylistic rendering, influenced by artists like Cory Loftis and Craig Mullins, brings this unique concept to life.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_13.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //14
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "a cyberpunk bedroom, isometric, unreal engine, cinematic lightening, hdr",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_14.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //15
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "A little bird. A windy day",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_15.webp",
                guidance_scale = 7F,
                stylePreset = "origami",
                steps = 15,
                samples = 1
            ),
            //16
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "Two snakes biting each other in the rainforest",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_16.webp",
                guidance_scale = 7F,
                stylePreset = "Photo Graphic",
                steps = 15,
                samples = 1
            ),
            //17
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "food burger",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_17.webp",
                guidance_scale = 7F,
                stylePreset = "Tile Texture",
                steps = 15,
                samples = 1
            ),
            //18
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "high quality, A beautifully designed leopard emerges, adorned with the vibrant hues of the electromagnetic spectrum, Its reflect the intricate patterns of electromagnetic wavelengths, showcasing a mesmerizing array of colors, From the soothing waves of radio frequencies to the visible splendor of light, and the ethereal realms of infrared and ultraviolet, the leopard embodies the entire spectrum, The interplay of these waves creates a fantastical display, as the leopard gracefully combines, HD   and blends the diverse colors of interference waves, The result is a breathtaking masterpiece, where the majestic leopard becomes a living embodiment of the electromagnetic spectrum, by yukisakura, high detailed,",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_18.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //19
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "bold neon colors, cartoon style illustration of a woman as she sees the world while experiencing hallucinations, stoned, splash art, splashed neon colors, (iridiscent glowy smoke) ((motion effects)), best quality, wallpaper art, UHD, centered image, MSchiffer art, ((flat colors)), (cel-shading style) very bold neon colors, ((high saturation)) ink lines, psychedelic environment",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_19.webp",
                guidance_scale = 7F,
                stylePreset = "Neon Punk",
                steps = 15,
                samples = 1
            ),
            //21
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Create an image of an Italian girl passionate about manga comics, Japanese cartoons, video games, travel, and fitness. The girl is blonde, with brown eyes, Mediterranean charm, and Swiss origins.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_21.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //22
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "A group of Maori warriors perform an intense and captivating haka, their powerful movements and ancestral chants filling the air with a raw energy. In this remarkable photograph, their muscular bodies are adorned with traditional tattoos, showcasing their deep connection to their Maori heritage. The image captures the warriors' fierce gazes, reflecting their unyielding determination and unwavering pride. The vivid colors and impeccable composition make this photograph a masterpiece, showcasing  the beauty and strength of Maori culture in a breathtaking manner.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_22.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //1
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Transport yourself to a world of sleek, futuristic vehicles with this stunning illustration. The white cyber vehicle stands out against the dark background, its glowing lights adding an otherworldly atmosphere. With its highly detailed rendering, it's a true masterpiece by artists like Wlop, Mars Ravela, and Greg Rutkowski",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_1.webp",
                guidance_scale = 7F,
                stylePreset = "3D Model",
                steps = 15,
                samples = 1
            ),
            //25
            ShowcaseItem(
                "stable-diffusion-xl-1024-v1-0",
                "Explore the dark and stylish world of Batman through a unique painting featuring sheer fabrics, textured details, and pencil construction lines. The elongated figure of Batman stands out against a backdrop of blue paint and glass, collaged with comic books and newsprint for a visually stunning effect.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_25.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //26
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "A menacing Venom, the iconic Marvel character known for his black suit and villainous persona, perches on a rope suspended between two intricately carved gargoyles atop a skyscraper. The image, a masterfully crafted digital painting, captures the viewer's attention with its vivid colors and breathtaking realism. Venom's muscular body is highlighted by the vibrant contrast of his jet-black suit against the city's illuminated backdrop, while his eyes gleam with a wicked intensity.The rope, seemingly at the mercy of his clenched fists, adds a sense of tension and danger to the composition. This visually stunning image brilliantly portrays the dark allure and power of Venom in a mesmerizing and captivating way.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_26.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //27
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "The rain-soaked streets of Rome are brought to life by the presence of the white marble statue of gladiator Maximus, its realistic depiction and dramatic pose adding a touch of grandeur to the old Italian square.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_27.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //28
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "From the minds of Chris Cunningham and Elsa Bleda comes a dynamic composition featuring an adorable robot figurine designed by Kidrobot and Naoto Hattori, with a luminous circuit board pattern and unusual angle that will captivate your imagination.",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_28.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //29
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "A unique and diverse alien portrait in the style of Debbie Criswell, featuring soft and muted colors for a folk art twist. Imagine a peaceful alien world, captured in stunning HDR on ArtStation",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_29.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //30
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "lovely double exposure image by blending together a stormy sea and a glass apple. The sea should serve as the underlying backdrop, with its details subtly incorporated into the glossy glass apple, sharp focus, double exposure, glossy glass apple, (translucent glass figure of an apple) (sea inside) lifeless, dead, glass apple, earthy colors, decadence, intricate design, hyper realistic, high definition, extremely detailed, dark softbox image, raytracing, cinematic, HDR, photorealistic",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_30.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //31
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "In this stunning artwork by Borovikovsky, a lone astronaut takes a moment to relax on the surface of Mars. The vibrant lighting of the scene creates a sense of warmth and tranquility, while the astronaut's full body is rendered in exquisite detail. The geometric shapes of the astronaut's suit and the surrounding landscape add a touch of modernity to this otherwise otherworldly setting. This is a truly unique and visually descriptive piece that captures the imagination",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_31.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //32
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "Create a hyper realistic image of a little boy in the middle of the night, with wizard clothes, glowing, and his wand is sparkling in the moonlight, riding a dragon in in the middle of a road, lifting weights drinking",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_32.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //33
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "extremely detailed illustration with oil paint, harmonious use of contrasting colors, tranquility, tiny flowers and vines, jasmin and cherry blossoms, beautiful woman with golden-brown hair, best resolution, best quality, prima marketing, art by Mschiffer, dynamic ink lines, romantic scrapbooking style",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_33.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //34
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "tom holland wearing iron man's iron suit",
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_34.webp",
                guidance_scale = 7F,
                stylePreset = "No style",
                steps = 15,
                samples = 1
            ),
            //above new show case with new API


            //35
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "A realistic furry cat, soft and fluffy, painted with watercolor, by David Palumbo, with a dramatic expression, pastel colors, neon lights, fantasy background, high resolution, hyper-realistic, trending on artstation.",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-2ecef32b-7b5a-4594-a774-17ca65e40dd3.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //36
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "generate a Cartoon image, Draw Lucas, a smiling boy, holding his faithful friend, Bolt, the dog, as they walk through the forest together.",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_36.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //37
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "police officer girl, wearing police hat, post apocalypse settings",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-9b499591-1f1d-41c3-a4ac-d85f24c28e91.png",
                num_inference_steps = "20",
                stylePreset = "3D Model",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //38
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "(((Chris Farley))) as (((a goblin))) from (((Baldur’s Gate 3))), he has large lower-jaw tusks, wears a hooded cloak, and is armed with a makeshift knife",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_38.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //39
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "((90's anime style)), ultra detailed illustration-robo pet, a robo dog, in megaman style, blue robo Cachorro.,(art by Masakazu Katsura)), trigun, DNA², Ranma, ultra detailed face, bold ink lines, cel shaded, art by MSchiffer, soft muted colors, lomography colors, vintage warm, dark vignette",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_39.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //41
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "a small cat baby smile his face",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_41.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //43
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "the cutest cute monster dragon with black horns on head blue eyes heart",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://ai.trustedtoolsutilities.com/ai_styles/show_case_43.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //44
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Espadachim poderoso e forte 8k com uma espada vermelha e manta preta com uma aura que emane poder e faça com que haja fogo. Quero também uma lua vermelha sangrenta de fundo e uma besta alada voando distante",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                "https://ai.trustedtoolsutilities.com/ai_styles/show_case_44.webp",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //45
            /*ShowcaseItem(
                "stable-diffusion-v1-6",
                "imagination of a beautiful wise lady in a dress made out of calligraphy paper, adult coloring book, inspired by Heinrich Lefler and Naoto Hattori and Edward Hopper and Marc Allante, epic, wet brush, pastels, pencil sketch, airbrush art ,kintsugi, fractal, complex entangled , elaborate, intricate, infinity ,hyperdetailed, colourful ,deep split-complementary colors, perfect balanced masterwork by head of prompt engineering",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-5a6fab33-9c7b-4ba8-a117-390fac3c85f1.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),*/
            //46
            ShowcaseItem(
                "stable-diffusion-v1-6",
                "Christmas wonderland with Christmas decoration",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                image = "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-dbc6ab92-77cf-43c4-b8e9-919cae15999b.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //48
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "A hut in forest with river around",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-07fb9a6c-a8dd-4ebf-aa62-e566fd7c70f3.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),
            //49
            ShowcaseItem(
                "stable-diffusion-xl-1024-v0-9",
                "disney animation, disney splash art, disney color palette, disney renaissance film, disney pixar movie still, disney art style, disney concept art :: nixri, wonderful compositions, pixar, disney concept artists, 2d character design , a girl in pink long maxi dress holding a cat , Enchanting forest path , Vibrant city skyline , Snow-covered winter wonderland",
                negative_prompt = context.getString(R.string.negative_prompt),
                width = "1024",
                height = "1024",
                "https://pub-3626123a908346a7a8be8d9295f44e26.r2.dev/generations/0-9da8aecb-b348-4561-bbd3-1b6b7503cd03.png",
                num_inference_steps = "20",
                stylePreset = "No style",
                guidance_scale = 7F,
                self_attention = "no",
            ),


            )
    }

    fun promptHints(): List<String> {

        return listOf(
            "ninja motor cycle,3d splash color with ART LOGO",
            "Ink drawing, vanishing point on white paper, seamless multiple exposure artwork that merges a volumetrically shaded silhouette of a black cat with a birch tree, intricate details, mellow and melancholic composition that conveys longing, photo, illustration, poster, conceptual art",
            "Teen girl is a Computer engineer with glasses and curly hair the background is showing, 3d render",
            "Inspired by WLOP >Treat the following Prompt Elements with equal Emphasis< Crisp and Intricate Photorealism, Taken on a Sony A7RIII | Increased Emphasis on the Feminine and Crisp Sideview Facial structure of the Woman | Foreground: A Woman, illustrated in Noir style, entangled in allure and flowers. Splashes of watercolor represent emotional turmoil | Theme: A journey from self-imprisonment to self-liberation, emphasizing the dichotomy of entrapment and freedom. , portrait photography, 3d render",
            "cute elegant with black hair and pretty witch photo inside a bubble Gaby with cute pumpkins and fluffy skulls with cute bats flying around si-fi, fashion, 3d render, anime",
            "old man sitting in a rocking chair, front porch, 3d render, photography, smoking weed, old dog with him, cinematic, typography, poster, conceptual art",
            "Inspiration character from disney pixar Cute cartoon style black guy cat with headphones, wearing blue hoodie with black jeans gray eyes and brown hair, product, cinematic, fashion, anime, 3d rendering, poster, photo, painting, illustration , typography",
            "The image depicts a plush bunny with a sad face, forgotten on a children's playground. The bunny sits forlornly on a bench, getting wet under the pouring rain , dark subdued tones, emotive scene, sad atmosphere, portrait photography, architecture, photo, 3d render",
            "a worn teddy bear view from above, sitting in the corner of a filthy abandoned concrete basement, raising his arms, dark subdued tones, emotive scene, sad atmosphere, photo, portrait photography",
            "A bewitching forest spirit, her hair flows like the leaves of the forest canopy. Her eyes glint with secrets of the woods, and she exudes an alluring aura., black and white photography, photo-realistic, shot with Rolleiflex TLR , a hyper-realistic pencil sketch, in light gray and white only, white background, grayscale, minimal shading , minimalistic ink drawing style, vanishing point on white paper, one line artwork portraying the duality within every human being, dynamic design, conceptual art",
            "Create an exquisite ink drawing on white paper that forms a perfect multiple exposure piece of art. This piece should fuse the volumetrically shadowed silhouette of a Geometric short black hair girl with a crystal front head illustration. wireframe. vector low poly line art. design black and white, poster, cinematic, photo, anime, illustration",
            "Create a compelling double exposure photograph that seamlessly merges the presence of a man and the wonders of nature. Capture the harmony between the human form and the natural world, using light and shadow to accentuate their connection and create a visually striking narrative., photo",
            "colorful sewing machine cake between bunnies with forest background",
            "drawing of uniform strokes and black lines without gradients, white background of a pretty dog",

            "A realistic furry cat, soft and fluffy, painted with watercolor, by David Palumbo, with a dramatic expression, pastel colors, neon lights, fantasy background, high resolution, hyper-realistic, trending on artstation.",
            "Photorealistic chibi art style, a beautiful woman in jeans and high heels, facing the viewers pretending to be scared, both hands on face, artistic, artist, simple volumtric light background, swirling clouds, ColorART, many cute ghosts with tongues out, chibi,",
            "police officer girl, wearing police hat, post apocalypse settings, 2D dark comic illustration, anime fantasy, fine-inking, Thick black-outlines, cel-shaded, contour, mysterious, by alphonse mucha, artgerm, Town of Salem 2, darkest dungeon, iratus:lord of the dead",
            "a fashion photoshoot of a old japanese professor from Ghost in The Shell live action anime remake, cover photo of really old wrinkly senior, fisheye",
            "iridescent white jellyfish flower bouquet in translucent crystal vase in a really dark deep sea scenery, mysterious, alcohol ink, amazing depth, intricate detailed masterwork by head of prompt engineering",
            "Cute cartoon style of a boy and girl with a smile on the front wearing a pink hoodie and a blue hoodie sitting , brown eyes and black hair, fashion, 3d rendering text, 3d render, fashion",
            "elegant round vector tshirt design, neon paint dripping sunset, black background, no mockup, illustration, conceptual art",
            "Quilling paper technique, surreal 3D portrait, a (subject matter), (image direction ), in a high-contrast, futuristic style, breathtaking landscapes with (art style), and 9setting background), (color palette includes name colors), showcasing (secondary subject), ornate shadows and dormer elements, high quality, highly detailed, sharp focus, 4K, 8K",
            "masterpiece, best quality, ultra-detailed, illustration, oinarisan, food, still life, food focus, realistic, plate, leaf",
            "A magnificent gold and silver engagement ring, high resolution, hyper-realistic, trending on artstation.",
            "imagination of a beautiful wise lady in a dress made out of calligraphy paper, adult coloring book, inspired by Heinrich Lefler and Naoto Hattori and Edward Hopper and Marc Allante, epic, wet brush, pastels, pencil sketch, airbrush art ,kintsugi, fractal, complex entangled , elaborate, intricate, infinity ,hyperdetailed, colourful ,deep split-complementary colors, perfect balanced masterwork by head of prompt engineering",
            "Christmas wonderland with Christmas decoration",
            "A hut in forest with river around",
            "disney animation, disney splash art, disney color palette, disney renaissance film, disney pixar movie still, disney art style, disney concept art :: nixri, wonderful compositions, pixar, disney concept artists, 2d character design , a girl in pink long maxi dress holding a cat , Enchanting forest path , Vibrant city skyline , Snow-covered winter wonderland",
            "A girl wearing hat hyperrealistic, full body, detailed clothing, highly detailed, cinematic lighting, stunningly beautiful, intricate, sharp focus, f\\/1. 8, 85mm, (centered image composition), (professionally color graded), ((bright soft diffused light)), volumetric fog, trending on instagram, trending on tumblr, HDR 4K, 8K",
            "Bubbles,1girl,(flowing liquid:1.3),pink background,3D cinematic film.(caricature:0.2) highly detailed,8K,HDR,UHD,masterpiece,best quality,highly detailed,wallpaper,reality ray tracing,"
        )
    }

    fun replaceEmojisWithText(inputText: String): String {
        var output = inputText
        val array = inputText.splitToCodePoints()
        for (i in array.indices) {

            val type = Character.getType(array[i].codePointAt(0))
            if (type == Character.OTHER_SYMBOL.toInt()) {

                output = output.replace(array[i], Character.getName(array[i].codePointAt(0)))
            }
        }
        return output
    }

    private fun String.splitToCodePoints(): List<String> {
        val list = mutableListOf<String>()
        var count = 0
        while (count < length) {
            with(codePointAt(count)) {
                list.add(String(Character.toChars(this)))
                count += Character.charCount(this)
            }
        }
        return list
    }

    fun openUrlInCustomTabs(context: Context, url: String) {
        try {
            val builder = CustomTabsIntent.Builder()
            val customTabsIntent = builder.build()
            customTabsIntent.launchUrl(context, Uri.parse(url))
        } catch (e: Exception) {

        }

    }

    fun Context.isNetworkAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo: NetworkInfo? = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

    fun Activity.showSnackBar(message: String, layout: View) {
        val duration = Snackbar.LENGTH_SHORT
        val snackBar = Snackbar.make(layout, message, duration)

        snackBar.setAction(getString(R.string.dismiss)) {
            snackBar.dismiss()
        }

        snackBar.show()
    }

    fun Activity.showSnackBar(message: String, layout: FrameLayout) {
        val duration = Snackbar.LENGTH_SHORT
        val snackBar = Snackbar.make(layout, message, duration)
        val snackBarView = snackBar.view
        val params = snackBarView.layoutParams as FrameLayout.LayoutParams
        params.bottomMargin = layout.height + 20
        snackBarView.layoutParams = params
        snackBar.setAction(getString(R.string.dismiss)) {
            snackBar.dismiss()
        }
        snackBar.show()
    }

    fun showToast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    fun reFormatModelID(model: String): String {
        return when (model) {
            "Articraft AI V3" -> Constants.MODEL_IDS[0]
            "Articraft AI V2" -> Constants.MODEL_IDS[1]
            "Articraft AI V1" -> Constants.MODEL_IDS[2]
            "CARTOON V1" -> Constants.MODEL_IDS[0]
            "Realistic" -> Constants.MODEL_IDS[1]
            "Unreal Engine" -> Constants.MODEL_IDS[1]
            "Anime V1" -> Constants.MODEL_IDS[0]
            "Meina Mix" -> Constants.MODEL_IDS[2]
            "Deliberate" -> Constants.MODEL_IDS[0]
            "Epic Realism" -> Constants.MODEL_IDS[0]
            "Portrait" -> Constants.MODEL_IDS[0]
            "Disney" -> Constants.MODEL_IDS[0]
            "NIJI CUTE" -> Constants.MODEL_IDS[0]
            else -> Constants.MODEL_IDS[0]
        }
    }

    fun reformattedModelName(context: Context, model: String): String {
        return when (model) {
            "stable-diffusion-v1-6" -> "Articraft AI" + " V3"
            "stable-diffusion-xl-1024-v0-9" -> "Articraft AI" + " V2"
            "stable-diffusion-xl-1024-v1-0" -> "Articraft AI" + " V1"
            else -> reformattedStyleName(model)
        }
    }

    private fun reformattedStyleName(style: String): String {
        return when (style) {
            StylesID.THREE_D_MODEL.label -> Constants.styleNameList[0]
            StylesID.ANALOG_FILM.label -> Constants.styleNameList[1]
            StylesID.ANIME.label -> Constants.styleNameList[2]
            StylesID.CINEMATIC.label -> Constants.styleNameList[3]
            StylesID.COMIC_BOOK.label -> Constants.styleNameList[4]
            StylesID.DIGITAL_ART.label -> Constants.styleNameList[5]
            StylesID.ENHANCE.label -> Constants.styleNameList[6]
            StylesID.FANTASY_ART.label -> Constants.styleNameList[7]
            StylesID.ISOMETRIC.label -> Constants.styleNameList[8]
            StylesID.LINE_ART.label -> Constants.styleNameList[9]
            StylesID.LOW_POLY.label -> Constants.styleNameList[10]
            StylesID.MODELING_COMPOUND.label -> Constants.styleNameList[11]
            StylesID.NEON_PUNK.label -> Constants.styleNameList[12]
            StylesID.ORIGAMI.label -> Constants.styleNameList[13]
            StylesID.PHOTO_GRAPHICS.label -> Constants.styleNameList[14]
            StylesID.PIXEL_ART.label -> Constants.styleNameList[15]
            StylesID.TILE_TEXTURE.label -> Constants.styleNameList[16]
            else -> style
        }
    }

    fun hideKeyboard(context: Context?) {
        val inputMethodManager =
            context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val view = (context as? MainActivity)?.currentFocus ?: View(context as? MainActivity)
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun Activity.showKeyboard() {
        val inputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val view = currentFocus ?: View(this)
        inputMethodManager.showSoftInput(view, 0)
    }

    fun Context.sendFirebaseEvents(name: String, bundle: Bundle = Bundle()) {
        Log.d(TAG, "firebaseEvents: $name && $bundle")
        FirebaseAnalytics.getInstance(this).logEvent(name, bundle)
    }

    fun getLanguagesList(): ArrayList<LanguageModel> {
        val languagesList: ArrayList<LanguageModel> = ArrayList()
        val locale: Locale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Resources.getSystem().configuration.locales.get(0)
        } else {
            Resources.getSystem().configuration.locale
        }


        languagesList.add(
            LanguageModel(
                "Default",
                Constants.defaultLanguageCode,
                Constants.defaultLanguageCode
            )
        )
        languagesList.add(LanguageModel("English", "USA", "en"))
        languagesList.add(LanguageModel("Arabic", "العربية", "ar"))
        languagesList.add(LanguageModel("Bangla", "বাংলা", "bn"))
        languagesList.add(LanguageModel("Chinese", "汉语", "zh"))
        languagesList.add(LanguageModel("French", "Français", "fr"))
        languagesList.add(LanguageModel("German", "Deutsch", "de"))
        languagesList.add(LanguageModel("Hindi", "हिंदी", "hi"))
        languagesList.add(LanguageModel("Indonesia", "Indonesian", "in"))
        languagesList.add(LanguageModel("Italian", "Italiano", "it"))
        languagesList.add(LanguageModel("Malaysian", "Melayu", "ms"))
        languagesList.add(LanguageModel("Nederland", "Dutch", "nl"))
        languagesList.add(LanguageModel("Russian", "русский", "ru"))
        languagesList.add(LanguageModel("Spanish", "Español", "es"))
        languagesList.add(LanguageModel("Turkish", "Türkçe", "tr"))
        languagesList.add(LanguageModel("Ukrainian", "Українська", "uk"))
        languagesList.add(LanguageModel("Portuguese", "Português", "pt"))
        languagesList.add(LanguageModel("Korean", "한국어", "ko"))
        languagesList.add(LanguageModel("Thai", "ไทย", "th"))
        languagesList.add(LanguageModel("Japanese", "日本語", "ja"))
        languagesList.add(LanguageModel("Vietnamese", "Tiếng Việ", "vi"))
        return languagesList
    }

    private fun getLanguageCode(lang: String): String {
        val finalFlag: String = if (lang.equals("en", ignoreCase = true)) {
            "en"
        } else if (lang.equals("ar", ignoreCase = true)) {
            "ar"
        } else if (lang.equals("bn", ignoreCase = true)) {
            "bn"
        } else if (lang.equals("zh", ignoreCase = true)) {
            "zh"
        } else if (lang.equals("fr", ignoreCase = true)) {
            "fr"
        } else if (lang.equals("de", ignoreCase = true)) {
            "de"
        } else if (lang.equals("hi", ignoreCase = true)) {
            "hi"
        } else if (lang.equals("in", ignoreCase = true)) {
            "in"
        } else if (lang.equals("it", ignoreCase = true)) {
            "it"
        } else if (lang.equals("ms", ignoreCase = true)) {
            "ms"
        } else if (lang.equals("nl", ignoreCase = true)) {
            "nl"
        } else if (lang.equals("ru", ignoreCase = true)) {
            "ru"
        } else if (lang.equals("es", ignoreCase = true)) {
            "es"
        } else if (lang.equals("tr", ignoreCase = true)) {
            "tr"
        } else if (lang.equals("uk", ignoreCase = true)) {
            "uk"
        } else if (lang.equals("pt", ignoreCase = true)) {
            "pt"
        } else if (lang.equals("ko", ignoreCase = true)) {
            "ko"
        } else if (lang.equals("th", ignoreCase = true)) {
            "th"
        } else if (lang.equals("ja", ignoreCase = true)) {
            "ja"
        } else if (lang.equals("vi", ignoreCase = true)) {
            "vi"
        } else {
            "en"
        }
        return finalFlag
    }

}