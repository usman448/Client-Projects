package ai.art.generator.aiart.artavatar.utilities


import ai.art.generator.aiart.artavatar.R
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.constraintlayout.widget.ConstraintLayout


class CustomCanvasView(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {

    private var sWidth: Int = 0
    private var sHeight: Int = 0
    private val paint = Paint()
    private var viewRect = RectF()
    var mainView: View? = null

    init {
//        paint.color = 0xC7000000.toInt() // Set your desired color for the rectangle
//        paint.style = Paint.Style.FILL
        val inflater = LayoutInflater.from(context)
        mainView = inflater.inflate(R.layout.model_tutorial_layout, this@CustomCanvasView, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
//
//        // Draw a rounded rectangle on the canvas
//        val rect = RectF(0f, 0f, sWidth.toFloat(), sHeight.toFloat()) // Adjust the coordinates and size as needed
//        val cornerRadius = 25f // Adjust the corner radius as needed
//        canvas.drawRoundRect(rect, 0f, cornerRadius, paint)
//
//        // Set PorterDuff.Mode to CLEAR to make a part of the rectangle transparent
//        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
//
//        // Define the area to be made transparent
//        val transparentRect: RectF = viewRect // Adjust the coordinates as needed
//
//        // Draw a transparent rounded rectangle to create the hole
//        canvas.drawRoundRect(transparentRect, cornerRadius, cornerRadius, paint)
//
//
//        // Reset the Xfermode to avoid affecting future drawings
//        paint.xfermode = null
    }

    fun setScrollViewSize(view: View) {
        sWidth = view.width
        sHeight = view.height
        "$sWidth x $sHeight".printIt()
    }


    fun getViewRect(view: View, parentView: ViewGroup, statusBarHeight: Int, height: Int) {
        val rect = RectF()
        val location = IntArray(2)

        // Get the screen coordinates of the View

        val offsetViewBounds = Rect()
//returns the visible bounds
//returns the visible bounds
        view.getDrawingRect(offsetViewBounds)
// calculates the relative coordinates to the parent
// calculates the relative coordinates to the parent
        parentView.offsetDescendantRectToMyCoords(view, offsetViewBounds)


        val relativeTop = offsetViewBounds.top
        val relativeLeft = offsetViewBounds.left

        view.getLocationOnScreen(location)

        // Set Rect dimensions
        rect.left = location[0].toFloat()
        rect.top = (location[1] - statusBarHeight - height).toFloat()
        rect.right = rect.left + view.width
        rect.bottom = rect.top + view.height

        viewRect = rect
        "$statusBarHeight $height ${rect.top} , ${rect.bottom} , ${rect.left} , ${rect.right}".printIt()


        mainView?.findViewById<ConstraintLayout>(R.id.main_container)?.apply {
//            x = rect.left
            y = location[1].toFloat()-statusBarHeight
        }

        invalidate()
    }


    fun showTutorials(view: View, parentView: ViewGroup, statusBarHeight: Int, height: Int) {

        val location = IntArray(2)
        view.getLocationOnScreen(location)
       mainView?.findViewById<ConstraintLayout>(R.id.main_container)?.apply {
            y = location[1].toFloat()-statusBarHeight
        }

        invalidate()
    }


}

