package ai.art.generator.aiart.artavatar.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ai.art.generator.aiart.artavatar.model.HistoryModel
import android.util.Log

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "GenArtDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "History"

        // Define column names
        private const val COLUMN_ID = "id"
        private const val COLUMN_SESSION_ID = "session_id"
        private const val COLUMN_PROMPT = "prompt"
        private const val COLUMN_IMAGE = "name"
        private const val COLUMN_TAGS = "tags"
        private const val COLUMN_STYLE = "style"
        private const val COLUMN_MODEL = "model"
        private const val COLUMN_MODEL_NAME = "model_name"
        private const val COLUMN_HEIGHT = "height"
        private const val COLUMN_WIDTH = "width"
        private const val COLUMN_NEGATIVE_PROMPT = "negative"
        private const val COLUMN_CFG = "cfg"
        private const val COLUMN_STEPS = "steps"
        private const val COLUMN_QUALITY = "quality"
        private const val COLUMN_FAVOURITE = "favourite"
        private const val COLUMN_TIME = "time"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableSQL = """
            CREATE TABLE $TABLE_NAME (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_SESSION_ID INTEGER,
                $COLUMN_PROMPT TEXT,
                $COLUMN_IMAGE TEXT,
                $COLUMN_TAGS TEXT,
                $COLUMN_STYLE TEXT,
                $COLUMN_MODEL TEXT,
                $COLUMN_MODEL_NAME TEXT,
                $COLUMN_HEIGHT TEXT,
                $COLUMN_WIDTH TEXT,
                $COLUMN_NEGATIVE_PROMPT TEXT,
                $COLUMN_CFG TEXT,
                $COLUMN_STEPS TEXT,
                $COLUMN_QUALITY TEXT,
                $COLUMN_FAVOURITE INTEGER,
                $COLUMN_TIME LONG
              
            )
        """.trimIndent()
//        $COLUMN_TIME DATETIME
        db.execSQL(createTableSQL)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Handle database schema upgrades if needed
    }

    // Insert a product into the database
    fun insertItem(item: HistoryModel) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_SESSION_ID, item.sessionId)
            put(COLUMN_PROMPT, item.prompt)
            put(COLUMN_IMAGE, item.imageUrl)
            put(COLUMN_TAGS, item.tags)
            put(COLUMN_STYLE, item.style)
            put(COLUMN_MODEL, item.model)
            put(COLUMN_MODEL_NAME, item.modelName)
            put(COLUMN_HEIGHT, item.height)
            put(COLUMN_WIDTH, item.width)
            put(COLUMN_NEGATIVE_PROMPT, item.negativePrompt)
            put(COLUMN_CFG, item.cfg)
            put(COLUMN_STEPS, item.steps)
            put(COLUMN_QUALITY, item.highQuality)
            put(COLUMN_FAVOURITE, item.favourite)
            put(COLUMN_TIME, item.time)
        }
        db.insert(TABLE_NAME, null, values)
        //db.close()
    }

    // Retrieve all items from the database
    fun getAllHistory(): List<HistoryModel> {
        val historyList = mutableListOf<HistoryModel>()
        val selectQuery = "SELECT * FROM $TABLE_NAME ORDER BY $COLUMN_TIME ASC"
        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, null)

        while (cursor.moveToNext()) {

            val columnIndex = cursor.getColumnIndex(COLUMN_ID)
            val columnSessionId = cursor.getColumnIndex(COLUMN_SESSION_ID)
            val columnPrompt = cursor.getColumnIndex(COLUMN_PROMPT)
            val columnImage = cursor.getColumnIndex(COLUMN_IMAGE)
            val columnTags = cursor.getColumnIndex(COLUMN_TAGS)
            val columnStyle = cursor.getColumnIndex(COLUMN_STYLE)
            val columnModel = cursor.getColumnIndex(COLUMN_MODEL)
            val columnModelName = cursor.getColumnIndex(COLUMN_MODEL_NAME)
            val columnHeight = cursor.getColumnIndex(COLUMN_HEIGHT)
            val columnWidth = cursor.getColumnIndex(COLUMN_WIDTH)
            val columnNegativePrompt = cursor.getColumnIndex(COLUMN_NEGATIVE_PROMPT)
            val columnCfg = cursor.getColumnIndex(COLUMN_CFG)
            val columnSteps = cursor.getColumnIndex(COLUMN_STEPS)
            val columnQuality = cursor.getColumnIndex(COLUMN_QUALITY)
            val columnFavourite = cursor.getColumnIndex(COLUMN_FAVOURITE)
            val columnTime = cursor.getColumnIndex(COLUMN_TIME)

            if (columnIndex != -1 && columnSessionId != -1 && columnPrompt != -1 && columnImage != -1 && columnTags != -1 &&
                columnStyle != -1 && columnModel != -1 && columnModelName != -1 && columnHeight != -1 && columnWidth != -1 && columnNegativePrompt != -1 &&
                columnCfg != -1 && columnSteps != -1 && columnQuality != -1 && columnFavourite != -1
                && columnTime != -1
            ) {

                val id = cursor.getInt(columnIndex)
                val sessionId = cursor.getInt(columnSessionId)
                val prompt = cursor.getString(columnPrompt)
                val imageUrl = cursor.getString(columnImage)
                val tags = cursor.getString(columnTags)
                val style = cursor.getString(columnStyle)
                val model = cursor.getString(columnModel)
                val modelName = cursor.getString(columnModelName)
                val height = cursor.getString(columnHeight)
                val width = cursor.getString(columnWidth)
                val negativePrompt = cursor.getString(columnNegativePrompt)
                val cfg = cursor.getString(columnCfg)
                val steps = cursor.getString(columnSteps)
                val highQuality = cursor.getString(columnQuality)
                val favourite = cursor.getInt(columnFavourite)
                val time = cursor.getLong(columnTime)

                historyList.add(
                    HistoryModel(
                        id,
                        sessionId,
                        prompt,
                        imageUrl,
                        tags,
                        style,
                        model,
                        modelName,
                        height,
                        width,
                        negativePrompt,
                        cfg,
                        steps,
                        highQuality,
                        favourite,
                        time
                    )
                )
            }
        }

        cursor.close()
        //db.close()
        return historyList
    }

    fun getAllHistoryWithSessionId(): List<HistoryModel> {
        val items = mutableListOf<HistoryModel>()
        val selectQuery = """
            SELECT t1.*
            FROM $TABLE_NAME t1
            INNER JOIN (
            SELECT $COLUMN_SESSION_ID, MAX($COLUMN_ID) AS max_id
            FROM $TABLE_NAME
            GROUP BY $COLUMN_SESSION_ID
        ) t2 ON t1.$COLUMN_SESSION_ID = t2.$COLUMN_SESSION_ID AND t1.$COLUMN_ID = t2.max_id
        """

        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, null)

        while (cursor.moveToNext()) {

            val columnIndex = cursor.getColumnIndex(COLUMN_ID)
            val columnSessionId = cursor.getColumnIndex(COLUMN_SESSION_ID)
            val columnPrompt = cursor.getColumnIndex(COLUMN_PROMPT)
            val columnImage = cursor.getColumnIndex(COLUMN_IMAGE)
            val columnTags = cursor.getColumnIndex(COLUMN_TAGS)
            val columnStyle = cursor.getColumnIndex(COLUMN_STYLE)
            val columnModel = cursor.getColumnIndex(COLUMN_MODEL)
            val columnModelName = cursor.getColumnIndex(COLUMN_MODEL_NAME)
            val columnHeight = cursor.getColumnIndex(COLUMN_HEIGHT)
            val columnWidth = cursor.getColumnIndex(COLUMN_WIDTH)
            val columnNegativePrompt = cursor.getColumnIndex(COLUMN_NEGATIVE_PROMPT)
            val columnCfg = cursor.getColumnIndex(COLUMN_CFG)
            val columnSteps = cursor.getColumnIndex(COLUMN_STEPS)
            val columnQuality = cursor.getColumnIndex(COLUMN_QUALITY)
            val columnFavourite = cursor.getColumnIndex(COLUMN_FAVOURITE)
            val columnTime = cursor.getColumnIndex(COLUMN_TIME)

            if (columnIndex != -1 && columnSessionId != -1 && columnPrompt != -1 && columnImage != -1 && columnTags != -1 &&
                columnStyle != -1 && columnModel != -1 && columnModelName != -1 && columnHeight != -1 && columnWidth != -1 && columnNegativePrompt != -1 &&
                columnCfg != -1 && columnSteps != -1 && columnQuality != -1 && columnFavourite != -1 && columnTime != -1
            ) {

                val id = cursor.getInt(columnIndex)
                val sessionId = cursor.getInt(columnSessionId)
                val prompt = cursor.getString(columnPrompt)
                val imageUrl = cursor.getString(columnImage)
                val tags = cursor.getString(columnTags)
                val style = cursor.getString(columnStyle)
                val model = cursor.getString(columnModel)
                val modelName = cursor.getString(columnModelName)
                val height = cursor.getString(columnHeight)
                val width = cursor.getString(columnWidth)
                val negativePrompt = cursor.getString(columnNegativePrompt)
                val cfg = cursor.getString(columnCfg)
                val steps = cursor.getString(columnSteps)
                val highQuality = cursor.getString(columnQuality)
                val favourite = cursor.getInt(columnFavourite)
                val time = cursor.getLong(columnTime)

                items.add(
                    HistoryModel(
                        id,
                        sessionId,
                        prompt,
                        imageUrl,
                        tags,
                        style,
                        model,
                        modelName,
                        height,
                        width,
                        negativePrompt,
                        cfg,
                        steps,
                        highQuality,
                        favourite,
                        time
                    )
                )
            }
        }

        cursor.close()
        //db.close()

        return items
    }

    // Update a record in the database based on column_id
    fun updateItem(item: HistoryModel): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_SESSION_ID, item.sessionId)
            put(COLUMN_PROMPT, item.prompt)
            put(COLUMN_IMAGE, item.imageUrl)
            put(COLUMN_TAGS, item.tags)
            put(COLUMN_STYLE, item.style)
            put(COLUMN_MODEL, item.model)
            put(COLUMN_MODEL_NAME, item.modelName)
            put(COLUMN_HEIGHT, item.height)
            put(COLUMN_WIDTH, item.width)
            put(COLUMN_NEGATIVE_PROMPT, item.negativePrompt)
            put(COLUMN_CFG, item.cfg)
            put(COLUMN_STEPS, item.steps)
            put(COLUMN_QUALITY, item.highQuality)
            put(COLUMN_FAVOURITE, item.favourite)
        }
        val updatedRows =
            db.update(TABLE_NAME, values, "column_id = ?", arrayOf(item.id.toString()))
        //db.close()
        return updatedRows
    }

    fun updateFavouriteStatus(itemId: Int, time: Long, isFavourite: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_FAVOURITE, isFavourite)
        values.put(COLUMN_TIME, time)

        val updatedRows =
            db.update(TABLE_NAME, values, "$COLUMN_ID = ?", arrayOf(itemId.toString()))

        //db.close()
        return updatedRows
    }

    fun getRecordById(itemId: Int): HistoryModel? {
        var historyItem: HistoryModel? = null

        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_ID = ?"
        val selectionArgs = arrayOf(itemId.toString())

        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, selectionArgs)
        if (cursor.count > 0) {
            cursor.moveToFirst()

            val columnIndex = cursor.getColumnIndex(COLUMN_ID)
            val columnSessionId = cursor.getColumnIndex(COLUMN_SESSION_ID)
            val columnPrompt = cursor.getColumnIndex(COLUMN_PROMPT)
            val columnImage = cursor.getColumnIndex(COLUMN_IMAGE)
            val columnTags = cursor.getColumnIndex(COLUMN_TAGS)
            val columnStyle = cursor.getColumnIndex(COLUMN_STYLE)
            val columnModel = cursor.getColumnIndex(COLUMN_MODEL)
            val columnModelName = cursor.getColumnIndex(COLUMN_MODEL_NAME)
            val columnHeight = cursor.getColumnIndex(COLUMN_HEIGHT)
            val columnWidth = cursor.getColumnIndex(COLUMN_WIDTH)
            val columnNegativePrompt = cursor.getColumnIndex(COLUMN_NEGATIVE_PROMPT)
            val columnCfg = cursor.getColumnIndex(COLUMN_CFG)
            val columnSteps = cursor.getColumnIndex(COLUMN_STEPS)
            val columnQuality = cursor.getColumnIndex(COLUMN_QUALITY)
            val columnFavourite = cursor.getColumnIndex(COLUMN_FAVOURITE)
            val columnTime = cursor.getColumnIndex(COLUMN_TIME)


            if (columnIndex != -1 && columnSessionId != -1 && columnPrompt != -1 && columnImage != -1 && columnTags != -1 &&
                columnStyle != -1 && columnModel != -1 && columnModelName != -1 && columnHeight != -1 && columnWidth != -1 && columnNegativePrompt != -1 &&
                columnCfg != -1 && columnSteps != -1 && columnQuality != -1 && columnFavourite != -1 && columnTime != -1
            ) {

                val id = cursor.getInt(columnIndex)
                val sessionId = cursor.getInt(columnSessionId)
                val prompt = cursor.getString(columnPrompt)
                val imageUrl = cursor.getString(columnImage)
                val tags = cursor.getString(columnTags)
                val style = cursor.getString(columnStyle)
                val model = cursor.getString(columnModel)
                val modelName = cursor.getString(columnModelName)
                val height = cursor.getString(columnHeight)
                val width = cursor.getString(columnWidth)
                val negativePrompt = cursor.getString(columnNegativePrompt)
                val cfg = cursor.getString(columnCfg)
                val steps = cursor.getString(columnSteps)
                val highQuality = cursor.getString(columnQuality)
                val favourite = cursor.getInt(columnFavourite)
                val time = cursor.getLong(columnTime)

                historyItem = HistoryModel(
                    id, sessionId, prompt, imageUrl, tags, style, model,modelName,
                    height, width, negativePrompt, cfg, steps, highQuality, favourite, time
                )

            }
        }

        cursor.close()
        //db.close()
        return historyItem
    }

    fun getRecordsBySessionId(sessionId: Int): MutableList<HistoryModel> {
        val historyList = mutableListOf<HistoryModel>()

        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_SESSION_ID = ?"
        val selectionArgs = arrayOf(sessionId.toString())

        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, selectionArgs)
        Log.i("RecordFromDb", "getRecordsBySessionId: $cursor")
        while (cursor.moveToNext()) {
            val columnIndex = cursor.getColumnIndex(COLUMN_ID)
            val columnSessionId = cursor.getColumnIndex(COLUMN_SESSION_ID)
            val columnPrompt = cursor.getColumnIndex(COLUMN_PROMPT)
            val columnImage = cursor.getColumnIndex(COLUMN_IMAGE)
            val columnTags = cursor.getColumnIndex(COLUMN_TAGS)
            val columnStyle = cursor.getColumnIndex(COLUMN_STYLE)
            val columnModel = cursor.getColumnIndex(COLUMN_MODEL)
            val columnModelName = cursor.getColumnIndex(COLUMN_MODEL_NAME)
            val columnHeight = cursor.getColumnIndex(COLUMN_HEIGHT)
            val columnWidth = cursor.getColumnIndex(COLUMN_WIDTH)
            val columnNegativePrompt = cursor.getColumnIndex(COLUMN_NEGATIVE_PROMPT)
            val columnCfg = cursor.getColumnIndex(COLUMN_CFG)
            val columnSteps = cursor.getColumnIndex(COLUMN_STEPS)
            val columnQuality = cursor.getColumnIndex(COLUMN_QUALITY)
            val columnFavourite = cursor.getColumnIndex(COLUMN_FAVOURITE)
            val columnTime = cursor.getColumnIndex(COLUMN_TIME)

            if (columnIndex != -1 && columnSessionId != -1 && columnPrompt != -1 && columnImage != -1 && columnTags != -1 &&
                columnStyle != -1 && columnModel != -1 && columnModelName != -1 && columnHeight != -1 && columnWidth != -1 && columnNegativePrompt != -1 &&
                columnCfg != -1 && columnSteps != -1 && columnQuality != -1 && columnFavourite != -1 && columnTime != -1
            ) {

                val id = cursor.getInt(columnIndex)
                val sessionId = cursor.getInt(columnSessionId)
                val prompt = cursor.getString(columnPrompt)
                val imageUrl = cursor.getString(columnImage)
                val tags = cursor.getString(columnTags)
                val style = cursor.getString(columnStyle)
                val model = cursor.getString(columnModel)
                val modelName = cursor.getString(columnModelName)
                val height = cursor.getString(columnHeight)
                val width = cursor.getString(columnWidth)
                val negativePrompt = cursor.getString(columnNegativePrompt)
                val cfg = cursor.getString(columnCfg)
                val steps = cursor.getString(columnSteps)
                val highQuality = cursor.getString(columnQuality)
                val favourite = cursor.getInt(columnFavourite)
                val time = cursor.getLong(columnTime)

                historyList.add(
                    HistoryModel(
                        id, sessionId, prompt, imageUrl, tags, style, model,modelName,
                        height, width, negativePrompt, cfg, steps, highQuality, favourite, time
                    )
                )
            }
        }

        cursor.close()
        //db.close()
        return historyList
    }

    fun getRecordIdByURL(imageUrl: String): Int {
        val db = this.readableDatabase
        val query = "SELECT $COLUMN_ID FROM $TABLE_NAME WHERE $COLUMN_IMAGE = ?"
        val selectionArgs = arrayOf(imageUrl)
        val cursor = db.rawQuery(query, selectionArgs)

        var recordId = -1
        while (cursor.moveToNext()) {

            val columnIndex = cursor.getColumnIndex(COLUMN_ID)

            if (columnIndex != -1) {

                val id = cursor.getInt(columnIndex)
                recordId = id
            }
        }

        cursor.close()
        //db.close()

        return recordId
    }

    // Delete a record from the database based on column_id
    fun deleteItemById(id: Int): Int {
        val db = this.writableDatabase
        val deletedRows = db.delete(TABLE_NAME, "$COLUMN_ID = ?", arrayOf(id.toString()))
        //db.close()
        return deletedRows
    }

    fun deleteItemBySessionId(id: Int): Int {
        val db = this.writableDatabase
        //db.close()
        return db.delete(TABLE_NAME, "$COLUMN_SESSION_ID = ?", arrayOf(id.toString()))
    }

    fun getRowCount(): Int {
        val db = this.readableDatabase
        val query = "SELECT COUNT(*) FROM $TABLE_NAME"
        val cursor = db.rawQuery(query, null)
        var count = 0

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0) // Get the count from the first column (index 0)
        }

        cursor.close()
        //db.close()

        return count
    }
}
