package ai.art.generator.aiart.artavatar.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class BottomSheetVM : ViewModel() {

    var tagsSelectionList: ArrayList<String> = ArrayList()
    var editTagsSelectionList: ArrayList<String> = ArrayList()

    private val _isPremium = MutableLiveData<Boolean>()
    val isPremium: LiveData<Boolean> = _isPremium

    fun premiumView() {
        _isPremium.postValue(true)
    }
}