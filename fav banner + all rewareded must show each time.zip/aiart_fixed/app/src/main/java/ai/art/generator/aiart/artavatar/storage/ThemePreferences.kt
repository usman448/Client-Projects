package ai.art.generator.aiart.artavatar.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class ThemePreferences(context: Context) {

    companion object{
        const val SHARED_PREF_NAME = "ArtiCraftTheme"
        const val SELECT_THEME = "SelectTheme"
    }

    private val sharedPreferences: SharedPreferences  = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)

    fun saveThemePreferences(selectTheme: Int) {
        sharedPreferences.edit {
            putInt(SELECT_THEME, selectTheme)
        }
    }

    fun getThemePreferences(): Int{
        return sharedPreferences.getInt(SELECT_THEME, 2)
    }

    fun clearStorage() = sharedPreferences.edit().clear().apply()
}