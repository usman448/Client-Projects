package ai.art.generator.aiart.artavatar.databinding;

import androidx.databinding.MergedDataBinderMapper;

public class DataBinderMapperImpl extends MergedDataBinderMapper {
  DataBinderMapperImpl() {
    addMapper(new ai.art.generator.aiart.artavatar.DataBinderMapperImpl());
  }
}
