package ai.art.generator.aiart.artavatar.utilities

object Constants {

    val MODEL_IDS = arrayOf(
        "stable-diffusion-v1-6",
        "stable-diffusion-xl-1024-v0-9",
        "stable-diffusion-xl-1024-v1-0",
        "CARTOON V1", //for cartoon model
        "Anime V1", // for anime
        "Unreal Engine", //model for cyberpunk image like
        "Realistic", //for real face image
        "Meina Mix",
        "Deliberate",
        "Epic Realism",
        "Portrait",
        "Disney",
        "NIJI CUTE",  // for ninja model like cartoon
    )

    val allModelNameList = arrayOf(
        "Articraft AI V3",
        "Articraft AI V2",
        "Articraft AI V1",
        "CARTOON V1",
        "Realistic",
        "Unreal Engine",
        "Anime V1",
        "Meina Mix",
        "Deliberate",
        "Epic Realism",
        "Portrait",
        "Disney",
        "NIJI CUTE"
    )

    val styleNameList = listOf(
        "3D Model",
        "Origami",
        "Anime",
        "Cinematic",
        "Comic Book",
        "Digital Art",
        "Enhance",
        "Fantasy Art",
        "Isometric",
        "Line Art",
        "Low Poly",
        "Modeling Compound",
        "Neon Punk",
        "Analog Film",
        "Photo Graphic",
        "Pixel Art",
        "Tile Texture",
    )

    val newStyleIdList = listOf(
        "3d-model",
        "origami",
        "anime",
        "cinematic",
        "comic-book",
        "digital-art",
        "enhance",
        "fantasy-art",
        "isometric",
        "line-art",
        "low-poly",
        "modeling-compound",
        "neon-punk",
        "analog-film",
        "photographic",
        "pixel-art",
        "tile-texture"
    )

    val STYLE_IDS = arrayOf(
        "No style",
        "3D Model",
        "Origami",
        "Anime",
        "Cinematic",
        "Comic Book",
        "Digital Art",
        "Enhance",
        "Fantasy Art",
        "Isometric",
        "Line Art",
        "Low Poly",
        "Modeling Compound",
        "Neon Punk",
        "Analog Film",
        "Photo Graphic",
        "Pixel Art",
        "Tile Texture",
        //above new style for new API
        //below style are old which pass in prompt not style_preset
        "Rapturous",
        "Dream Like",
        "Cyberpunk",
        "Studio Ghibli",
        "Cartoon",
        "Kawaii Chibi",
        "Color Splash",
        "Color Splash V2",
        "Cosmos",
        "Coloring Book",
        "Coloring Book v2",
        "Scatter",
        "Chalk Drawing",
        "Psychedelia",
        "Extraterrestrial",
        "Macro photography",
        "Product photography",
        "Polaroid",
        "Fauvist",
        "Pop Art",
        "Pop Art V2",
        "Street Art",
        "Bizarre",
        "Architectural",
        "Cubist",
        "Japanese",
        "Vector Art",
        "Painting",
        "Acrylic Painting",
        "Monochrome",
        "Paper Art",
        "Glass painting",
        "Sticker",
        "Clip Art",
        "Goth",
        "Horror",
        "Metallic",
        "Fire",
        "Rainbow",
        "Sculpture",
        "Clay",
        "Square Glass",
        "Glass Globe",
        "Logo",
        "Vector Art V2",
        "Wooly",
        "Mosaic"
    )

    val allStyleIdList = arrayOf(
        "3d-model",
        "origami",
        "anime",
        "cinematic",
        "comic-book",
        "digital-art",
        "enhance",
        "fantasy-art",
        "isometric",
        "line-art",
        "low-poly",
        "modeling-compound",
        "neon-punk",
        "analog-film",
        "photographic",
        "pixel-art",
        "tile-texture",
        "rapturous",
        "dream_like",
        "cyber_punk",
        "studio_ghibli",
        "cartoon",
        "comic",
        "kawaii_chibi",
        "color_splash",
        "vibrant",
        "cosmic",
        "coloring_book",
        "coloring_book_two",
        "scatter",
        "chalk_drawing",
        "psychedelia",
        "extraterrestrial",
        "macro_photography",
        "product_photography",
        "polaroid",
        "fauvist",
        "pop_art",
        "pop_art_two",
        "street_art",
        "bizarre",
        "architectural",
        "cubist",
        "japanese",
        "sketch",
        "vector_art",
        "painting",
        "acrylic_painting",
        "monochrome",
        "paper_art",
        "glass_art",
        "sticker",
        "clip_art",
        "goth",
        "horror",
        "metallic",
        "fire",
        "rainbow",
        "sculpture",
        "clay",
        "square_glass",
        "glass_globe",
        "logo",
        "vector_art_two",
        "wool",
        "mosaic"
    )

    val LANGUAGES = arrayOf(
        "Default",
        "English",
        "Arabic",
        "Bangla",
        "Chinese",
        "French",
        "German",
        "Hindi",
        "Indonesia",
        "Italian",
        "Malaysian",
        "Nederland",
        "Russian",
        "Spanish",
        "Turkish",
        "Ukrainian",
        "Portuguese",
        "Korean",
        "Thai",
        "Japanese",
        "Vietnamese"
    )

    var defaultLanguageCode = ""
    var defaultLanguageCountry = ""
    val LANGUAGES_CODE = arrayOf(
        defaultLanguageCode,
        "en",
        "ar",
        "bn",
        "zh",
        "fr",
        "de",
        "hi",
        "in",
        "it",
        "ms",
        "nl",
        "ru",
        "es",
        "tr",
        "uk",
        "pt",
        "ko",
        "th",
        "ja",
        "vi"
    )


    val PREMIUM_STYLES = arrayOf(
        "anime",
        "comic-book",
        "pixel-art",
        "Cyberpunk",
        "Cartoon",
        "Comic",
        "Psychedelia",
        "Macro photography",
        "Architectural",
        "Japanese",
        "Pencil Sketch",
        "Acrylic Painting",
        "Paper Art",
        "Sticker",
        "Metallic",
        "Sculpture",
        "Logo",
        "Vector Art V2",
        "Wooly"
    )

    val NEGATIVE_TAGS = arrayOf(
        "Blur Images",
        "Illustrations",
        "Painting",
        "Ugly",
        "Cartoon",
        "Out of Frame",
        "Low Quality"
    )

    var POPULAR_TAGS2 = ArrayList<String>().apply {
        add("Neon lights")
        add("Zen garden")
        add("Cute cat")
        add("Metallic")
        add("Prismatic")
        add("Cinematic")
        add("Smoky haze")
        add("Opalescent")
        add("Golden hour")
        add("Rustic barn")
        add("Tranquil pond")
        add("Tropical bird")
        add("Ancient ruins")
        add("Winter magic")
        add("Starry night")
        add("Iridescent")
        add("Earth tones")
        add("Retro vibes")
        add("Cloudy skies")
        add("Sunlit beach")
        add("Dreamy pastels")
        add("Dancing flames")
        add("Wildlife safari")
        add("Colorful market")
        add("Beautiful woman")
        add("Black and white")
        add("Flickering fire")
        add("Mystical forest")
        add("Underwater world")
        add("Colorful garden")
        add("Realistic lighting")
        add("Thunderstorm drama")
        add("Gothic cathedral")
        add("Moonlit landscape")
        add("Foggy atmosphere")
        add("Cityscape in motion")
        add("Waterfall oasis")
        add("Playful children")
        add("Autumn foliage")
        add("Coastal cliffs")
        add("Lakeside view")
        add("Vivid green meadow")
        add("Peaceful riverbank")
        add("Majestic mountains")
        add("Mysterious alley")
        add("Countryside landscape")
    }
    val POPULAR_TAGS = arrayOf(
        "Neon lights",
        "Zen garden",
        "Cute cat",
        "Metallic",
        "Prismatic",
        "Cinematic",
        "Smoky haze",
        "Opalescent",
        "Golden hour",
        "Rustic barn",
        "Tranquil pond",
        "Tropical bird",
        "Ancient ruins",
        "Winter magic",
        "Starry night",
        "Iridescent",
        "Earth tones",
        "Retro vibes",
        "Cloudy skies",
        "Sunlit beach",
        "Dreamy pastels",
        "Dancing flames",
        "Wildlife safari",
        "Colorful market",
        "Beautiful woman",
        "Black and white",
        "Flickering fire",
        "Mystical forest",
        "Underwater world",
        "Colorful garden",
        "Realistic lighting",
        "Thunderstorm drama",
        "Gothic cathedral",
        "Moonlit landscape",
        "Foggy atmosphere",
        "Cityscape in motion",
        "Waterfall oasis",
        "Playful children",
        "Autumn foliage",
        "Coastal cliffs",
        "Lakeside view",
        "Vivid green meadow",
        "Peaceful riverbank",
        "Majestic mountains",
        "Mysterious alley",
        "Countryside landscape"
    )


    var QUALITY_TAGS2 = ArrayList<String>().apply {
        add("Lifelike")
        add("Smooth")
        add("HD")
        add("VRay")
        add("HDR")
        add("Shadows")
        add("Fantasy")
        add("Magical")
        add("Ethereal")
        add("Symbolic")
        add("Full HD")
        add("Wallpaper")
        add("Mystical")
        add("Intricate")
        add("Haunting")
        add("Fine art")
        add("Interactive")
        add("Expressive")
        add("Evocative")
        add("3D modeling")
        add("Enchanting")
        add("Masterpiece")
        add("Mind bending")
        add("Color harmony")
        add("Epic fantasy")
        add("Highly detailed")
        add("Ultra detailed")
        add("Ambient occlusion")
        add("Dynamic composition")
        add("Real-time rendering")
        add("Post-processing effects")
        add("Iridescent accents")
        add("Captivating")
        add("High Quality")
        add("Dynamic lighting")
        add("Translucency")
        add("Mesmerizing")
        add("Detailed brushwork")
        add("Abstract")
        add("Hyper-realistic")
        add("Global illumination")
        add("Octane render")
        add("Conceptual")
        add("Experimental")
        add("Fluid motion")
        add("Depth of field")
        add("Cinematic light")
        add("Soft lighting")
        add("Panoramic")
    }
    val QUALITY_TAGS = arrayOf(
        "Lifelike",
        "Smooth",
        "HD",
        "VRay",
        "HDR",
        "Shadows",
        "Fantasy",
        "Magical",
        "Ethereal",
        "Symbolic",
        "Full HD",
        "Wallpaper",
        "Mystical",
        "Intricate",
        "Haunting",
        "Fine art",
        "Interactive",
        "Expressive",
        "Evocative",
        "3D modeling",
        "Enchanting",
        "Masterpiece",
        "Mind bending",
        "Color harmony",
        "Epic fantasy",
        "Highly detailed",
        "Ultra detailed",
        "Ambient occlusion",
        "Dynamic composition",
        "Real-time rendering",
        "Post-processing effects",
        "Iridescent accents",
        "Captivating",
        "High Quality",
        "Dynamic lighting",
        "Translucency",
        "Mesmerizing",
        "Detailed brushwork",
        "Abstract",
        "Hyper-realistic",
        "Global illumination",
        "Octane render",
        "Conceptual",
        "Experimental",
        "Fluid motion",
        "Depth of field",
        "Cinematic light",
        "Soft lighting",
        "Panoramic"
    )

    var STYLE_TAGS2 = ArrayList<String>().apply {
        add("Still life")
        add("Graffiti")
        add("Calligraphy")
        add("Typography")
        add("Sci-fi")
        add("AR")
        add("VR")
        add("3D")
        add("Drawing")
        add("Sketch")
        add("Cartoon")
        add("Vintage")
        add("Ceramic art")
        add("Pop art")
        add("Sculpture")
        add("Geometric")
        add("Video art")
        add("Impressionism")
        add("Botanical")
        add("Mixed media")
        add("Nature")
        add("Anime")
        add("Minimalist")
        add("Celestial")
        add("Cityscape")
        add("Dadaism")
        add("Fauvism")
        add("Bokeh")
        add("Psychedelic")
        add("Texture")
        add("Brush effect")
        add("Cyberpunk")
        add("Futuristic")
        add("Steampunk")
        add("Documentary photography")
        add("Fashion photography")
        add("Digital painting")
        add("Interactive art")
        add("Cubism")
        add("Photography")
        add("Watercolor")
        add("Surrealism")
        add("Experimental photography")
        add("Abstract expressionism")
        add("Street photography")
        add("Nature-inspired")
        add("Architecture")
        add("Motion graphics")
        add("Music inspired")
        add("Fashion inspired")
        add("Constructivism")
        add("Land art")
        add("Still photography")
        add("Macro photography")
        add("High-speed photography")
        add("Long exposure photography")
        add("B&W photography")
        add("Infrared photography")
        add("Nature photography")
        add("Wildlife photography")
        add("Concept art")
        add("Oil painting")
        add("Aesthetic")
        add("Illustration")
        add("Pointillism")
        add("Hyper-realism")
        add("Ultra-realism")
        add("Dark fantasy")
        add("Renaissance")
        add("Oriental art")
    }
    val STYLE_TAGS = arrayOf(
        "Still life",
        "Graffiti",
        "Calligraphy",
        "Typography",
        "Sci-fi",
        "AR",
        "VR",
        "3D",
        "Drawing",
        "Sketch",
        "Cartoon",
        "Vintage",
        "Ceramic art",
        "Pop art",
        "Sculpture",
        "Geometric",
        "Video art",
        "Impressionism",
        "Botanical",
        "Mixed media",
        "Nature",
        "Anime",
        "Minimalist",
        "Celestial",
        "Cityscape",
        "Dadaism",
        "Fauvism",
        "Bokeh",
        "Psychedelic",
        "Texture",
        "Brush effect",
        "Cyberpunk",
        "Futuristic",
        "Steampunk",
        "Documentary photography",
        "Fashion photography",
        "Digital painting",
        "Interactive art",
        "Cubism",
        "Photography",
        "Watercolor",
        "Surrealism",
        "Experimental photography",
        "Abstract expressionism",
        "Street photography",
        "Nature-inspired",
        "Architecture",
        "Motion graphics",
        "Music inspired",
        "Fashion inspired",
        "Constructivism",
        "Land art",
        "Still photography",
        "Macro photography",
        "High-speed photography",
        "Long exposure photography",
        "B&W photography",
        "Infrared photography",
        "Nature photography",
        "Wildlife photography",
        "Concept art",
        "Oil painting",
        "Aesthetic",
        "Illustration",
        "Pointillism",
        "Hyper-realism",
        "Ultra-realism",
        "Dark fantasy",
        "Renaissance",
        "Oriental art"
    )


    var COLORS_TAGS2 = ArrayList<String>().apply {
        add("Coral reef")
        add("Gilded gold")
        add("Lilac dreams")
        add("Coral blush")
        add("Cyan vibes")
        add("Silver mist")
        add("Smoky allure")
        add("Rustic charm")
        add("Soft gradients")
        add("Vibrant spectrum")
        add("Nacre elegance")
        add("Neon bursts")
        add("Soft pearl")
        add("Rich crimson")
        add("Magenta burst")
        add("Aquatic teal")
        add("Lilac pastel")
        add("Periwinkle bliss")
        add("Citrus burst")
        add("Turquoise dreams")
        add("Verdant forest")
        add("Amethyst glow")
        add("Azure skies")
        add("Blushing rose")
        add("Chartreuse zest")
        add("Royal purple")
        add("Deep maroon")
        add("Mustard sunshine")
        add("Orchid bloom")
        add("Peachy delight")
        add("Olive essence")
        add("Cozy warm tones")
        add("Sumptuous richness")
        add("Playfully colorful")
        add("Luxurious deep tones")
        add("Shimmering tones")
        add("Pearlescent")
        add("Harmonious variations")
        add("Bronze brilliance")
        add("Natural earthy shades")
        add("Refreshing cool tones")
        add("Matte metallic")
        add("Rainbow hues")
        add("Bold red rust")
        add("Sapphire elegance")
        add("Fluorescent zest")
        add("Glittering glam")
        add("Holographic magic")
        add("Deep indigo")
        add("Ivory lime fusion")
        add("Mauve whispers")
        add("Timeless monochrome")
    }
    val COLORS_TAGS = arrayOf(
        "Coral reef",
        "Gilded gold",
        "Lilac dreams",
        "Coral blush",
        "Cyan vibes",
        "Silver mist",
        "Smoky allure",
        "Rustic charm",
        "Soft gradients",
        "Vibrant spectrum",
        "Nacre elegance",
        "Neon bursts",
        "Soft pearl",
        "Rich crimson",
        "Magenta burst",
        "Aquatic teal",
        "Lilac pastel",
        "Periwinkle bliss",
        "Citrus burst",
        "Turquoise dreams",
        "Verdant forest",
        "Amethyst glow",
        "Azure skies",
        "Blushing rose",
        "Chartreuse zest",
        "Royal purple",
        "Deep maroon",
        "Mustard sunshine",
        "Orchid bloom",
        "Peachy delight",
        "Olive essence",
        "Cozy warm tones",
        "Sumptuous richness",
        "Playfully colorful",
        "Luxurious deep tones",
        "Shimmering tones",
        "Pearlescent",
        "Harmonious variations",
        "Bronze brilliance",
        "Natural earthy shades",
        "Refreshing cool tones",
        "Matte metallic",
        "Rainbow hues",
        "Bold red rust",
        "Sapphire elegance",
        "Fluorescent zest",
        "Glittering glam",
        "Holographic magic",
        "Deep indigo",
        "Ivory lime fusion",
        "Mauve whispers",
        "Timeless monochrome"
    )


    var MOOD_TAGS2 = ArrayList<String>().apply {
        add("Whimsy")
        add("Radiance")
        add("Awe")
        add("Zest")
        add("Surreal")
        add("Enchantment")
        add("Futurism")
        add("Captivation")
        add("Mystique")
        add("Tranquility")
        add("Mystery")
        add("Elegance")
        add("Dynamic")
        add("Serenity")
        add("Aetherial")
        add("Dreaminess")
        add("Intensity")
        add("Romance")
        add("Jubilation")
        add("Uplift")
        add("Calmness")
        add("Brooding")
        add("Playfulness")
        add("Hypnosis")
        add("Immersive")
        add("Sensual")
        add("Reflection")
        add("Wistfulness")
        add("Fanciful")
        add("Adventure")
        add("Delicacy")
        add("Ebullience")
        add("Ecstasy")
        add("Expansive")
        add("Exuberance")
        add("Impression")
        add("Jubilance")
        add("Liveliness")
        add("Thrill")
        add("Vitality")
        add("Wholesome")
    }

    val MOOD_TAGS = arrayOf(
        "Whimsy",
        "Radiance",
        "Awe",
        "Zest",
        "Surreal",
        "Enchantment",
        "Futurism",
        "Captivation",
        "Mystique",
        "Tranquility",
        "Mystery",
        "Elegance",
        "Dynamic",
        "Serenity",
        "Aetherial",
        "Dreaminess",
        "Intensity",
        "Romance",
        "Jubilation",
        "Uplift",
        "Calmness",
        "Brooding",
        "Playfulness",
        "Hypnosis",
        "Immersive",
        "Sensual",
        "Reflection",
        "Wistfulness",
        "Fanciful",
        "Adventure",
        "Delicacy",
        "Ebullience",
        "Ecstasy",
        "Expansive",
        "Exuberance",
        "Impression",
        "Jubilance",
        "Liveliness",
        "Thrill",
        "Vitality",
        "Wholesome"
    )

    const val AI_BASE_URL = "https://ai.trustedtoolsutilities.com/"

    const val API_KEY = "oR7lEXl2no8pI2oCHddKjPdxCFAJ5IqZ0r7Z9ESyyBuJrAZdsJkWMdMSit23"

    const val ARG_IS_FROM_EDIT = "is_from_edit"
    const val ARG_TAGS_STRING = "tags_string"
    const val ARG_STYLE_TYPE = "style_type"
    const val ARG_STYLE_VALUE = "style_value"
    const val ARG_STYLE_NAME = "style_name"
    const val ARG_IMAGE_URL = "image_url"
    const val ARG_SELECTED_IMAGE = "selected_image"
    const val ARG_SHOWCASE_POSITION = "showCasePosition"
    const val ARG_NEGATIVE_PROMPT = "negative_prompt"
    const val ARG_NEGATIVE_PROMPT_TAGS = "negative_prompt_tags"
    const val ARG_CFG_SCALE = "cfg_scale"
    const val ARG_DE_NOISING = "de_noising_steps"
    const val ARG_IMAGE_QUALITY = "image_quality"

    const val SHARE_APP = "https://play.google.com/store/apps/details?id="
    const val FEEDBACK = "hazelmobileapps@gmail.com"
    const val PRIVACY_POLICY = "https://toolsutilitiesapps.com/ai-art-generator-articraft/"
    const val TERMS_AND_CONDITIONS = "https://toolsutilitiesapps.com/terms-conditions/"

    // =====================================================================
    // COINS / CREDIT SYSTEM
    // =====================================================================
    //
    // HOW IT WORKS:
    // - Every time the user clicks Generate or Regenerate, their credit count goes up by 1.
    // - When the count reaches IMAGE_CREDIT_LIMIT, ads or premium screen is triggered.
    // - After watching a rewarded ad, the count resets back to 0.
    //
    // Both Generate (MainActivity) and Regenerate (ResultFragment) share
    // this same limit and state variable.
    //
    // ---------------------------------------------------------------------
    // TO CHANGE NUMBER OF FREE GENERATES:
    //   Change IMAGE_CREDIT_LIMIT below.
    //   Example: value 4 means user gets 5 free uses (0, 1, 2, 3, 4).
    //   To give 3 free uses → set to 2
    //   To give 10 free uses → set to 9
    // ---------------------------------------------------------------------
    var IMAGE_CREDIT_LIMIT = 4
    //
    // ---------------------------------------------------------------------
    // TO CHANGE NUMBER OF FREE REGENERATES (if you want it separate):
    //   Step 1: Uncomment the line below and set your desired value.
    //   Step 2: In ResultFragment.kt → find "Constants.IMAGE_CREDIT_LIMIT"
    //           inside the generateMoreBtn click handler and replace it
    //           with "Constants.REGENERATE_CREDIT_LIMIT".
    // ---------------------------------------------------------------------
    // var REGENERATE_CREDIT_LIMIT = 4
    //
    // ---------------------------------------------------------------------
    // TO CHANGE WHAT HAPPENS WHEN CREDITS ARE EXHAUSTED:
    //   Change GENERATE_IMAGE_STATE below.
    //   0 = Always allow generation (no ad, no block) — used for testing
    //   1 = Show "Watch Ad" dialog to the user
    //   2 = Send user directly to Premium screen
    //   This setting applies to both Generate and Regenerate buttons.
    // ---------------------------------------------------------------------
    var GENERATE_IMAGE_STATE = 0
    // =====================================================================

    var userMovingScreenState = ""
    var sessionID = 0
    var imageUrl = ""
    var themeChange = false
}