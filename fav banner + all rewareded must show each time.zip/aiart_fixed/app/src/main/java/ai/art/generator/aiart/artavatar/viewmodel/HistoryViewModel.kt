package ai.art.generator.aiart.artavatar.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ai.art.generator.aiart.artavatar.database.DatabaseHelper
import ai.art.generator.aiart.artavatar.model.HistoryModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HistoryViewModel : ViewModel() {

    private val _recordDeleted = MutableLiveData<Boolean>()
    val recordDeleted: LiveData<Boolean> = _recordDeleted

//    private val _favouriteUpdated = MutableLiveData<Int>()
//    val favouriteUpdated: LiveData<Int> = _favouriteUpdated

    fun getItemList(databaseHelper: DatabaseHelper): List<HistoryModel> {
        return databaseHelper.getAllHistory()
    }

    fun getHistoryItems(databaseHelper: DatabaseHelper): List<HistoryModel> {
        return databaseHelper.getAllHistoryWithSessionId()
    }

//    fun addToFavourite(itemId: Int, databaseHelper: DatabaseHelper, isFavourite: Int) {
//        databaseHelper.updateFavouriteStatus(itemId, isFavourite)
//        _favouriteUpdated.postValue(isFavourite)
//    }

    fun getID(image: String, databaseHelper: DatabaseHelper): Int {
        return databaseHelper.getRecordIdByURL(image)
    }

    fun deleteHistoryRecord(itemId: Int, databaseHelper: DatabaseHelper) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                databaseHelper.deleteItemById(itemId)
                _recordDeleted.postValue(true)
            }
        }
    }

    fun deleteSessionRecord(itemId: Int, databaseHelper: DatabaseHelper) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                databaseHelper.deleteItemBySessionId(itemId)
                _recordDeleted.postValue(true)
            }
        }
    }

    fun updateOnBackPress() {
        _recordDeleted.postValue(false)
    }
}