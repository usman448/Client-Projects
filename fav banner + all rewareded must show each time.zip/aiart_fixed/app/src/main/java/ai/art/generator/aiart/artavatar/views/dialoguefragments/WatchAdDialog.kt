package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ItemWatchAdDialogBinding
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class WatchAdDialog(val onClickButton: (String) -> Unit,var from:String?=null) : BottomSheetDialogFragment() {
    private lateinit var binding: ItemWatchAdDialogBinding
    private var mContext: Context? = null
    private var mActivity: MainActivity? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as? MainActivity
    }

    override fun onStart() {
        super.onStart()
        (dialog as BottomSheetDialog).behavior.state = BottomSheetBehavior.STATE_EXPANDED
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = ItemWatchAdDialogBinding.inflate(inflater, container, false)

        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        when(from){
            "MainActivity"->{
                mActivity?.sendFirebaseEvents("main_ad_dialog_box_displayed")
            }
            "resultfragment"->{
                mActivity?.sendFirebaseEvents("result_scr_ad_dialog_box_displayed")
            }
            "EditPrompt"->{
                mActivity?.sendFirebaseEvents("edit_prompt_ad_dialog_box_displayed")
            }
        }
        binding.watchAdButton.setOnClickListener {
            when(from){
                "MainActivity"->{
                    mActivity?.sendFirebaseEvents("main_db_watch_ad_btn_clicked")
                }
                "resultfragment"->{
                    mActivity?.sendFirebaseEvents("result_scr_db_watch_ad_btn_clicked")
                }
                "EditPrompt"->{
                    mActivity?.sendFirebaseEvents("edit_prompt_db_watch_ad_btn_clicked")
                }
            }

            onClickButton(getString(R.string.watchAd))
            dismiss()
        }

        binding.removeAdButton.setOnClickListener {
            when(from){
                "MainActivity"->{
                    mActivity?.sendFirebaseEvents("main_db_remove_ad_btn_clicked")
                }
                "resultfragment"->{
                    mActivity?.sendFirebaseEvents("result_scr_db_remove_ad_btn_clicked")
                }
                "EditPrompt"->{
                    mActivity?.sendFirebaseEvents("edit_prompt_db_remove_ad_btn_clicked")
                }
            }
            mActivity?.premiumLauncher?.launch(Intent(mContext, PremiumActivity::class.java))
            dismiss()
        }
    }
}