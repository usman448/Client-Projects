package ai.art.generator.aiart.artavatar.adapter

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.LanguageItemBinding
import ai.art.generator.aiart.artavatar.model.LanguageModel
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView

class LanguageAdapter(
    private val context: Context,
    private val items: ArrayList<LanguageModel>,
    private var selectedItemPosition: Int,
) : RecyclerView.Adapter<LanguageAdapter.ViewHolder>() {

    private var onItemClickListener: OnItemClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LanguageItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        if (position == selectedItemPosition) {
            holder.layout.setBackgroundResource(R.drawable.selected_language_bg)
            holder.radioButton.setImageResource(R.drawable.white_checked)
            holder.langNameTxt.setTextColor(Color.WHITE)
            holder.langCodeTxt.setTextColor(Color.WHITE)
        } else {
            holder.langCodeTxt.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.radioButtonCircleColor))
            holder.langNameTxt.setTextColor(context.resources.getColor(R.color.black))
            holder.layout.setBackgroundResource(R.drawable.gray_language_bg)
            holder.radioButton.setImageResource(R.drawable.unchecked_btn)
        }

        holder.bind(item)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    interface OnItemClickListener {
        fun onItemClick(languageName: LanguageModel)
    }

    inner class ViewHolder(binding: ViewDataBinding) :
        RecyclerView.ViewHolder(binding.root) {

        val langNameTxt: TextView = binding.root.findViewById(R.id.lang_name_txt)
        val langCodeTxt: TextView = binding.root.findViewById(R.id.lang_code_txt)
        val radioButton: ImageView = binding.root.findViewById(R.id.radioButton)
        val layout: ConstraintLayout = binding.root.findViewById(R.id.language_view)

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition

                val previousSelectedItemPosition = selectedItemPosition
                selectedItemPosition = position
                notifyItemChanged(previousSelectedItemPosition)
                notifyItemChanged(selectedItemPosition)

                if (position != RecyclerView.NO_POSITION) {
                    onItemClickListener?.onItemClick(items[position])
                }
            }
        }

        fun bind(name: LanguageModel) {

            langNameTxt.text = name.title
            langCodeTxt.text = name.language
            /*textView.text = when (name) {
                "English" -> " English(USA)"
                "Arabic" -> "Arabic(عربي)"
                "Bangla" -> "Bangla(বাংলা)"
                "Chinese" -> "Chinese(中国人)"
                "French" -> "French(Français)"
                "German" -> "German(Deutsch)"
                "Hindi" -> "Hindi(हिंदी)"
                "Indonesian" -> "Indonesian(bahasa Indonesia)"
                "Italian" -> "Italian(Italiano)"
                "Malay" -> "Malay(Melayu)"
                "Dutch" -> "Dutch(Nederlands)"
                "Russian" -> "Russian(Русский)"
                "Spanish" -> "Spanish(Español)"
                "Turkish" -> "Turkish(Türkçe)"
                "Ukrainian" -> "Ukrainian(Український)"
                "Portuguese" -> "Portuguese(Português)"
                "Korean" -> "Korean(한국인)"
                "Thai" -> "Thai(แบบไทย)"
                "Japanese" -> "Japanese(日本語)"
                "Vietnamese" -> "Vietnamese(Tiếng Việt)"
                else -> name
            }*/
        }
    }
}
