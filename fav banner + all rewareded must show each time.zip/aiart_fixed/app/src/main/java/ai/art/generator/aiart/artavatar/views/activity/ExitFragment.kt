package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.R
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import androidx.cardview.widget.CardView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium

class ExitFragment : BottomSheetDialogFragment() {

    private var cvAd: CardView? = null
    private var flAdExit: FrameLayout? = null
    private var btnExit: Button? = null
    private var btnCancel: Button? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_exit, container, false)

        // Find views manually
        cvAd = view.findViewById(R.id.cv_ad)
        flAdExit = view.findViewById(R.id.fl_ad_exit)
        btnExit = view.findViewById(R.id.btn_exit)
    //    btnCancel = view.findViewById(R.id.btn_cancel) // optional, if exists

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Handle Ad Visibility & Display
        if (requireContext().isPremium()) {
            cvAd?.visibility = View.GONE
        } else {
            showNativeAd()
        }

        // Handle Exit button
        btnExit?.setOnClickListener {
            requireActivity().finishAffinity()
        }

        // Optional Cancel button
        btnCancel?.setOnClickListener {
            dismiss()
        }
    }

    private fun showNativeAd() {
        val adConfig = AdConfigManager.SHOW_MAIN_NATIVE_EXIT_DIALOG.apply {
            adConfig.nativeAdLayout = R.layout.layout_native_ad_exit
        }

        // Show pre-loaded native ad
        AdsManagerX.showNativeAd(
            adConfigManager = adConfig,
            nativeAdContainer = flAdExit!!
        )
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        return dialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        cvAd = null
        flAdExit = null
        btnExit = null
        btnCancel = null
    }
}