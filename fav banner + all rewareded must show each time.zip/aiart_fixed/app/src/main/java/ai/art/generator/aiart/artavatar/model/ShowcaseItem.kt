package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep


@Keep
data class ShowcaseItem(
    val model_id: String,
    val prompt: String,
    val negative_prompt: String = "",
    val width: String,
    val height: String,
    val image: String,
    val num_inference_steps: String = "",
    val guidance_scale: Float,
    val self_attention: String = "",
    val stylePreset: String = "",
    val steps: Int = 20,
    val samples: Int = 1,
    val noiseSeed: Int = 0
    )

