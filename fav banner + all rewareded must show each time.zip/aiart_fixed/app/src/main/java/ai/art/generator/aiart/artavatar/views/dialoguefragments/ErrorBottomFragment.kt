package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentErrorBottomBinding
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class ErrorBottomSheet : BottomSheetDialogFragment() {

    private lateinit var binding: FragmentErrorBottomBinding
    var onTryAgainBtnClick: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentErrorBottomBinding.inflate(inflater, container, false)

        binding.tryAgainBtn.setOnClickListener {
            context?.sendFirebaseEvents("main_error_dialog_box_try_again")
            onTryAgainBtnClick?.invoke()
            dismiss()
        }

        return binding.root
    }

    override fun show(manager: FragmentManager, tag: String?) {

        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (ignored: IllegalStateException) {

        }
    }


}