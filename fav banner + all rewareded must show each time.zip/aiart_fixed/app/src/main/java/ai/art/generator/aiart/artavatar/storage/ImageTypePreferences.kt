package ai.art.generator.aiart.artavatar.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class ImageTypePreferences(context: Context) {
    companion object{
        const val SHARED_PREF_NAME = "image_type_pref"
        const val IMAGE_TYPE = "image_type"
    }

    private val sharedPreferences: SharedPreferences  = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)

    fun saveImageTypePreferences(type: String) {
        sharedPreferences.edit {
            putString(IMAGE_TYPE, type)
        }
    }

    fun getImageTypePreferences(): String {
        return sharedPreferences.getString(IMAGE_TYPE, "JPG") ?: "JPG"
    }

    fun clearStorage() = sharedPreferences.edit().clear().apply()
}