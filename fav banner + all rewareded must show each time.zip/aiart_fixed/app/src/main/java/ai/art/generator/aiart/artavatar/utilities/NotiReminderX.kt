package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.NotiRedirectActivity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Context.ALARM_SERVICE
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import com.hm.admanagerx.utility.TinyDB

fun Context.notiReminder() {

    val mAlarmManager = getSystemService(ALARM_SERVICE) as? AlarmManager

    val notiReminderReceiverX = Intent(this, NotiReminderReceiverX::class.java)
    notiReminderReceiverX.putExtra("type", "NotiReminder")

    val mRandomReceiverPendingIntent = PendingIntent.getBroadcast(
        this, 101, notiReminderReceiverX, if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
    )



    if (!TinyDB.getInstance(this).getBoolean("isAlarmRunning")) {
        mAlarmManager?.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime(),
            6 * 60 * 60 * 1000, mRandomReceiverPendingIntent
        )
        TinyDB.getInstance(this).putBoolean("isAlarmRunning",true)
    }



}


class NotiReminderReceiverX : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {

        val type = intent?.getStringExtra("type")

        if (type == "NotiReminder" && context != null) {
            Log.d("NotiReminderReceiverX", "NotiReminder")
            notificationReminderGroup(context, "NotiReminder")

        }
    }
}

val notiTextArrayList = arrayListOf(
    "Turn text into pictures your way! Choose sizes and styles you like. Try this now.",
    "Make visuals from text! Pick sizes, styles, and more in an instant. Try these features now.",
    "Upgrade to premium for limitless creativity! Unlock diverse aspect ratios, modules, and styles today. Get premium now.",
    "Create, explore, enjoy! Turn your text into great images with our app. Try the amazing features now.",
    "New styles, new possibilities! Try our app to customize text-based images as you envision. Try this now.",
    "Expand your options! Premium access means unlocking multiple ratios, modules, and styles. Upgrade to premium now.",
    "From text to masterpiece! Explore various styles and create high-quality images effortlessly. Try the amazing feature now.",
    "Use our app to make pictures just the way you want! Change the size to fit what you need. Try this now.",
    "Tell stories with pictures! Our app helps turn your words into cool and different images. Try the amazing feature now.",
    "Upgrade for enhanced features! Access a world of aspect ratios, modules, and styles with premium. Get it now.",
    "Your history of creativity awaits! Check out the prompt creation archive in our app. View history now.",
    "Set your imagination free! Select negative prompts, keywords, and image types in our app. Try this now.",
    "History of your creativity at your fingertips! Revisit your prompts in our app's archive feature. Try this now.",
    "Explore limitless creativity! Choose from diverse styles, modules, and image types in our app. Try these features now.",
    "Unlock creativity! Premium brings diverse aspect ratios, modules, and styles for your artistic journey. Try premium now."
)


var bundleNotificationId = 100
var singleNotificationId = 100


fun notificationReminderGroup(applicationContext: Context, channelId: String) {
    // Create Notification
    val contentTitle = "Articraft AI Art Generator"
    val contentText = notiTextArrayList.random()


    lateinit var summaryNotificationBuilder: NotificationCompat.Builder

    val defaultSoundUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    var notificationManager: NotificationManager =
        applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Notification Group Key
    val groupKey = "bundle_notification_$bundleNotificationId"

    val flagsX = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    } else {
        PendingIntent.FLAG_UPDATE_CURRENT
    }
    // Notification Group click intent
    val resultIntent = Intent(applicationContext, MainActivity::class.java)
    resultIntent.putExtra("notification", "Summary Notification")
    resultIntent.putExtra("notification_id", bundleNotificationId)
    resultIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    val resultPendingIntent = PendingIntent.getActivity(
        applicationContext, bundleNotificationId, resultIntent, flagsX
    )

    // We need to update the bundle notification every time a new notification comes up
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        if (notificationManager.notificationChannels.size < 2) {
            val groupChannel = NotificationChannel(
                "bundle_channel_id", "bundle_channel_name", NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(groupChannel)
            val channel = NotificationChannel(
                "channel_id", "channel_name", NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }
    }
    summaryNotificationBuilder =
        NotificationCompat.Builder(applicationContext, "bundle_channel_id")
            .setGroup(groupKey).setGroupSummary(true)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setAutoCancel(true)
            .setContentIntent(resultPendingIntent)

    if (singleNotificationId == bundleNotificationId) singleNotificationId = bundleNotificationId + 1
    else singleNotificationId++

    // Individual notification click intent
    resultIntent.setClass(applicationContext, NotiRedirectActivity::class.java)
    resultIntent.putExtra("notification", "Single Notification")
    resultIntent.putExtra("notification_id", singleNotificationId)
    resultIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP

    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    } else {
        PendingIntent.FLAG_UPDATE_CURRENT
    }
    val notificationIntent = PendingIntent.getActivity(
        applicationContext, singleNotificationId, resultIntent, flags
    )

    val notification =
        NotificationCompat.Builder(applicationContext, "channel_id")
            .setGroup(groupKey)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(contentText)
            )
            .setSound(defaultSoundUri)
            .setAutoCancel(true)
            .setGroupSummary(false)
            .setContentIntent(notificationIntent)

    notificationManager.notify(singleNotificationId, notification.build())
    notificationManager.notify(bundleNotificationId, summaryNotificationBuilder.build())
}

