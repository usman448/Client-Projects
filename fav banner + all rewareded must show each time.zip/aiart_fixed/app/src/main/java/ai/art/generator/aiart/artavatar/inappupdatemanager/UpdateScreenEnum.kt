package recovermessages.restoredeleteddata.recoverdata.notifyme.inappupdatemanager

enum class UpdateScreenEnum(val value : Int = 1) {
    SPLASH_SCREEN(1),
    MAIN_SCREEN(2)
}