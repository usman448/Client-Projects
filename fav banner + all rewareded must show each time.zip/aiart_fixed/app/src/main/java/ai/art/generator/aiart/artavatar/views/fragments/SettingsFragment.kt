package ai.art.generator.aiart.artavatar.views.fragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.cmp.AdsConsentManagerX
import ai.art.generator.aiart.artavatar.databinding.FragmentSettingsBinding
import ai.art.generator.aiart.artavatar.model.SharedPreferenceHelper
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.openUrlInCustomTabs
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.showToast
import ai.art.generator.aiart.artavatar.utilities.ratingDialog
import ai.art.generator.aiart.artavatar.utilities.sendEmailX
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.views.dialoguefragments.ImageSettingsBottomSheet
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import ai.art.generator.aiart.artavatar.views.activity.UserScreenNavigationState
import ai.art.generator.aiart.artavatar.views.dialoguefragments.SelectThemeBottomFragment
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isAppOpenAdShow
import com.hm.admanagerx.isPremium

class SettingsFragment : Fragment(), View.OnClickListener {
    private lateinit var binding: FragmentSettingsBinding

    var isExternalIntentActive = false
    private val viewModel: BottomSheetVM by activityViewModels()
    var mContext: Context? = null
    private var mActivity: MainActivity? = null
    private lateinit var onBackPressedCallback: OnBackPressedCallback
    private var adsConsentManagerX: AdsConsentManagerX? = null

    companion object {
        fun newInstance() = SettingsFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentSettingsBinding.inflate(inflater, container, false)
        //when theme is change and activity is recreate then
        Log.i("userMovingInfo", "setting Frag onCreate: ${Constants.userMovingScreenState}")
        when (Constants.userMovingScreenState) {
            UserScreenNavigationState.MAIN_TO_SETTING_TO_LANGUAGE.label -> {
                mActivity?.let {
                    Constants.userMovingScreenState =
                        UserScreenNavigationState.MAIN_TO_SETTING_TO_LANGUAGE.label
                    val fromSplash = false
                    val languageFragment: LanguageFragment = LanguageFragment.newInstance(fromSplash)
                    val fragmentManager = it.supportFragmentManager
                    val transaction = fragmentManager.beginTransaction()
                    transaction.add(R.id.fragmentContainer, languageFragment)

                    transaction.addToBackStack(null)
                    transaction.commit()
                }
            }
        }
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        isExternalIntentActive = false //flag reset arslan
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Helper.hideKeyboard(mContext)

        observers()
        clickListener()
        if (context?.isPremium() == false)

            adsConsentManagerX = mContext?.let { AdsConsentManagerX.getInstance(it) }
        if (adsConsentManagerX?.isPrivacyOptionsRequired == true && mActivity?.isPremium() == false) {
            binding.updateConsent.visibility = View.VISIBLE
            binding.updateConsentViewLine.visibility = View.VISIBLE
        } else {
            binding.updateConsent.visibility = View.GONE
            binding.updateConsentViewLine.visibility = View.GONE
        }

        mContext?.let {
            if (SharedPreferenceHelper.isRatingDone(it)) {
                binding.rateUs.visibility = View.GONE
            } else {
                binding.rateUs.visibility = View.VISIBLE
            }
        }
        if (mContext?.isPremium() == true) {
            hidePremiumUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedCallback = object : OnBackPressedCallback(true /* enabled by default */) {
            override fun handleOnBackPressed() {
                Constants.userMovingScreenState = ""
                val fragmentManager = requireActivity().supportFragmentManager
                fragmentManager.popBackStack()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(
            requireActivity(),
            onBackPressedCallback
        )
    }

    override fun onStart() {
        super.onStart()
        // Agar user external intent se wapas aaya hai to App Open Ad show mat karo
        if (isExternalIntentActive) {
            requireContext().isAppOpenAdShow(false)
        } else {
            requireContext().isAppOpenAdShow(true)
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    override fun onDetach() {
        onBackPressedCallback.remove()
        super.onDetach()
    }

    private fun hidePremiumUI() {
        binding.settingsHeader.visibility = View.GONE
    }

    private fun observers() {
        viewModel.isPremium.observe(viewLifecycleOwner) {
            hidePremiumUI()
        }
    }

    private fun clickListener() {
        binding.imageSettings.setOnClickListener(this)
        binding.languageSelection.setOnClickListener(this)
        binding.tryNowBtn.setOnClickListener(this)
        binding.rateUs.setOnClickListener(this)
        binding.shareApp.setOnClickListener(this)
        binding.feedback.setOnClickListener(this)
        binding.updateConsent.setOnClickListener(this)
        binding.privacyPolicy.setOnClickListener(this)

        binding.backButtonImageView.setOnClickListener {
            mContext?.sendFirebaseEvents("settings_back_icon_clicked")
            Constants.userMovingScreenState = ""
            activity?.onBackPressed()
        }

        binding.appTheme.setOnClickListener {

            //ars_
            loadBannerForAppthemeClick()

            val appThemeBottomSheet = SelectThemeBottomFragment()
            activity?.let {
                appThemeBottomSheet.show(
                    it.supportFragmentManager, appThemeBottomSheet.tag
                )
            }
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            binding.imageSettings -> {
                val settingsBottomSheet = ImageSettingsBottomSheet()
                activity?.let {
                    settingsBottomSheet.show(
                        it.supportFragmentManager, settingsBottomSheet.tag
                    )
                }
            }

            binding.languageSelection -> {
                mActivity?.let {
                    Constants.userMovingScreenState =
                        UserScreenNavigationState.MAIN_TO_SETTING_TO_LANGUAGE.label
                    val fromSplash = false
                    val languageFragment: LanguageFragment = LanguageFragment.newInstance(fromSplash)

                    val fragmentManager = it.supportFragmentManager
                    val transaction = fragmentManager.beginTransaction()
                    transaction.add(R.id.fragmentContainer, languageFragment)
                    transaction.addToBackStack(null)
                    transaction.commit()
                }

            }

            binding.rateUs -> {
                isExternalIntentActive = true
                mContext?.sendFirebaseEvents("settings_rate_us_clicked")
                val sheet = activity?.ratingDialog(
                    onExitClick = null
                ) { binding.rateUs.visibility = View.GONE }
                sheet?.findViewById<TextView>(R.id.tv_cancelBtn)?.text =
                    mContext?.getString(R.string.cancel)
                sheet?.show()
            }

            binding.tryNowBtn -> {
                mContext?.sendFirebaseEvents("premium_activity_started")
                mActivity?.premiumLauncher?.launch(Intent(context, PremiumActivity::class.java))
            }

            binding.shareApp -> {
                isExternalIntentActive = true
                mContext?.sendFirebaseEvents("settings_share_app_clicked")
                try {
                    val sharingIntent = Intent(Intent.ACTION_SEND)
                    sharingIntent.type = "text/plain"
                    sharingIntent.putExtra(
                        Intent.EXTRA_TEXT, Constants.SHARE_APP + mContext?.packageName
                    )
                    startActivity(
                        Intent.createChooser(
                            sharingIntent,
                            resources.getString(R.string.shareVia)
                        )
                    )
                } catch (_: Exception) {

                }
            }

            binding.feedback -> {
                isExternalIntentActive = true
                mActivity?.sendEmailX(
                    Constants.FEEDBACK,
                    getString(R.string.feedback) + " " + resources.getString(R.string.short_app_name),
                    ""
                )
            }

            binding.privacyPolicy -> {
                isExternalIntentActive = true
                mContext?.let { openUrlInCustomTabs(it, Constants.PRIVACY_POLICY) }
            }

            binding.updateConsent -> {
                isExternalIntentActive = true
                mActivity?.let {
                    adsConsentManagerX?.showPrivacyOptionsForm(it) { formError ->
                        if (formError?.message != null) {
                            showToast(requireContext(), getString(R.string.network_error))
                        }
                    }
                }
            }
        }
    }

    private fun SettingsFragment.loadBannerForAppthemeClick() {

        if (context?.isPremium() == true) return
//        binding?.containerAdStartBannerBottom?.let {
        AdsManagerX.loadBannerAd(
            this,
            AdConfigManager.BANNER_AD_THEME_CLICK_AIART,
            null
        )
//        }
    }
}