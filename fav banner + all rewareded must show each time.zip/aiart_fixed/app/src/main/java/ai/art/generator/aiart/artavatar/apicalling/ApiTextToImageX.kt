package ai.art.generator.aiart.artavatar.apicalling

import androidx.annotation.Keep
import ai.art.generator.aiart.artavatar.model.FetchApiResponse
import ai.art.generator.aiart.artavatar.model.ResponseBody
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@Keep
data class RequestBodyJson(var token: String)

inline fun <reified T : Any> String.jsonToObject(): T? {
    return try {
        Gson().fromJson(this, T::class.java)
    } catch (e: Exception) {
        null
    }
}

/*fun generateAiImage(request: RequestBodyJson, onSuccess: (String) -> Unit, onFailed: (String) -> Unit) {

    val apiService = RetrofitClient.apiService
    val requestToJson = Gson().toJson(request)

    apiService.createPostX(requestToJson).enqueue(object : Callback<String> {
        override fun onResponse(
            call: Call<String>,
            response: Response<String>,
        ) {

            val json = response.body().toString()

            val result = json.jsonToObject<ResponseBody>()?.output?.firstOrNull()
                ?: json.jsonToObject<FetchApiResponse>()?.output?.firstOrNull()

            result?.apply { onSuccess(this) } ?: onFailed(json)

        }

        override fun onFailure(call: Call<String>, t: Throwable) {
            onFailed(t.toString())
        }
    })
}*/


suspend fun generateAiImage(request: RequestBodyJson, onSuccess: (String) -> Unit, onFailed: (String) -> Unit) {

    val apiService = RetrofitClient.apiService
    val requestToJson = Gson().toJson(request)

    try {
        val response = apiService.createPostX(requestToJson)

        if (response.isSuccessful) {
            withContext(Main){
                val json = response.body().toString()

                val result = json.jsonToObject<ResponseBody>()?.output?.firstOrNull()
                    ?: json.jsonToObject<FetchApiResponse>()?.output?.firstOrNull()


                result?.apply { onSuccess(this) } ?: onFailed(json)
            }


        } else {
            withContext(Main){
                onFailed(response.message())
            }
        }
    } catch (e: Exception) {

        withContext(Main){
            onFailed(e.message ?: "")
        }
    }
}







