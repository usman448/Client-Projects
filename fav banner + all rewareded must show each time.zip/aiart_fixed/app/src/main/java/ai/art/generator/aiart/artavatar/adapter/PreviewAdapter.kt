package ai.art.generator.aiart.artavatar.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ai.art.generator.aiart.artavatar.databinding.PreviewItemBinding
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry

class PreviewAdapter(
    private val context: Context,
    private val imageList: List<String>,
//    val onThumbnailClick: (String) -> Unit
    private var onItemClickListener: OnItemClickListener
): RecyclerView.Adapter<PreviewAdapter.ThumbnailVH>() {

    private var selectedPosition: Int = 0

    fun updateSelectedPosition(position: Int) {
        selectedPosition = position
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThumbnailVH {
        val binding = PreviewItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ThumbnailVH(binding)
    }

    override fun onBindViewHolder(holder: ThumbnailVH, position: Int) {
        holder.bind(imageList[position])
        if(position == selectedPosition) {
            holder.binding.overlay.visibility = View.VISIBLE
        } else {
            holder.binding.overlay.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return imageList.size
    }

    interface OnItemClickListener {
        fun onItemClick(item: String)
    }

    inner class ThumbnailVH(val binding: PreviewItemBinding): RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClickListener.onItemClick(imageList[position])
                }

            }
        }
        fun bind(image: String) {
            binding.previewShimmer.startShimmer()
            Helper.loadWithRetry(context, binding.imageView, image, 1024, 1024, binding.previewShimmer, false)
        }
    }

}