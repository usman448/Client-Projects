package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentAspectRatioBinding
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.hm.admanagerx.isPremium

class AspectRationFragment(private val aspectRatio: String, val onUpdateAspectRatio: (String) -> Unit) : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentAspectRatioBinding
    private var mContext: Context? = null
    private var mActivity: MainActivity? = null
    private var selectAspectRatio = ""
    private var premiumLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            onUpdateAspectRatio(selectAspectRatio)
            dismiss()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as? MainActivity
    }

    override fun onStart() {
        super.onStart()
        (dialog as BottomSheetDialog).behavior.state = BottomSheetBehavior.STATE_EXPANDED
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAspectRatioBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.ratio11Layout.setOnClickListener {
            mContext?.sendFirebaseEvents("aspect_ratio_selected_1_1")
            onUpdateAspectRatio(getString(R.string._1_1))
            binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
            handelSelectAspectRation(getString(R.string._1_1))
            dismiss()
        }

        binding.ratio916Layout.setOnClickListener {
            selectAspectRatio = getString(R.string._9_16)
            mContext?.sendFirebaseEvents("aspect_ratio_selected_9_16")
            if(requireActivity().isPremium()){
                onUpdateAspectRatio(getString(R.string._9_16))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                handelSelectAspectRation(getString(R.string._9_16))
                dismiss()
            }else{
                premiumLauncher.launch(Intent(mContext, PremiumActivity::class.java))
            }
        }

        binding.ratio169Layout.setOnClickListener {
            mContext?.sendFirebaseEvents("aspect_ratio_selected_16_9")
            selectAspectRatio = getString(R.string._16_9)
            if(requireActivity().isPremium()){
                onUpdateAspectRatio(getString(R.string._16_9))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                handelSelectAspectRation(getString(R.string._16_9))
                dismiss()
            }else{
                premiumLauncher.launch(Intent(mContext, PremiumActivity::class.java))
            }
        }

        binding.ratio34Layout.setOnClickListener {
            mContext?.sendFirebaseEvents("aspect_ratio_selected_3_4")
            selectAspectRatio = getString(R.string._3_4)
            if(requireActivity().isPremium()){
                onUpdateAspectRatio(getString(R.string._3_4))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                handelSelectAspectRation(getString(R.string._3_4))
                dismiss()
            }else{
                premiumLauncher.launch(Intent(mContext, PremiumActivity::class.java))
            }
        }

        binding.ratio43Layout.setOnClickListener {
            mContext?.sendFirebaseEvents("aspect_ratio_selected_4_3")
            selectAspectRatio = getString(R.string._4_3)
            if(requireActivity().isPremium()){
                onUpdateAspectRatio(getString(R.string._4_3))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                handelSelectAspectRation(getString(R.string._4_3))
                dismiss()
            }else{
                premiumLauncher.launch(Intent(mContext, PremiumActivity::class.java))
            }
        }
    }

    private fun initUi() {
        val visibility = when (requireActivity().isPremium()) {
            true -> View.GONE
            false -> View.VISIBLE
        }
        binding.premium1.visibility = visibility
        binding.premium2.visibility = visibility
        binding.premium3.visibility = visibility
        binding.premium4.visibility = visibility

        when(aspectRatio){
            AspectRatio.Ratio11.label -> handelSelectAspectRation(aspectRatio)
            AspectRatio.Ratio169.label -> handelSelectAspectRation(aspectRatio)
            AspectRatio.Ratio916.label -> handelSelectAspectRation(aspectRatio)
            AspectRatio.Ratio34.label -> handelSelectAspectRation(aspectRatio)
            AspectRatio.Ratio43.label -> handelSelectAspectRation(aspectRatio)
        }
    }

    private fun handelSelectAspectRation(ratio: String){
        when(ratio){
            AspectRatio.Ratio11.label -> {
                binding.ratio11Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_select_aspect_ratio)
                binding.ratio169Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio916Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio34Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio43Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
            }
            AspectRatio.Ratio916.label ->{
                binding.ratio11Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio169Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio916Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_select_aspect_ratio)
                binding.ratio34Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio43Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
            }
            AspectRatio.Ratio169.label ->{
                binding.ratio11Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio169Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_select_aspect_ratio)
                binding.ratio916Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio34Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio43Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
            }
            AspectRatio.Ratio43.label ->{
                binding.ratio11Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio169Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio916Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio34Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio43Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_select_aspect_ratio)
                binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
            }
            AspectRatio.Ratio34.label ->{
                binding.ratio11Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio169Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio916Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio34Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_select_aspect_ratio)
                binding.ratio43Layout.background = AppCompatResources.getDrawable(requireContext(), R.drawable.ic_unselect_aspect_ratio)
                binding.ratio11Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio169Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio916Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
                binding.ratio34Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                binding.ratio43Textview.setTextColor(ContextCompat.getColor(requireContext(), R.color.unselectRatioColor))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        initUi()
    }
}
enum class AspectRatio(val label: String){
    Ratio11("1:1"),
    Ratio916("9:16"),
    Ratio169("16:9"),
    Ratio43("4:3"),
    Ratio34("3:4")
}