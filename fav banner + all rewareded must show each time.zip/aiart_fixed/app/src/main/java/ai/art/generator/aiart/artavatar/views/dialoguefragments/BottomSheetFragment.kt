package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentBottomSheetBinding
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Singleton
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

var onAdvanceDismissListener: ((
    Boolean, String, String,
    Int, String, String
) -> Unit)? = null

class BottomSheetFragment : BottomSheetDialogFragment(), View.OnClickListener {
    private lateinit var binding: FragmentBottomSheetBinding
    private var addedNegativeTag: MutableList<String> = mutableListOf()
    private var negativePrompt: String? = null
    private var highQualityValue: String = "no"
    private var isFromEdit = false
    private var cfgScale = 7
    private var deNoisingSteps = "20"
    private var mContext: Context? = null
    private var mActivity: MainActivity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)

        arguments?.let { it ->
            isFromEdit = it.getBoolean(Constants.ARG_IS_FROM_EDIT)

            it.getString(Constants.ARG_NEGATIVE_PROMPT)?.let {
                negativePrompt = it
            }

            it.getString(Constants.ARG_NEGATIVE_PROMPT_TAGS)?.let {
                val delimiter = ","
                val stringList: List<String> = it.split(delimiter)

                for (i in stringList) {
                    if (i != "") {
                        addedNegativeTag.add(i.trimStart())
                    }
                }
            }

            it.getString(Constants.ARG_CFG_SCALE).let {
                cfgScale = it?.toInt() ?: 7
            }

            it.getString(Constants.ARG_DE_NOISING)?.let {
                deNoisingSteps = it
            }

            it.getString(Constants.ARG_IMAGE_QUALITY)?.let {
                highQualityValue = it
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val context =
            mContext ?: throw IllegalStateException("mContext is null, cannot create dialog")

        return BottomSheetDialog(context, theme).apply {
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.peekHeight = context.resources.displayMetrics.heightPixels
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBottomSheetBinding.inflate(inflater, container, false)
        setUI()
        clickListeners()
        return binding.root
    }

    private fun setUI() {
        binding.slider.progress = cfgScale
        binding.maxValue.text = cfgScale.toString()

        binding.stepsSlider.progress = deNoisingSteps.toInt()
        binding.maxSteps.text = deNoisingSteps

        if (binding.maxValue.text.toString() != "7" || deNoisingSteps != "20") {
            binding.defaultButton.setBackgroundResource(R.drawable.ic_activie_button_gradient)
            binding.defaultButton.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.black
                )
            )
        }

        negativePrompt?.let {
            binding.negativePrompt.setText(it.trimStart().replace("null", ""))
        }

        binding.negativePrompt.imeOptions = EditorInfo.IME_ACTION_DONE

        binding.negativePrompt.setRawInputType(
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        )

        binding.negativePrompt.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            //if (!hasFocus && binding.negativePrompt.text.isNotEmpty()) {
            if (isFromEdit) {
                mContext?.sendFirebaseEvents("edit_prompt_negative_prompt_entered")
            } else {
                mContext?.sendFirebaseEvents("negative_prompt_entered")
            }
            //  }
        }

        mContext?.let {
            for (i in binding.negativeTagsLayout.childCount - 1 downTo 0) {
                val childView = binding.negativeTagsLayout.getChildAt(i) as? TextView
                if (childView != null && addedNegativeTag.contains(childView.text)) {
                    childView.setTextColor(resources.getColor(R.color.black))
                    childView.background = AppCompatResources.getDrawable(
                        it,
                        R.drawable.ic_negative_tag_border
                    )
                    childView.setPadding(
                        Helper.spToPx(it, 15F),
                        Helper.spToPx(it, 7F),
                        Helper.spToPx(it, 15F),
                        Helper.spToPx(it, 7F)
                    )
                }
            }
        }


    }

    private fun clickListeners() {

        binding.slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.defaultButton.setBackgroundResource(R.drawable.ic_activie_button_gradient)
                binding.defaultButton.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.black
                    )
                )
                if (fromUser) {
                    var cfgProgress = progress
                    val min = 1
                    if (progress < min) {
                        cfgProgress = min
                    }
                    binding.maxValue.text = cfgProgress.toString()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (isFromEdit) {
                    mContext?.sendFirebaseEvents("edit_prompt_cfg_scale_changed")
                } else {
                    mContext?.sendFirebaseEvents("cfg_scale_changed")
                }

            }
        })

        binding.doneButton.setOnClickListener {
            mContext?.sendFirebaseEvents("advance_settings_done_btn_clicked")
            cfgScale = binding.maxValue.text.toString().toInt()
            deNoisingSteps = binding.maxSteps.text.toString()
            dismiss()
        }

        binding.defaultButton.setOnClickListener {
            mContext?.sendFirebaseEvents("advance_settings_default_btn_clicked")
            cfgScale = 7
            deNoisingSteps = "20"
            binding.slider.progress = cfgScale
            binding.maxValue.text = cfgScale.toString()

            binding.stepsSlider.progress = deNoisingSteps.toInt()
            binding.maxSteps.text = deNoisingSteps

            binding.defaultButton.setBackgroundResource(R.drawable.ic_gray_button_round_border)
            binding.defaultButton.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.buttonBorderColor
                )
            )
        }

        binding.stepsSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.defaultButton.setBackgroundResource(R.drawable.ic_activie_button_gradient)
                binding.defaultButton.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.black
                    )
                )
                if (fromUser) {
                    var deNoisingProgress = progress
                    val min = 11
                    if (progress < min) {
                        deNoisingProgress = min
                    }
                    binding.maxSteps.text = deNoisingProgress.toString()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (isFromEdit) {
                    mContext?.sendFirebaseEvents("edit_prompt_denoising_changed")
                } else {
                    mContext?.sendFirebaseEvents("denoising_changed")
                }

            }
        })

        binding.blur.setOnClickListener(this)
        binding.illustration.setOnClickListener(this)
        binding.painting.setOnClickListener(this)
        binding.outOfFrame.setOnClickListener(this)
        binding.lowQuality.setOnClickListener(this)
        binding.ugly.setOnClickListener(this)
        binding.cartoon.setOnClickListener(this)
    }

    override fun onDismiss(dialog: DialogInterface) {
        var negativeTags = ""
        for (i in 0 until addedNegativeTag.size) {
            negativeTags = negativeTags + ", " + addedNegativeTag[i]

            Singleton.getNegativeTag().add(i, addedNegativeTag[i])
        }

        Singleton.setNegativeText(binding.negativePrompt.text.toString())

        onAdvanceDismissListener?.invoke(
            isFromEdit, binding.negativePrompt.text.toString(),
            negativeTags, cfgScale, deNoisingSteps, highQualityValue
        )

        super.onDismiss(dialog)
    }

    override fun onClick(v: View?) {
        mContext?.let {
            if (addedNegativeTag.contains((v as TextView).text.toString())) {
                v.setTextColor(resources.getColor(R.color.gray))
                v.background =
                    AppCompatResources.getDrawable(it, R.drawable.negative_tags_bg)
                v.setPadding(
                    Helper.spToPx(it, 15F),
                    Helper.spToPx(it, 7F),
                    Helper.spToPx(it, 15F),
                    Helper.spToPx(it, 7F)
                )

                addedNegativeTag.remove(v.text.toString())

            } else {
                mContext?.sendFirebaseEvents("negative_prompt_options_selected")
                v.setTextColor(resources.getColor(R.color.black))
                v.background = AppCompatResources.getDrawable(
                    it,
                    R.drawable.ic_negative_tag_border
                )
                v.setPadding(
                    Helper.spToPx(it, 15F),
                    Helper.spToPx(it, 7F),
                    Helper.spToPx(it, 15F),
                    Helper.spToPx(it, 7F)
                )

                addedNegativeTag.add(v.text.toString())
            }
        }

    }

    companion object {
        @JvmStatic
        fun newInstance(
            fromEdit: Boolean, nPrompt: String?,
            nPromptTags: String?, cfgScale: String,
            deNoising: String, quality: String
        ) =
            BottomSheetFragment().apply {
                arguments = Bundle().apply {
                    putBoolean(Constants.ARG_IS_FROM_EDIT, fromEdit)
                    putString(Constants.ARG_NEGATIVE_PROMPT, nPrompt)
                    putString(Constants.ARG_NEGATIVE_PROMPT_TAGS, nPromptTags)
                    putString(Constants.ARG_CFG_SCALE, cfgScale)
                    putString(Constants.ARG_DE_NOISING, deNoising)
                    putString(Constants.ARG_IMAGE_QUALITY, quality)
                }
            }
    }
}