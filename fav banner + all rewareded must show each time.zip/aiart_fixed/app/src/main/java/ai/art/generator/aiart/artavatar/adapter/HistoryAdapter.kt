
package ai.art.generator.aiart.artavatar.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.HistoryFavItemBinding
import ai.art.generator.aiart.artavatar.databinding.HistoryItemBinding
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry
import com.facebook.shimmer.ShimmerFrameLayout
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import java.util.*
import androidx.viewbinding.ViewBinding
class HistoryAdapter(
    private val activity: FragmentActivity,
    private val isFavourites: Boolean,
    private val emptyBg: View,
    private val emptyLayout: LinearLayout,
    private val lifecycleOwner: LifecycleOwner
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), Filterable {

    private val ITEM_VIEW_TYPE = 0
    private val AD_VIEW_TYPE = 1
    private val ITEMS_BEFORE_AD = 4

    private var onItemClickListener: OnItemClickListener? = null
    private var filteredItemList: List<HistoryModel> = ArrayList()
    private var mainList: List<HistoryModel> = ArrayList()

    var canLoadAds: Boolean = false
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    fun setSpanSizeLookup(layoutManager: GridLayoutManager) {
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (getItemViewType(position) == AD_VIEW_TYPE) {
                    layoutManager.spanCount
                } else 1
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (canLoadAds && isAdPosition(position)) AD_VIEW_TYPE else ITEM_VIEW_TYPE
    }

    override fun getItemCount(): Int {
        if (filteredItemList.isEmpty()) return 0
        return if (canLoadAds) {
            val adCount = filteredItemList.size / ITEMS_BEFORE_AD
            filteredItemList.size + adCount
        } else {
            filteredItemList.size
        }
    }

    private fun isAdPosition(position: Int): Boolean {
        return (position + 1) % (ITEMS_BEFORE_AD + 1) == 0
    }

    private fun getDataIndex(adapterPosition: Int): Int {
        if (!canLoadAds) return adapterPosition
        val adsBefore = (adapterPosition + 1) / (ITEMS_BEFORE_AD + 1)
        return adapterPosition - adsBefore
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == AD_VIEW_TYPE) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.native_ad_container, parent, false)
            AdViewHolder(view)
        } else {
            val binding = if (isFavourites) {
                HistoryFavItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            } else {
                HistoryItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            }
            ViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is AdViewHolder) {
            holder.bindAd()
        } else if (holder is ViewHolder) {
            val dataIndex = getDataIndex(position)
            if (dataIndex in filteredItemList.indices) {
                holder.bind(filteredItemList[dataIndex])
            }
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val list = if (constraint.isNullOrEmpty()) {
                    mainList
                } else {
                    val pattern = constraint.toString().lowercase(Locale.getDefault())
                    mainList.filter {
                        it.prompt.lowercase(Locale.getDefault()).contains(pattern)
                    }
                }
                return FilterResults().apply { values = list }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filteredItemList = results?.values as? List<HistoryModel> ?: listOf()
                if (mainList.isEmpty()) {
                    showEmptyState(
                        R.drawable.empty_history,
                        if (isFavourites) R.string.no_favourite else R.string.no_history
                    )
                } else if (filteredItemList.isEmpty()) {
                    showEmptyState(R.drawable.empty_search, R.string.no_search_found)
                } else {
                    emptyLayout.visibility = View.GONE
                    emptyBg.visibility = View.GONE
                }
                notifyDataSetChanged()
            }
        }
    }

    private fun showEmptyState(iconRes: Int, textRes: Int) {
        emptyLayout.visibility = View.VISIBLE
        emptyBg.visibility = View.VISIBLE
        (emptyLayout.getChildAt(0) as? ImageView)?.setImageDrawable(
            AppCompatResources.getDrawable(activity, iconRes)
        )
        (emptyLayout.getChildAt(1) as? TextView)?.text = activity.getString(textRes)
    }

    fun setData(list: List<HistoryModel>) {
        mainList = list
        filteredItemList = list
        notifyDataSetChanged()
    }

    inner class ViewHolder(binding: ViewBinding) : RecyclerView.ViewHolder(binding.root) {
        private val imageView: ImageView = binding.root.findViewById(R.id.history_image)
        private val textView: TextView = binding.root.findViewById(R.id.history_prompt)
        private val shimmer: ShimmerFrameLayout =
            binding.root.findViewById(if (isFavourites) R.id.fav_shimmer else R.id.history_shimmer)
        private val favImage: ImageView? = binding.root.findViewById(R.id.add_to_fav)
        private val deleteImage: ImageView? = binding.root.findViewById(R.id.delete_history_item)
        private val favToggle: ImageView? = binding.root.findViewById(R.id.fav_toggle)
        private val stackImage: ImageView? = binding.root.findViewById(R.id.item_stack)

        init {
            binding.root.setOnClickListener {
                val pos = getDataIndex(adapterPosition)
                if (pos in filteredItemList.indices)
                    onItemClickListener?.onItemClick(filteredItemList[pos])
            }
            favToggle?.setOnClickListener {
                val pos = getDataIndex(adapterPosition)
                if (pos in filteredItemList.indices)
                    onItemClickListener?.onFavClick(filteredItemList[pos], false)
            }
            favImage?.setOnClickListener {
                val pos = getDataIndex(adapterPosition)
                if (pos in filteredItemList.indices) {
                    val item = filteredItemList[pos]
                    onItemClickListener?.onFavClick(item, item.favourite != 1)
                }
            }
            deleteImage?.setOnClickListener {
                val pos = getDataIndex(adapterPosition)
                if (pos in filteredItemList.indices)
                    onItemClickListener?.onDeleteClick(filteredItemList[pos], pos)
            }
        }

        fun bind(item: HistoryModel) {
            shimmer.startShimmer()
            loadWithRetry(itemView.context, imageView, item.imageUrl, 230, 230, shimmer, false)
            textView.text = item.prompt
            if (!isFavourites) {
                stackImage?.visibility = if (item.count > 1) View.VISIBLE else View.GONE
                val res = if (item.favourite == 1) R.drawable.ic_fill_heart else R.drawable.ic_heart
                favImage?.setImageDrawable(AppCompatResources.getDrawable(activity, res))
            }
        }
    }

    inner class AdViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val adFrame: FrameLayout = itemView.findViewById(R.id.fl_small_native)
        fun bindAd() {
            adFrame.visibility = View.VISIBLE
            adFrame.removeAllViews()
            AdsManagerX.showNativeAd(
                adConfigManager = AdConfigManager.LIST_NATIVE_AD_FOR_HISTORY,
                nativeAdContainer = adFrame
            )
        }
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    interface OnItemClickListener {
        fun onItemClick(item: HistoryModel)
        fun onFavClick(item: HistoryModel, isLike: Boolean)
        fun onDeleteClick(item: HistoryModel, position: Int)
    }
}