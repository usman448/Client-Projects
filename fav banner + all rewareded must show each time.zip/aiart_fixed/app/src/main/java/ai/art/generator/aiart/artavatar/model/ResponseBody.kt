package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

/*

data class ResponseBody(
    val status: String,
    val message: String,
    val generationTime: Double,
    val id: Int,
    val output: List<String>,
    val meta: Meta,
    val tip: String,
    val eta: Double,
    val webhook_status: String,
    val fetch_result: String,
    val future_links: List<String>,
    val response: ErrorResponse,
    val error_id: String,
)
*/
@Keep
data class ErrorResponse(
    val status: String,
    val message: String,
)

/*
data class Meta(
    val H: Int,
    val W: Int,
    val enable_attention_slicing: String,
    val file_prefix: String,
    val guidance_scale: Double,
    val model: String,
    val n_samples: Int,
    val negative_prompt: String,
    val outdir: String,
    val prompt: String,
    val revision: String,
    val safety_checker: String,
    val seed: Long,
    val steps: Int,
    val vae: String,
    val model_id: String,
    val scheduler: String,
    val full_url: String,
    val instant_response: String,
    val tomesd: String,
    val upscale: String,
    val multi_lingual: String,
    val panorama: String,
    val self_attention: String,
    val use_karras_sigmas: String,
    val algorithm_type: String,
    val safety_checker_type: String,
    val embeddings: String,
    val lora: String,
    val lora_strength: Int,
    val clip_skip: Int,
    val temp: String,
    val base64: String,
)*/

@Keep
data class ResponseBody(
    @SerializedName("status") var status: String? = null,
    @SerializedName("generationTime") var generationTime: Double? = null,
    @SerializedName("id") var id: Int? = null,
    @SerializedName("output") var output: ArrayList<String> = arrayListOf(),
    @SerializedName("webhook_status") var webhookStatus: String? = null,
    @SerializedName("meta") var meta: Meta? = Meta(),
)

@Keep
data class Meta(
    @SerializedName("prompt") var prompt: String? = null,
    @SerializedName("model_id") var modelId: String? = null,
    @SerializedName("negative_prompt") var negativePrompt: String? = null,
    @SerializedName("scheduler") var scheduler: String? = null,
    @SerializedName("safety_checker") var safetyChecker: String? = null,
    @SerializedName("W") var W: Int? = null,
    @SerializedName("H") var H: Int? = null,
    @SerializedName("guidance_scale") var guidanceScale: Int? = null,
    @SerializedName("seed") var seed: Int? = null,
    @SerializedName("steps") var steps: Int? = null,
    @SerializedName("n_samples") var nSamples: Int? = null,
    @SerializedName("full_url") var fullUrl: String? = null,
    @SerializedName("instant_response") var instantResponse: String? = null,
    @SerializedName("tomesd") var tomesd: String? = null,
    @SerializedName("free_u") var freeU: String? = null,
    @SerializedName("upscale") var upscale: String? = null,
    @SerializedName("multi_lingual") var multiLingual: String? = null,
    @SerializedName("panorama") var panorama: String? = null,
    @SerializedName("self_attention") var selfAttention: String? = null,
    @SerializedName("use_karras_sigmas") var useKarrasSigmas: String? = null,
    @SerializedName("algorithm_type") var algorithmType: String? = null,
    @SerializedName("safety_checker_type") var safetyCheckerType: String? = null,
    @SerializedName("embeddings") var embeddings: String? = null,
    @SerializedName("vae") var vae: String? = null,
    @SerializedName("lora") var lora: String? = null,
    @SerializedName("lora_strength") var loraStrength: Int? = null,
    @SerializedName("clip_skip") var clipSkip: Int? = null,
    @SerializedName("temp") var temp: String? = null,
    @SerializedName("base64") var base64: String? = null,
    @SerializedName("file_prefix") var filePrefix: String? = null,
)
@Keep
data class FetchApiResponse(
    @SerializedName("status") var status: String? = null,
    @SerializedName("id") var id: Int? = null,
    @SerializedName("output") var output: ArrayList<String> = arrayListOf(),
)