package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.StylesAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentStyleBottomBinding
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.hm.admanagerx.isPremium
import java.util.Locale

var onUpdateStyle: ((Boolean, String) -> Unit)? = null
var onUpdateModel: ((Boolean, String) -> Unit)? = null
private const val TAG = "StyleBottomFragmentInfo"

class StyleBottomFragment : BottomSheetDialogFragment(), StylesAdapter.OnItemClickListener {
    private lateinit var binding: FragmentStyleBottomBinding
    private lateinit var adapter: StylesAdapter
    private var mContext: Context? = null
    private var mActivity: MainActivity? = null
    private lateinit var data: String
    private lateinit var value: String
    private lateinit var name: String
    private var isFromEdit = false
    private var selectStyleName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)

        arguments?.let {
            isFromEdit = it.getBoolean(Constants.ARG_IS_FROM_EDIT)
            data = it.getString(Constants.ARG_STYLE_TYPE).toString()
            value = it.getString(Constants.ARG_STYLE_VALUE).toString()
            name = it.getString(Constants.ARG_STYLE_NAME).toString()
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return BottomSheetDialog(mContext!!, theme).apply {
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.peekHeight = context.resources.displayMetrics.heightPixels
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentStyleBottomBinding.inflate(inflater, container, false)
        if (data == "model") {
            binding.heading.text = getString(R.string.models)
            setupModelsRecyclerView()
        } else {
            binding.heading.text = getString(R.string.styles)
            setupStylesRecyclerView()
        }
        clickListeners()
        return binding.root
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as? MainActivity
    }

    private fun clickListeners() {
        val editText =
            binding.searchStyle.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
        editText.setTextColor(Color.BLACK)

        binding.searchStyle.setOnQueryTextFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.title.visibility = View.GONE

            } else {
                binding.title.visibility = View.VISIBLE
            }
        }

        binding.searchStyle.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                // Handle the search query submission
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Handle query text change (optional)
                val closeBtn =
                    binding.searchStyle.findViewById<ImageView>(androidx.appcompat.R.id.search_close_btn)
                closeBtn.setImageResource(R.drawable.close_search)
                adapter.filter.filter(newText)
                return true
            }
        })
    }

    private fun setupModelsRecyclerView() {
        Log.i("TAG", "setupModelsRecyclerView: $name")
        var modelItemIndex: Int = -1
        for (i in 0 until Constants.MODEL_IDS.size) {
            if (name == Constants.allModelNameList[i]) {
                modelItemIndex = i
                break
            }/*else{
                val modelID = Helper.reFormatModelID(name)
                if (modelID == Constants.MODEL_IDS[i]) {
                    modelItemIndex = i
                    break
                }
            }*/
        }
        mContext?.let {
            Log.i("TAG", "setupModelsRecyclerView: $modelItemIndex")
            adapter = StylesAdapter(it, Constants.allModelNameList.toList(), modelItemIndex)
            adapter.setOnItemClickListener(this)

            binding.styleRecyclerView.adapter = adapter
            binding.styleRecyclerView.layoutManager = GridLayoutManager(it, 2)
            Log.i("setupModelsRecyclerView", "setupModelsRecyclerView: $name  $modelItemIndex")
            binding.styleRecyclerView.smoothScrollToPosition(modelItemIndex)
        }

    }

    private fun setupStylesRecyclerView() {
        var styleItemIndex: Int = -1
        for (i in 0 until Constants.STYLE_IDS.size) {
            if (Constants.STYLE_IDS[i].contains(value, ignoreCase = true)) {
                styleItemIndex = i
                break
            }
        }
        Log.i("TAG", "setupStylesRecyclerView: value:$value   styleItemIndex:$styleItemIndex")

        mContext?.let {
            adapter = StylesAdapter(it, Constants.STYLE_IDS.toList(), styleItemIndex)
            adapter.setOnItemClickListener(this)
            binding.styleRecyclerView.adapter = adapter
            binding.styleRecyclerView.layoutManager = GridLayoutManager(it, 3)
            if (styleItemIndex == -1) styleItemIndex = 0
            binding.styleRecyclerView.smoothScrollToPosition(styleItemIndex)
        }

    }

    override fun onStyleItemClick(styleName: String) {
        selectStyleName = styleName
        if (data == "model") {
 /*           mContext?.sendFirebaseEvents(
                "model_selected",
                Bundle().apply { putString("model", styleName) })*/
            if (isFromEdit){
                mContext?.sendFirebaseEvents("edit_prompt_model_selected_${styleName.getFormattedString()}")
            }else{
                mContext?.sendFirebaseEvents("model_selected_${styleName.getFormattedString()}")
            }

            onUpdateModel?.invoke(isFromEdit, styleName)
        } else {
            if (mContext?.isPremium() == true) {
                if (isFromEdit){
                    mContext?.sendFirebaseEvents("edit_prompt_style_selected_${styleName.getFormattedString()}")
                }else{
                    mContext?.sendFirebaseEvents("style_selected_${styleName.getFormattedString()}")
                }

                onUpdateStyle?.invoke(isFromEdit, styleName)
            } else {
                if (Constants.PREMIUM_STYLES.contains(styleName)) {
                    premiumLauncher.launch(Intent(mContext, PremiumActivity::class.java))
                } else {
                    if (isFromEdit){
                        mContext?.sendFirebaseEvents("edit_prompt_style_selected_${styleName.getFormattedString()}")
                    }else{
                        mContext?.sendFirebaseEvents("style_selected_${styleName.getFormattedString()}")
                    }
                    onUpdateStyle?.invoke(isFromEdit, styleName)
                }
            }
        }
        if (!Constants.PREMIUM_STYLES.contains(styleName)) {
            this.dismiss()
        } else if (requireActivity().isPremium()) {
            this.dismiss()
        }
    }

    private fun String.getFormattedString(): String {
        return this.replace("\\s".toRegex(), "_").toLowerCase(Locale.ROOT)
    }

    private var premiumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == AppCompatActivity.RESULT_OK) {
                onUpdateStyle?.invoke(isFromEdit, selectStyleName)
                dismiss()
            }
        }

    companion object {
        @JvmStatic
        fun newInstance(fromEdit: Boolean, type: String, value: String, name: String) =
            StyleBottomFragment().apply {
                arguments = Bundle().apply {
                    putBoolean(Constants.ARG_IS_FROM_EDIT, fromEdit)
                    putString(Constants.ARG_STYLE_TYPE, type)
                    putString(Constants.ARG_STYLE_VALUE, value)
                    putString(Constants.ARG_STYLE_NAME, name)
                }
            }
    }
}
