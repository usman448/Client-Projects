package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.databaseHelper
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentDiscardBottomBinding
import ai.art.generator.aiart.artavatar.viewmodel.HistoryViewModel
import androidx.fragment.app.activityViewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

private const val ARG_SESSION_ID = "session_id"

class DiscardBottomFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentDiscardBottomBinding
    private val historyViewModel: HistoryViewModel by activityViewModels()
    private var historySessionId: Int? = null
    var onDeleteClick: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDiscardBottomBinding.inflate(inflater, container, false)
        historySessionId = arguments?.getInt(ARG_SESSION_ID)

        clickListeners()

        return binding.root
    }

    private fun clickListeners() {

        binding.cancelButton.setOnClickListener {
            dismiss()
        }

        binding.doneButton.setOnClickListener {
            historySessionId?.let {
                historyViewModel.deleteSessionRecord(it, databaseHelper)
            }
            dismiss()
        }
    }


    companion object {
        fun newInstance(session_id: Int): DiscardBottomFragment {
            val fragment = DiscardBottomFragment()
            val args = Bundle()
            args.putInt(ARG_SESSION_ID, session_id)
            fragment.arguments = args
            return fragment
        }
    }
}