package ai.art.generator.aiart.artavatar.views.fragments

import ai.art.generator.aiart.artavatar.adapter.LanguageAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentLanguageBinding
import ai.art.generator.aiart.artavatar.model.LanguageModel
import ai.art.generator.aiart.artavatar.model.SharedPreferenceHelper
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Constants.themeChange
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.setAppLocale
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import ai.art.generator.aiart.artavatar.views.activity.SplashActivity
import ai.art.generator.aiart.artavatar.views.activity.UserScreenNavigationState
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX

class LanguageFragment : Fragment(), LanguageAdapter.OnItemClickListener {

    private lateinit var binding: FragmentLanguageBinding
    private var fromSplash: Boolean = false
    private lateinit var adapter: LanguageAdapter
    private lateinit var language: LanguageModel
    private var mContext: Context? = null
    private lateinit var onBackPressedCallback: OnBackPressedCallback

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    private fun clickListeners() {
        binding.doneBtn.setOnClickListener {
            if (!::language.isInitialized) return@setOnClickListener

            // Disable button to prevent double tap
            binding.doneBtn.isEnabled = false

            showLanguageInterThenClose {
                val act = activity ?: run {
                    binding.doneBtn.isEnabled = true
                    return@showLanguageInterThenClose
                }

                // ✅ FIX: Main thread pe run karo — ad close ke baad activity
                // background mein hoti hai, isliye Handler(Main) zaroori hai
                Handler(Looper.getMainLooper()).post {

                    // ✅ FIX: Fragment aur activity ka state dobara check karo
                    // kyunki ad show hone ke dauran state change ho sakta hai
                    if (!isAdded || !isResumed) {
                        binding.doneBtn.isEnabled = true
                        return@post
                    }

                    val currentAct = activity ?: run {
                        binding.doneBtn.isEnabled = true
                        return@post
                    }

                    if (currentAct.isFinishing || currentAct.isDestroyed) {
                        binding.doneBtn.isEnabled = true
                        return@post
                    }

                    try {
                        SharedPreferenceHelper.setAppLanguage(requireContext(), language.title)
                        setAppLocale(language.code)

                        if (currentAct is SplashActivity) {
                            // Coming from onboarding flow → go to Premium screen
                            currentAct.startActivity(
                                Intent(currentAct, PremiumActivity::class.java).apply {
                                    putExtra("FROM_ONBOARDING", true)
                                    // ✅ FIX: Flags add kiye taaki back stack clean ho
                                    // aur app dobara crash na ho
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                }
                            )
                            currentAct.finish()
                        } else {
                            // Coming from Settings → just pop back
                            themeChange = true
                            parentFragmentManager.popBackStack()
                        }
                    } catch (e: Exception) {
                        // ✅ FIX: Koi bhi unexpected crash catch karo
                        // aur button re-enable karo
                        e.printStackTrace()
                        binding.doneBtn.isEnabled = true
                    }
                }
            }
        }

        binding.backButtonImageView.setOnClickListener {
            val act = activity ?: return@setOnClickListener
            if (act.isFinishing || act.isDestroyed) return@setOnClickListener

            if (act is MainActivity) {
                Constants.userMovingScreenState = UserScreenNavigationState.MAIN_TO_SETTING.label
                showLanguageInterThenClose {
                    // ✅ FIX: Yahan bhi Handler(Main) use karo
                    Handler(Looper.getMainLooper()).post {
                        if (!isAdded || activity == null) return@post
                        val currentAct = activity ?: return@post
                        if (currentAct.isFinishing || currentAct.isDestroyed) return@post
                        themeChange = false
                        parentFragmentManager.popBackStack()
                    }
                }
            } else {
                act.finish()
            }
        }
    }

    companion object {
        private const val ARG_FROM_SPLASH = "from_splash"
        fun newInstance(fromSplash: Boolean) = LanguageFragment().apply {
            arguments = Bundle().apply { putBoolean(ARG_FROM_SPLASH, fromSplash) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fromSplash = arguments?.getBoolean(ARG_FROM_SPLASH, false) ?: false

        onBackPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (requireActivity() is MainActivity) {
                    Constants.userMovingScreenState =
                        UserScreenNavigationState.MAIN_TO_SETTING.label
                    parentFragmentManager.popBackStack()
                } else {
                    requireActivity().finish()
                }
            }
        }

        requireActivity().onBackPressedDispatcher.addCallback(this, onBackPressedCallback)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLanguageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!fromSplash) {
            // Coming from Settings → load settings-specific ads
            AdsManagerX.loadNativeAd(
                viewLifecycleOwner,
                AdConfigManager.SETTINGS_LANGUAGE_NATIVE,
                binding.langNativeAdContainer
            )
            AdsManagerX.loadInterAd(
                viewLifecycleOwner,
                AdConfigManager.SETTINGS_LANGUAGE_INTER
            )
        } else {
            // Coming from Splash onboarding flow → load splash-specific ads
            AdsManagerX.loadNativeAd(
                viewLifecycleOwner,
                AdConfigManager.NATIVE_AD_LANGUAGE,
                binding.langNativeAdContainer
            )
            AdsManagerX.loadInterAd(
                viewLifecycleOwner,
                AdConfigManager.LANGUAGE_INTER_SPLASH_FALLBACK
            )
        }

        setupRecyclerView()
        clickListeners()
    }

    // -----------------------------------------------------------------------
    // Shows the appropriate interstitial ad before calling onClose().
    // For splash flow  : uses LANGUAGE_INTER_SPLASH_FALLBACK.
    // For settings flow: uses SETTINGS_LANGUAGE_INTER.
    // -----------------------------------------------------------------------
    private fun showLanguageInterThenClose(onClose: () -> Unit) {

        val act = activity as? AppCompatActivity

        if (act == null || act.isFinishing || act.isDestroyed) {
            onClose()
            return
        }

        val adConfig = if (fromSplash) {
            AdConfigManager.LANGUAGE_INTER_SPLASH_FALLBACK
        } else {
            AdConfigManager.SETTINGS_LANGUAGE_INTER
        }

        // Guard — onClose sirf ek baar call ho
        var isCallbackCalled = false

        val safeCallback = Runnable {
            if (isCallbackCalled) return@Runnable
            isCallbackCalled = true
            // ✅ FIX: callback hamesha main thread pe fire karo
            Handler(Looper.getMainLooper()).post {
                onClose()
            }
        }

        if (AdsManagerX.isInterAdLoaded(adConfig)) {
            AdsManagerX.showInterAd(
                act,
                adConfig,
                { safeCallback.run() },
                { safeCallback.run() }
            )
        } else {
            // Ad load nahi hui → directly proceed
            safeCallback.run()
        }
    }

    private fun setupRecyclerView() {
        mContext?.let {
            val langArray = Constants.LANGUAGES
            val getAppLanguage = SharedPreferenceHelper.getAppLanguage(it)
            var index = langArray.indexOf(getAppLanguage)
            if (index == -1) index = 0

            language = Helper.getLanguagesList()[index]

            adapter = LanguageAdapter(it, Helper.getLanguagesList(), index)
            adapter.setOnItemClickListener(this)

            binding.languageRecyclerView.adapter = adapter
            binding.languageRecyclerView.layoutManager = LinearLayoutManager(it)
            binding.languageRecyclerView.smoothScrollToPosition(index)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        try {
            if (!fromSplash) {
                AdsManagerX.destroyNativeAd(AdConfigManager.SETTINGS_LANGUAGE_NATIVE)
                AdsManagerX.destroyInterAd(AdConfigManager.SETTINGS_LANGUAGE_INTER)
            } else {
                AdsManagerX.destroyNativeAd(AdConfigManager.NATIVE_AD_LANGUAGE)
                AdsManagerX.destroyInterAd(AdConfigManager.LANGUAGE_INTER_SPLASH_FALLBACK)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDetach() {
        onBackPressedCallback.remove()
        super.onDetach()
    }

    override fun onItemClick(languageModel: LanguageModel) {
        language = languageModel
    }
}