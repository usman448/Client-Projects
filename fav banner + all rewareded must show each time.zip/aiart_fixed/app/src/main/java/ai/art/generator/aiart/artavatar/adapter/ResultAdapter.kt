package ai.art.generator.aiart.artavatar.adapter

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ResultItemBinding
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.utilities.Helper
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.facebook.shimmer.ShimmerFrameLayout
import com.hm.admanagerx.isPremium

class ResultAdapter(private val context: Context, val viewPager: ViewPager2) : RecyclerView.Adapter<ResultAdapter.ViewHolder>() {

    private var onItemClickListener: OnItemClickListener? = null

    private var selectedItemPosition = -1

    private var items: MutableList<HistoryModel> = arrayListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: ViewDataBinding = ResultItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        if (context.isPremium()) {
            holder.refresh.visibility = View.GONE
        } else {
            holder.refresh.visibility = View.VISIBLE
        }
        holder.bind(item)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    fun setCurrentItemPosition(position: Int) {
        selectedItemPosition = position
        // Post the operation to the main thread to execute on the next frame
        Handler(Looper.getMainLooper()).post {
            notifyItemRangeChanged(position - 1, 3)
        }
    }

    fun setData(list: MutableList<HistoryModel>) {
        this.items = list
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onItemClick(url: String)
        fun onPremiumClick()
    }


    inner class ViewHolder(binding: ViewDataBinding) : RecyclerView.ViewHolder(binding.root) {

        private val imageView: ImageView = binding.root.findViewById(R.id.result_image)
        val refresh: ImageView = binding.root.findViewById(R.id.refresh)
        private val shimmerFrameLayout = binding.root.findViewById<ShimmerFrameLayout>(R.id.result_shimmer)

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClickListener?.onItemClick(items[position].imageUrl)
                }
            }

            refresh.setOnClickListener {
                onItemClickListener?.onPremiumClick()
            }

        }

        fun bind(item: HistoryModel) {

            if ((item.height == "1024" && item.width == "1024") || (item.height == "512" && item.width == "512")) {
                imageView.scaleType = ImageView.ScaleType.CENTER_CROP
            }
            shimmerFrameLayout.startShimmer()
            //Log.i("ViewPagerWidthInfo", "bind: ${viewPager.display.width}   // ${viewPager.display.height}")
            //viewPager.layoutParams.height = viewPager.width
            //viewPager.layoutParams.width = viewPager.height
            //val width = (item.height.toInt() * Helper.getAspectRatio(width = item.width.toInt(), height = item.height.toInt())).toInt()
            //val height = (width / Helper.getAspectRatio(width = item.width.toInt(), height = item.height.toInt())).toInt()


            /*val heightViewpager = viewPager.display.height
            val viewPagerWidth = viewPager.display.width
            if(heightViewpager > viewPagerWidth){
                val layoutParams = viewPager.layoutParams
                layoutParams.width = viewPager.width
                layoutParams.height = viewPager.width // Set height to match the width
                viewPager.layoutParams = layoutParams
            }*/

            Log.i("ViewPagerWidthInfo", "bind:  after change: ${viewPager.width}   // ${viewPager.height}")

            Helper.loadWithRetry(
                context,
                imageView,
                item.imageUrl,
                item.height.toInt(),
                item.width.toInt(),
                shimmerFrameLayout,
                adapterPosition == 0
            )
        }



        /*fun loadImageWithFixedHeight(
            imageUrl: String, imageView: ImageView, aspectRatio: Float, height: Int, @DrawableRes placeholder: Int = R.drawable.placeholder, thumbnailUrl: String = "",
            radius: Float = 8f
        ) {
            val width = (height * aspectRatio).toInt()
            loadImageInto(imageUrl, imageView, width, height, placeholder, thumbnailUrl = thumbnailUrl, radius = radius)
        }
        fun loadImageWithFixedWidth(imageUrl: String, imageView: ImageView, aspectRatio: Float, width: Int, @DrawableRes placeholder: Int = R.drawable.placeholder, thumbnailUrl: String = "") {
            val height = (width / aspectRatio).toInt()
            loadImageInto(imageUrl, imageView, width, height, placeholder, thumbnailUrl= thumbnailUrl)
        }*/
    }
}
