package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ImageSettingsBottomSheetBinding
import ai.art.generator.aiart.artavatar.storage.ImageTypePreferences
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.setPadding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium

class ImageSettingsBottomSheet : BottomSheetDialogFragment() {
    private lateinit var binding: ImageSettingsBottomSheetBinding
    private lateinit var previousView: TextView
    private lateinit var currentView: TextView
    private var mContext: Context? = null
    private lateinit var imageTypePreferences: ImageTypePreferences

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }
    override fun onResume() {
        super.onResume()
        showBanner()
    }
    private fun showBanner() {

        if (requireContext().isPremium()) return

        val adConfigManager = AdConfigManager.BANNER_AD_IMG_TYPE
        val container = binding.containerAdStartBannerBottomForImgType

        if (AdsManagerX.isBannerAdLoaded(adConfigManager)) {

            AdsManagerX.showBannerAd(
                adConfigManager = adConfigManager,
                nativeAdContainer = container
            )

        } else {

            AdsManagerX.loadBannerAd(
                lifecycleOwner = this,
                adConfigManager = adConfigManager,
                bannerAdContainer = container
            )
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ImageSettingsBottomSheetBinding.inflate(inflater, container, false)
        imageTypePreferences = ImageTypePreferences(requireContext())
        currentView = when (imageTypePreferences.getImageTypePreferences()) {
            "PNG" -> {
                binding.png
            }

            "JPG" -> {
                binding.jpg
            }

            "WEBP" -> {
                binding.webp
            }

            else -> {
                binding.jpg
            }
        }
        previousView = currentView

        updateUI()
        clickListeners()

        return binding.root
    }

    private fun clickListeners() {
        binding.jpg.setOnClickListener {
            currentView = binding.jpg
            updateUI()
        }

        binding.png.setOnClickListener {
            currentView = binding.png
            updateUI()
        }

        binding.webp.setOnClickListener {
            currentView = binding.webp
            updateUI()
        }

        binding.cancelButton.setOnClickListener {
            dismiss()
        }

        binding.doneButton.setOnClickListener {
            mContext?.sendFirebaseEvents("settings_image_type_done_btn_clicked")
            //mContext?.sendFirebaseEvents("image_type", Bundle().apply { putString("image_type", currentView.text.toString()) })
            imageTypePreferences.saveImageTypePreferences(currentView.text.toString())
            dismiss()
        }
    }

    private fun updateUI() {
        mContext?.let { previousView.background =
            AppCompatResources.getDrawable(it, R.drawable.ic_unselect_image_setting)
            previousView.setCompoundDrawablesRelativeWithIntrinsicBounds(
                null,
                null,
                AppCompatResources.getDrawable(it, R.drawable.unchecked_btn),
                null
            )
            previousView.setPadding(Helper.spToPx(it, 18F))

            currentView.background = AppCompatResources.getDrawable(it, R.drawable.ic_select_image_setting)
            currentView.setCompoundDrawablesRelativeWithIntrinsicBounds(
                null,
                null,
                AppCompatResources.getDrawable(it, R.drawable.checked),
                null
            )
            currentView.setPadding(Helper.spToPx(it, 18F))

            previousView = currentView }
        
    }
}