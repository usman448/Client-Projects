package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.utilities.isMainActivityRunning
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class NotiRedirectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (isMainActivityRunning) {
            finish()
        } else {
            startActivity(Intent(this, SplashActivity::class.java))
            finish()
        }
    }
}