package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentSelectThemeItemBottomBinding
import ai.art.generator.aiart.artavatar.storage.ThemePreferences
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import android.app.Dialog
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.content.res.AppCompatResources
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium

class SelectThemeBottomFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentSelectThemeItemBottomBinding
    private var mContext: Context? = null
    private var selectTheme = ""
    private lateinit var themePreferences: ThemePreferences

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val context =
            mContext ?: throw IllegalStateException("mContext is null, cannot create dialog")

        return BottomSheetDialog(context, theme).apply {
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.peekHeight = context.resources.displayMetrics.heightPixels
        }
    }

    private fun showBanner() {
        if (requireContext().isPremium()) return

        val adConfigManager = AdConfigManager.BANNER_AD_IMG_TYPE
        val container = binding.containerAdStartBannerBottom

        if (AdsManagerX.isBannerAdLoaded(adConfigManager)) {
            AdsManagerX.showBannerAd(
                adConfigManager = adConfigManager,
                nativeAdContainer = container
            )
        } else {
            AdsManagerX.loadBannerAd(
                lifecycleOwner = this,
                adConfigManager = adConfigManager,
                bannerAdContainer = container
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentSelectThemeItemBottomBinding.inflate(inflater, container, false)
        themePreferences = ThemePreferences(requireContext())
        clickListeners()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        showBanner()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        when (themePreferences.getThemePreferences()) {
            AppCompatDelegate.MODE_NIGHT_NO -> adjustSelectThemeView(
                SelectedTheme.LIGHT_THEME.label,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                ),
                null,
                null
            )

            AppCompatDelegate.MODE_NIGHT_YES -> adjustSelectThemeView(
                SelectedTheme.DARK_THEME.label,
                null,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                ),
                null
            )

            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM -> adjustSelectThemeView(
                SelectedTheme.SYSTEM_THEME.label,
                null,
                null,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                )
            )
        }
    }

    private fun clickListeners() {
        binding.lightThemeImageview.setOnClickListener {
            adjustSelectThemeView(
                SelectedTheme.LIGHT_THEME.label,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                ),
                null,
                null
            )
        }

        binding.darkThemeImageview.setOnClickListener {
            adjustSelectThemeView(
                SelectedTheme.DARK_THEME.label,
                null,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                ),
                null
            )
        }

        binding.systemDefaultThemeImageview.setOnClickListener {
            adjustSelectThemeView(
                SelectedTheme.SYSTEM_THEME.label,
                null,
                null,
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.ic_multi_border_tutorial
                )
            )
        }

        binding.doneButton.setOnClickListener {
            mContext?.sendFirebaseEvents("settings_app_theme_done_btn_clicked")
            when (selectTheme) {
                SelectedTheme.LIGHT_THEME.label -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    themePreferences.saveThemePreferences(AppCompatDelegate.MODE_NIGHT_NO)
                }

                SelectedTheme.DARK_THEME.label -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    themePreferences.saveThemePreferences(AppCompatDelegate.MODE_NIGHT_YES)
                }

                SelectedTheme.SYSTEM_THEME.label -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    themePreferences.saveThemePreferences(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                }
            }
            this.dismiss()
        }

        binding.cancelButton.setOnClickListener {
            dismiss()
        }
    }

    private fun adjustSelectThemeView(
        selectThemeLabel: String,
        lightTheme: Drawable?,
        darkTheme: Drawable?,
        systemDefault: Drawable?
    ) {
        selectTheme = selectThemeLabel
        binding.lightThemeImageview.background = lightTheme
        binding.darkThemeImageview.background = darkTheme
        binding.systemDefaultThemeImageview.background = systemDefault
    }

    companion object {
        @JvmStatic
        fun newInstance() = SelectThemeBottomFragment()
    }
}

enum class SelectedTheme(val label: String) {
    LIGHT_THEME("Light Theme"),
    DARK_THEME("Dark Theme"),
    SYSTEM_THEME("System Theme")
}