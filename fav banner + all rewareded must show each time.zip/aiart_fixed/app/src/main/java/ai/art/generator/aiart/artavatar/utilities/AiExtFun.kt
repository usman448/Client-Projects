package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.R
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.util.TypedValue
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

var isMainActivityRunning = false
fun convertCommaStringToList(input: String): ArrayList<String> {
    return input.split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() } as ArrayList<String>
}

fun setAppLocale(languageCode: String) {
    val appLocale: LocaleListCompat = LocaleListCompat.forLanguageTags(languageCode)
    AppCompatDelegate.setApplicationLocales(appLocale)
}

fun Int.dpToPx(context: Context): Float {
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, this.toFloat(), context.resources.displayMetrics)
}

fun Int.pxToDp(context: Context): Float {
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, this.toFloat(), context.resources.displayMetrics)
}

var onPriceUpdate: ((String) -> Unit)? = null
fun Context.showSubscriptionDetailsDialog(): Dialog {
    val dialog = Dialog(this, R.style.Style_Dialog_Rounded_Corner)
    dialog.setCancelable(false)
    dialog.setContentView(R.layout.dialog_subscription_details)
    val tvPrice: TextView = dialog.findViewById(R.id.tv_bullet_3_text)
    val tvOK: TextView = dialog.findViewById(R.id.tv_okBtn)

    onPriceUpdate={
        tvPrice.text = it
    }
    tvOK.setOnClickListener {
        (this as Activity).hideSystemUI()
        dialog.dismiss()
    }
    dialog.setOnCancelListener {
        (this as Activity).hideSystemUI()
    }
    dialog.setCancelable(false)
    return dialog
}

fun Activity.transparentStatusBar() {
    val window: Window = window
    val winParams: WindowManager.LayoutParams = window.attributes
    winParams.flags = winParams.flags and WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS.inv()
    window.attributes = winParams
    window.decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
}

fun Activity.statusBarAndNavBarColourChanger(colour: Int, useLightStatusBar: Boolean) {
    val window: Window = window
    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
    window.statusBarColor = ContextCompat.getColor(this, colour)
    window.navigationBarColor = ContextCompat.getColor(this, colour)
    val compat = WindowInsetsControllerCompat(window, window.decorView)
    compat.isAppearanceLightStatusBars = useLightStatusBar
}

fun Activity.hideSystemUI() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    WindowInsetsControllerCompat(
        window,
        window.decorView.findViewById(android.R.id.content)
    ).let { controller ->
        controller.hide(WindowInsetsCompat.Type.navigationBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}
