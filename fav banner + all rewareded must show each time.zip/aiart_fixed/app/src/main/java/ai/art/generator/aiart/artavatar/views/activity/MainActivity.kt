package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.ShowcaseAdapter
import ai.art.generator.aiart.artavatar.databinding.ActivityMainBinding
import ai.art.generator.aiart.artavatar.inappupdatemanager.InAppUpdateUtil.checkForUpdate
import ai.art.generator.aiart.artavatar.inappupdatemanager.InAppUpdateUtil.registerUpdateListener
import ai.art.generator.aiart.artavatar.inappupdatemanager.InAppUpdateUtil.resumeUpdate
import ai.art.generator.aiart.artavatar.model.GenerateModel
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.model.RequestModel
import ai.art.generator.aiart.artavatar.model.ShowcaseItem
import ai.art.generator.aiart.artavatar.storage.ImageCreditPreferences
import ai.art.generator.aiart.artavatar.storage.ThemePreferences
import ai.art.generator.aiart.artavatar.utilities.AppX
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.databaseHelper
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.isForceUpdate
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Constants.userMovingScreenState
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.hideKeyboard
import ai.art.generator.aiart.artavatar.utilities.Helper.isNetworkAvailable
import ai.art.generator.aiart.artavatar.utilities.Helper.loadStyleImage
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.setStylePrompt
import ai.art.generator.aiart.artavatar.utilities.Helper.showKeyboard
import ai.art.generator.aiart.artavatar.utilities.Helper.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.Helper.spToPx
import ai.art.generator.aiart.artavatar.utilities.Helper.styleImagesX
import ai.art.generator.aiart.artavatar.utilities.Singleton
import ai.art.generator.aiart.artavatar.utilities.TutorialView
import ai.art.generator.aiart.artavatar.utilities.isMainActivityRunning
import ai.art.generator.aiart.artavatar.utilities.notiReminder
import ai.art.generator.aiart.artavatar.utilities.printIt
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.viewmodel.LoaderViewModel
import ai.art.generator.aiart.artavatar.viewmodel.MainViewModel
import ai.art.generator.aiart.artavatar.views.dialoguefragments.AspectRationFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.BottomSheetFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.ErrorBottomSheet
import ai.art.generator.aiart.artavatar.views.dialoguefragments.LoaderBottomFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.NoInternetFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.ShowcaseItemBottomFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.StyleBottomFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.TagsFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.onAdvanceDismissListener
import ai.art.generator.aiart.artavatar.views.dialoguefragments.onUpdateModel
import ai.art.generator.aiart.artavatar.views.dialoguefragments.onUpdateStyle
import ai.art.generator.aiart.artavatar.views.fragments.HistoryFragment
import ai.art.generator.aiart.artavatar.views.fragments.ResultFragment
import ai.art.generator.aiart.artavatar.views.fragments.SettingsFragment
import android.Manifest
import android.app.UiModeManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import androidx.core.widget.NestedScrollView
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import ai.art.generator.aiart.artavatar.utilities.RapidClicker
import ai.art.generator.aiart.artavatar.views.dialoguefragments.WatchAdDialog
import androidx.activity.result.ActivityResult
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.material.shape.CornerFamily
import com.google.android.material.shape.ShapeAppearanceModel
import com.google.android.material.textview.MaterialTextView
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium
import com.hm.admanagerx.utility.HandlerX
import com.hm.admanagerx.utility.TinyDB
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent.setEventListener
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener
import recovermessages.restoredeleteddata.recoverdata.notifyme.inappupdatemanager.UpdateScreenEnum

class MainActivity : AppCompatActivity(), View.OnClickListener,
    ShowcaseAdapter.OnItemClickListener {
    lateinit var binding: ActivityMainBinding
    private val TAG_ADS = "AdsLog_MainActivity"

    //    private var adsConsentManagerX: AdsConsentManagerX? = null
    private lateinit var viewModel: MainViewModel
    private lateinit var loaderViewModel: LoaderViewModel
    private lateinit var bottomSheetViewModel: BottomSheetVM
    private lateinit var requestObject: RequestModel
    private var loaderBottomFragment: LoaderBottomFragment? = null
    private lateinit var adapter: ShowcaseAdapter

    private var isTags: Boolean = false
    private var previousSelectedView: TextView? = null
    private lateinit var noInternetFragment: NoInternetFragment
    private var saveClickCounter = 0
    private var statusBarColorX: Int = 0
    private var doubleBackToExitPressedOnce = false
    private var tags: String = ""
    private var style: String = ""
    private var newModelPromptText: String = ""
    private var lastSelectModel = "stable-diffusion-v1-6"

    private var isNativeAdLoaded = false
    private var isNativeAdLoading = false
    private var generateModel: GenerateModel = GenerateModel()
    private var mainNativeAd: NativeAd? = null
    private lateinit var imageCreditPreferences: ImageCreditPreferences
    private val rapidClicker: RapidClicker = RapidClicker(1000)

    companion object {
        const val TAG = "MainActivityInfo"
    }

    override fun onStart() {
        super.onStart()
        // its for notification click redirect activity see in Notification RedirectActivity
        isMainActivityRunning = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loaderBottomFragment?.dismissAllowingStateLoss()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!isPremium()) {
            loadNativeAdForExitDialog()
            loadAds()
            loadNativeAdIfNeeded()
        }
        //change status bar color
        statusBarColorX = window.statusBarColor
        window.statusBarColor = ContextCompat.getColor(this, R.color.activity_bg_color)

        viewModel = ViewModelProvider(this@MainActivity)[MainViewModel::class.java]
        loaderViewModel = ViewModelProvider(this)[LoaderViewModel::class.java]
        imageCreditPreferences = ImageCreditPreferences(this)
        changeStatusBarIconVisibility()
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        hideKeyboard(this)

        Log.e("------>", "onCreate")

        sendFirebaseEvents("main_screen_displayed")

        clearFragmentFromBackStack()  // remove all fragments from stack when its create or recreate on apply theme
        observers()
        setUIAdapters()
        clickListeners()
        setupRecyclerView()
        checkForUpdateAvailable()
        supportActionBar?.setDisplayShowTitleEnabled(false)
        noInternetFragment = NoInternetFragment()

        if (!isNetworkAvailable() && !Constants.themeChange) {
            Singleton.setIsInternetAvailable(false)
            noInternetFragment.isCancelable = true
            noInternetFragment.show(supportFragmentManager, noInternetFragment.tag)
        } else {
            Singleton.setIsInternetAvailable(true)
        }

        if (!TinyDB.getInstance(this).getBoolean("notShowTutorial")) {
            lifecycleScope.launch {
                delay(1500)
                startTutorial()
            }
        }

        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startNotAlarmManager()
        }

        //when theme is change and activity is recreate then
        Log.i("userMovingInfo", "onCreate: $userMovingScreenState")
        when (userMovingScreenState) {
            UserScreenNavigationState.MAIN_TO_HISTORY.label -> {
                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY.label
                val historyFragment: HistoryFragment = HistoryFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, historyFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            UserScreenNavigationState.MAIN_TO_HISTORY_TO_RESULT.label -> {
                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY_TO_RESULT.label
                val historyFragment: HistoryFragment = HistoryFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, historyFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            UserScreenNavigationState.MAIN_TO_SETTING.label -> {
                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_SETTING.label
                val settingsFragment: SettingsFragment = SettingsFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, settingsFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            UserScreenNavigationState.MAIN_TO_SETTING_TO_LANGUAGE.label -> {
                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_SETTING_TO_LANGUAGE.label
                val settingsFragment: SettingsFragment = SettingsFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, settingsFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            UserScreenNavigationState.MAIN_TO_RESULT.label -> {
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_RESULT.label
                val resultFragment: ResultFragment =
                    ResultFragment.newInstance(false, Constants.sessionID, Constants.imageUrl)
                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, resultFragment)
                transaction.addToBackStack(null)
                transaction.commitAllowingStateLoss()
            }
        }

        binding.promptInput.clearFocus()
        binding.edittext.requestFocus()
    }


    //ars
    private fun loadNativeAdIfNeeded() {
        if (isNativeAdLoaded || isNativeAdLoading || isPremium()) return
        isNativeAdLoading = true
        AdsManagerX.loadNativeAd(
            this,
            adConfigManager = AdConfigManager.HOME_NATIVE_IN_BETWEEN,
            null,
            onAdLoaded = {
                isNativeAdLoading = false
                isNativeAdLoaded = true
                if (::adapter.isInitialized) adapter.notifyDataSetChanged()
            }
        )
    }

    fun loadRewAd() {
        Log.d(TAG_ADS, "Attempting to load Rewarded Ad...")
        AdsManagerX.loadRewardedAd(
            lifecycleOwner = this,
            adConfigManager = AdConfigManager.REWARDED_AD_GENERATE,
            onAdLoaded = {
                Log.d(TAG_ADS, "Rewarded Ad successfully loaded and ready to show.")

                AdsManagerX.showRewardedAd(
                    activity = this@MainActivity,
                    adConfigManager = AdConfigManager.REWARDED_AD_GENERATE,
                    onUserEarnedRewarded = { rewardItem ->
                        // --- REWARD LOGGING ---
                        Log.i(TAG_ADS, "REWARD GRANTED: Video Finished.")
                        Log.i(
                            TAG_ADS,
                            "Reward details: Type=${rewardItem.type}, Amount=${rewardItem.amount}"
                        )

                        // RESET CREDITS: If the user watches an ad, we reset their count to 0
                        // so they can use the app again until they hit the limit.
                        imageCreditPreferences.saveImageCreditPreferences(0)
                        Log.d(TAG_ADS, "Credits have been reset to 0 in SharedPrefs.")
                    },
                    onAdClose = {
                        Log.d(TAG_ADS, "Ad Closed by user. Proceeding to generation...")
                        generateImage()
                    }
                )

            },
            onAdFailed = { error ->
                Log.e(TAG_ADS, "Rewarded Ad failed to load: ${error.toString()}")
            }
        )
    }

    // Helper to keep the main function clean
    private fun showNoInternetDialog() {
        if (saveClickCounter++ == 0) {
            Singleton.setIsInternetAvailable(false)
            noInternetFragment.isCancelable = true
            noInternetFragment.show(supportFragmentManager, noInternetFragment.tag)
            Handler(Looper.getMainLooper()).postDelayed({ saveClickCounter = 0 }, 1000)
        }
    }

    // -----------------------------------------------------------------------
    // REQUIREMENT 2 — GENERATE BUTTON COIN SYSTEM
    //
    // This function is called every time the user taps the Generate button
    // (after the credit check in onClick → binding.generateButton).
    //
    // Flow:
    //   1. Check internet connection.
    //   2. If premium user → skip all coin checks, generate directly.
    //   3. If free user and credits < IMAGE_CREDIT_LIMIT → use one free credit.
    //   4. If credits exhausted → show rewarded ad or go premium.
    //
    // To change the number of free generates:
    //   → Go to Constants.kt → change IMAGE_CREDIT_LIMIT
    //
    // To change what happens after credits run out:
    //   → Go to Constants.kt → change GENERATE_IMAGE_STATE (0 / 1 / 2)
    // -----------------------------------------------------------------------
    private fun handleGenerateImage() {
        val currentCredits = imageCreditPreferences.getImageCreditPreferences()
        Log.d(TAG_ADS, "--- Generation Request Started ---")

        Log.d(
            TAG_ADS,
            "Current Status -> Credits: $currentCredits/${Constants.IMAGE_CREDIT_LIMIT}, Premium: ${isPremium()}"
        )

        // 1. Internet Check
        if (!isNetworkAvailable()) {
            Log.e(TAG_ADS, "Abort: No internet connection available.")
            showNoInternetDialog()
            return
        }

        // 2. Premium Bypass — premium users skip coin checks entirely.
        if (isPremium()) {
            Log.i(TAG_ADS, "Flow: Premium user detected. Bypassing ads.")
            generateImage()
            return
        }

        // 3. Free credit check.
        // If currentCredits is still below the limit, allow generation and
        // increment the counter. Once it reaches IMAGE_CREDIT_LIMIT, ads kick in.
        // To change the free generate limit → Constants.kt → IMAGE_CREDIT_LIMIT
        if (currentCredits < Constants.IMAGE_CREDIT_LIMIT) {
            val newCreditCount = currentCredits + 1
            imageCreditPreferences.saveImageCreditPreferences(newCreditCount)
            Log.i(
                TAG_ADS,
                "Flow: Using free credit ($newCreditCount/${Constants.IMAGE_CREDIT_LIMIT}). No ad required."
            )
            generateImage()
            return
        }

        // 4. Ad flow — coins exhausted, determine which ad to show.
        // Priority order: Rewarded Ad → Rewarded Interstitial → Emergency fallback.
        // After watching an ad, credits reset to 0 (inside onUserEarnedRewarded).
        Log.d(TAG_ADS, "Flow: Credits exhausted. Attempting to show Rewarded/Interstitial.")

        when {
            // Priority 1: Standard Rewarded Ad (user earns reward by watching fully).
            AdsManagerX.isRewardedAdLoaded(AdConfigManager.REWARDED_AD_GENERATE) -> {
                Log.d(TAG_ADS, "Ad Action: Showing standard Rewarded Ad.")
                AdsManagerX.showRewardedAd(
                    activity = this@MainActivity,
                    adConfigManager = AdConfigManager.REWARDED_AD_GENERATE,
                    onUserEarnedRewarded = { rewardItem ->
                        Log.i(TAG_ADS, "Reward: Standard Rewarded earned. Resetting credits.")
                        // Reset coin counter to 0 so user gets fresh free generates.
                        // To change how many free generates reset to → change the 0 here.
                        imageCreditPreferences.saveImageCreditPreferences(0)
                        sendFirebaseEvents("reward_earned_credits_reset")
                    },
                    onAdClose = {
                        Log.d(TAG_ADS, "Ad Event: Rewarded closed. Proceeding to generation.")
                        generateImage()
                    }
                )
            }

            // Priority 2: Rewarded Interstitial Ad (Fallback)
            AdsManagerX.isRewardedInterstitialAdLoaded(AdConfigManager.REWARDED_INTER_AD) -> {
                Log.d(
                    TAG_ADS,
                    "Ad Action: Standard Rewarded not ready. Showing Rewarded Interstitial."
                )
                AdsManagerX.showRewardedInterstitialAd(
                    activity = this@MainActivity,
                    adConfigManager = AdConfigManager.REWARDED_INTER_AD,
                    onUserEarnedRewarded = { rewardItem ->
                        Log.i(TAG_ADS, "Reward: Rewarded Interstitial earned. Resetting credits.")
                        // Reset coin counter to 0 so user gets fresh free generates.
                        // To change how many free generates reset to → change the 0 here.
                        imageCreditPreferences.saveImageCreditPreferences(0)
                        sendFirebaseEvents("reward_inter_earned_credits_reset")
                    },
                    funBlock = {
                        Log.d(
                            TAG_ADS,
                            "Ad Event: Rewarded Interstitial finished. Proceeding to generation."
                        )
                        generateImage()
                    }
                )
            }

            // Priority 3: Emergency Fallback (No ads ready)
            else -> {
                Log.w(
                    TAG_ADS,
                    "Ad Action: No ads loaded. Triggering background load and granting 1 free use."
                )
                // Try to load for next time
                loadRewAd()
                // Grant one generation so user isn't stuck
                generateImage()
            }
        }
    }

    private fun checkForUpdateAvailable() {
        checkForUpdate(
            fromScreen = UpdateScreenEnum.SPLASH_SCREEN.value,
            updateType = isForceUpdate,
            activityResultLauncher = activityResultLauncher
        )
        registerUpdateListener(binding.root)

    }

    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result: ActivityResult ->

            if (result.resultCode != RESULT_OK) {
                Log.d("Tag", "Update flow failed! Result code: " + result.resultCode)
            }
        }

    private fun clearFragmentFromBackStack() {
        val fragmentManager = supportFragmentManager
        val fragments = fragmentManager.fragments
        for (fragment in fragments) {
            fragmentManager.beginTransaction().remove(fragment).commit()
        }
        fragmentManager.popBackStack(
            null,
            FragmentManager.POP_BACK_STACK_INCLUSIVE
        ) // Clear back stack if needed
    }

    private fun changeStatusBarIconVisibility() {
        val themePreferences = ThemePreferences(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nightModeFlags: Int =
                resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            if (isDarkThemeOn()) {
                window.decorView.systemUiVisibility = 0
                when (themePreferences.getThemePreferences()) {
                    AppCompatDelegate.MODE_NIGHT_NO -> window.decorView.systemUiVisibility =
                        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                }
            } else {
                when (nightModeFlags) {
                    Configuration.UI_MODE_NIGHT_YES -> {
                        window.decorView.systemUiVisibility = 0
                    }

                    Configuration.UI_MODE_NIGHT_NO -> {
                        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    }

                    Configuration.UI_MODE_NIGHT_UNDEFINED -> {
                        window.decorView.systemUiVisibility = 0
                    }
                }
            }
        }
    }

    private fun isDarkThemeOn(): Boolean {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val uiMode = uiModeManager.nightMode
        return uiMode == UiModeManager.MODE_NIGHT_YES
    }

    private fun startNotAlarmManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Permissions.check(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
                null,
                object : PermissionHandler() {
                    override fun onGranted() {
                        notiReminder()
                    }
                })
        } else notiReminder()
    }


    private fun loadAds() {
        // ✅ FIX: Preload Rewarded Ad for Image Generation (ResultFragment uses this)
        AdsManagerX.loadRewardedAd(
            lifecycleOwner = this,
            adConfigManager = AdConfigManager.REWARDED_AD_GENERATE
        )

        // Row 10: Preload Rewarded Interstitial fallback for Image Generation
        AdsManagerX.loadRewardedInterstitialAd(
            lifecycleOwner = this,
            adConfigManager = AdConfigManager.REWARDED_INTER_AD
        )

        // Row 14: Preload Choose Model Ads
        AdsManagerX.loadRewardedAd(
            lifecycleOwner = this,
            adConfigManager = AdConfigManager.CHOOSE_MODEL_REWARDED
        )
        AdsManagerX.loadRewardedInterstitialAd(
            lifecycleOwner = this,
            adConfigManager = AdConfigManager.CHOOSE_MODEL_REWARDED_INTER
        )
    }

    // Row 14: Helper to show ad when choosing a model
    fun showChooseModelRewardedAd(onGranted: () -> Unit) {
        if (isPremium()) {
            onGranted()
            return
        }

        when {
            AdsManagerX.isRewardedAdLoaded(AdConfigManager.CHOOSE_MODEL_REWARDED) -> {
                AdsManagerX.showRewardedAd(
                    activity = this,
                    adConfigManager = AdConfigManager.CHOOSE_MODEL_REWARDED,
                    onUserEarnedRewarded = { onGranted() },
                    onAdClose = { /* Ad closed */ }
                )
            }

            AdsManagerX.isRewardedInterstitialAdLoaded(AdConfigManager.CHOOSE_MODEL_REWARDED_INTER) -> {
                AdsManagerX.showRewardedInterstitialAd(
                    activity = this,
                    adConfigManager = AdConfigManager.CHOOSE_MODEL_REWARDED_INTER,
                    onUserEarnedRewarded = { onGranted() },
                    funBlock = { onGranted() }
                )
            }

            else -> onGranted() // Fallback if no ad is loaded
        }
    }

    private fun setupRecyclerView() {

        val imageItems = Helper.showCaseList(this@MainActivity)
        val sublist = imageItems.subList(0, 9)
        adapter = ShowcaseAdapter(this@MainActivity)
        adapter.updateItems(sublist)
        adapter.setOnItemClickListener(this)

        val layoutManager = GridLayoutManager(this@MainActivity, 2)
        adapter.setSpanSizeLookup(layoutManager)

        binding.showcaseRecyclerview.layoutManager = layoutManager
        binding.showcaseRecyclerview.adapter = adapter
        var scroll = 0
        binding.nestedScrollView.setOnScrollChangeListener { _, scrollX, scrollY, oldScrollX, oldScrollY ->
            if (scrollY > oldScrollY) {
                scroll++
                if (scroll == 5) adapter.updateItems(imageItems.subList(10, 19))
                if (scroll == 15) adapter.updateItems(imageItems.subList(20, 29))
                if (scroll == 25) adapter.updateItems(imageItems.subList(30, 39))
                if (scroll == 35) adapter.updateItems(imageItems.subList(40, 49))
            }
            Log.i(TAG, "onBindViewHolder setupRecyclerView: $scroll")
        }
    }

    private fun setUIAdapters() {
        binding.digitalArtShimmer.startShimmer()
        binding.neonPunkShimmer.startShimmer()
        binding.colorSplashShimmer.startShimmer()
        binding.cosmosShimmer.startShimmer()
        binding.bizarreShimmer.startShimmer()
        loadStyleImage(
            applicationContext,
            binding.digitalArtImageview,
            "digital-art",
            binding.digitalArtShimmer
        )
        loadStyleImage(
            applicationContext,
            binding.colorSplashImageView,
            "color_splash",
            binding.colorSplashShimmer
        )
        loadStyleImage(
            applicationContext,
            binding.neonPunkImageView,
            "neon-punk",
            binding.neonPunkShimmer
        )
        loadStyleImage(applicationContext, binding.cosmosImageview, "cosmic", binding.cosmosShimmer)
        loadStyleImage(
            applicationContext,
            binding.bizarreImageview,
            "bizarre",
            binding.bizarreShimmer
        )
        //setUpStyle(getString(R.string.digitalArt))

        loadStyleImage(
            applicationContext,
            binding.modelImageview,
            styleImagesX(generateModel.modelName),
            binding.bizarreShimmer
        )

        binding.modelName.text = Helper.reformattedModelName(this, "stable-diffusion-v1-6")

        binding.promptInput.imeOptions = EditorInfo.IME_ACTION_DONE
        binding.promptInput.setRawInputType(
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        )

        previousSelectedView = binding.oneOne

        if (!TinyDB.getInstance(this@MainActivity).getBoolean("notShowTagTutorial")) {
            binding.tagTutorialTempView.visibility = View.VISIBLE
        }
    }

    private fun hidePremiumUI() {
        mainNativeAd?.destroy()

        binding.premium.visibility = View.GONE
        binding.btnAdText.visibility = View.GONE
        binding.nativeAdContainerForMain.visibility = View.GONE
    }

    private fun observers() {
        bottomSheetViewModel = ViewModelProvider(this)[BottomSheetVM::class.java]
    }

    private fun clickListeners() {

        binding.aspectRatioLayout.setOnClickListener {
            rapidClicker.publish {
                val aspectRationFragment = AspectRationFragment(generateModel.aspectRatio) {
                    generateModel.aspectRatio = it
                    binding.ratioValueTextview.text = it
                }
                aspectRationFragment.show(supportFragmentManager, aspectRationFragment.tag)
            }
        }

        // remove promptInput focus when keyboard close
        setEventListener(this, KeyboardVisibilityEventListener { isOpen ->

            if (!isOpen) {

                /*if (!binding.searchView.isIconified) {
                    binding.toolbarTitle.visibility = View.GONE
                }*/

                if (bottomSheetViewModel.tagsSelectionList.size > 0) return@KeyboardVisibilityEventListener
                binding.promptInput.clearFocus()
                showHintButton()
            } else {
                "doAfterTextChanged".printIt()
                if (supportFragmentManager.backStackEntryCount > 0) return@KeyboardVisibilityEventListener
                showTagButton()


            }
        })

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                binding.cross.visibility = View.VISIBLE
                if (s != null) {
                    if (s.isEmpty() || s == "") {
                        binding.cross.visibility = View.GONE
                    }
                    if (s.length <= 500) {
                        binding.wordCount.text = "${s.length}/500"
                    }
                } else {
                    binding.tagCountTxt.isVisible = false
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        }

        binding.promptInput.doAfterTextChanged {
            /*val isValueChangedByUser = binding.promptInput.hasFocus()
            if (isValueChangedByUser) {
                showTagButton()
            }*/
            //above code is comment to solved problem when focus on edittext without open keyboard its show tag button
        }
        binding.promptInput.addTextChangedListener(textWatcher)

        // Set up focus change listener to detect when the EditText loses focus
        binding.promptInput.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (!hasFocus && binding.promptInput.text.isNotEmpty()) {
                sendFirebaseEvents("main_prompt_entered")
            }
        }

        binding.advanceSettingsDropdown.setOnClickListener(this)
        binding.model.setOnClickListener(this)
        binding.oneOne.setOnClickListener(this)
        binding.fourThree.setOnClickListener(this)
        binding.threeTwo.setOnClickListener(this)
        binding.twoThree.setOnClickListener(this)
        binding.sixteenNine.setOnClickListener(this)
        binding.nineSixteen.setOnClickListener(this)
        binding.fiveFour.setOnClickListener(this)
        binding.fourFive.setOnClickListener(this)
        binding.threeOne.setOnClickListener(this)
        binding.threeFour.setOnClickListener(this)
        binding.seeAllLayout.setOnClickListener(this)
        binding.promptHint.setOnClickListener(this)
        binding.promptTag.setOnClickListener(this)
        binding.generateButton.setOnClickListener(this)
        binding.premium.setOnClickListener(this)
        binding.settings.setOnClickListener(this)
        binding.history.setOnClickListener(this)
        binding.promptInput.setOnClickListener(this)
        binding.cross.setOnClickListener(this)
        binding.premium.setOnClickListener(this)
        binding.tagTutorialTempView.setOnClickListener(this)

        binding.audio.setOnClickListener(this)
        binding.digitalArtLayout.setOnClickListener(this)
        binding.neonPunkLayout.setOnClickListener(this)
        binding.colorSplashLayout.setOnClickListener(this)
        binding.cosmosLayout.setOnClickListener(this)
        binding.bizarreLayout.setOnClickListener(this)

        /*val editText = binding.searchView.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
        editText.setTextColor(resources.getColor(R.color.black))
        editText.textSize = 16F
        editText.setPadding(50,0,0,0)

        binding.searchView.setOnQueryTextFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.toolbarTitle.visibility = View.GONE

            } else {
                binding.toolbarTitle.visibility = View.VISIBLE
            }
        }*/

    }

    private fun showHintButton() {
        isTags = false
        binding.promptTag.visibility = View.GONE
        binding.promptHint.visibility = View.VISIBLE
        binding.tagCountTxt.isVisible = false
    }

    private fun showTagButton() {
        isTags = true
        binding.tagCountTxt.isVisible = true
        binding.promptTag.visibility = View.VISIBLE
        binding.promptHint.visibility = View.GONE

        val text = binding.promptInput.text.toString()
        if (text.isEmpty() || text == "") {
            binding.cross.visibility = View.GONE
        }
    }

    override fun onClick(v: View?) {
        when (v) {

            binding.digitalArtLayout -> {
                sendFirebaseEvents("style_selected_digital_art")
                /*if(generateModel.style == getString(R.string.digitalArt)){
                    generateModel.style = "No style"
                }else{
                    generateModel.style = getString(R.string.digitalArt)
                }
                setUpStyle(generateModel.style)*/

                when (binding.digitalArtTextview.text) {
                    getString(R.string.digitalArt) -> generateModel.style =
                        getString(R.string.digitalArt)

                    generateModel.style -> generateModel.style = "No style"
                    else -> generateModel.style =
                        styleImagesX(binding.digitalArtTextview.text.toString())
                }
                setUpStyle(generateModel.style)
            }

            binding.cosmosLayout -> {
                sendFirebaseEvents("style_selected_cosmos")
                if (generateModel.style == getString(R.string.cosmosText)) {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = getString(R.string.cosmosText)
                }
                setUpStyle(generateModel.style)
            }

            binding.neonPunkLayout -> {
                sendFirebaseEvents("style_selected_neon_punk")
                if (generateModel.style == "Neon Punk") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Neon Punk"
                }
                setUpStyle(generateModel.style)
            }

            binding.colorSplashLayout -> {
                sendFirebaseEvents("style_selected_color_splash")
                if (generateModel.style == "Color Splash") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Color Splash"
                }
                setUpStyle(generateModel.style)
            }

            binding.bizarreLayout -> {
                sendFirebaseEvents("style_selected_bizarre")
                if (generateModel.style == "Bizarre") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Bizarre"
                }
                setUpStyle(generateModel.style)
            }

            binding.audio -> {
                sendFirebaseEvents("main_speech_icon_clicked")
                openVoiceToText()
            }

            binding.cross -> {
                sendFirebaseEvents("main_prompt_dismiss_icon_clicked")
                binding.promptInput.setText("")
            }

            binding.promptInput -> {
                binding.promptInput.clearFocus()
                binding.promptInput.requestFocus()
            }

            binding.inputLayout -> {
                binding.promptInput.requestFocus()
            }

            binding.tagTutorialTempView -> {
                Log.i(
                    TAG,
                    "setUIAdapters: isTagTutorial:${
                        TinyDB.getInstance(this@MainActivity).getBoolean("notShowTagTutorial")
                    }"
                )
                if (!TinyDB.getInstance(this@MainActivity).getBoolean("notShowTagTutorial")) {
                    startTutorial(3)
                }
                binding.promptInput.requestFocus()
                binding.tagTutorialTempView.isVisible = false
            }

            binding.advanceSettingsDropdown -> {
                rapidClicker.publish {
                    val bottomSheet = BottomSheetFragment.newInstance(
                        false,
                        generateModel.negative_prompt,
                        generateModel.negative_prompt_tags,
                        generateModel.cfgScale.toString(),
                        generateModel.deNoising,
                        generateModel.hdQuality
                    )
                    sendFirebaseEvents("advance_settings_clicked")
                    bottomSheet.show(supportFragmentManager, bottomSheet.tag)
                }
                onAdvanceDismissListener =
                    { fromEdit: Boolean, negPrompt: String, negTags: String, cfg: Int, deNoising: String, hd: String ->
                        if (!fromEdit) {
                            generateModel.negative_prompt = negPrompt
                            generateModel.negative_prompt_tags = negTags
                            generateModel.cfgScale = cfg
                            generateModel.deNoising = deNoising
                            generateModel.hdQuality = hd
                        }

                    }
            }

            binding.model -> {
                sendFirebaseEvents("main_choose_model_arrow_clicked")
                if (saveClickCounter++ == 0) {
                    rapidClicker.publish {
                        val bottomSheet = StyleBottomFragment.newInstance(
                            fromEdit = false,
                            type = "model",
                            value = lastSelectModel,
                            name = generateModel.modelName
                        )
                        bottomSheet.show(supportFragmentManager, bottomSheet.tag)
                    }

                    onUpdateModel = { fromEdit: Boolean, model: String ->
                        if (!fromEdit) {
                            lastSelectModel = model
                            val reformatNameToModelId = when (model) {
                                Constants.allModelNameList[0] -> {
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[1] -> {
                                    Constants.MODEL_IDS[1]
                                }

                                Constants.allModelNameList[2] -> {
                                    Constants.MODEL_IDS[2]
                                }

                                Constants.allModelNameList[3] -> {
                                    newModelPromptText = "generate a Cartoon image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[4] -> {
                                    newModelPromptText =
                                        "imagine Goku in a drip outfit. Epic background. Tatsuya Nagamine art-style,"
                                    Constants.MODEL_IDS[1]
                                }

                                Constants.allModelNameList[5] -> {
                                    newModelPromptText = "VIRTUAL REALITY DESIGN,"
                                    Constants.MODEL_IDS[1]
                                }

                                Constants.allModelNameList[6] -> {
                                    newModelPromptText = "generate a Real image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[7] -> {
                                    newModelPromptText =
                                        "extremely detailed illustration in anime style, cartoon, best resolution, best quality,"
                                    Constants.MODEL_IDS[2]
                                }

                                Constants.allModelNameList[8] -> {
                                    newModelPromptText = "An awe-inspiring alien cyborg image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[9] -> {
                                    newModelPromptText = "high quality, Generate real image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[10] -> {
                                    newModelPromptText = "a portrait image with solid background,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[11] -> {
                                    newModelPromptText = "modern disney diffusion,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[12] -> {
                                    newModelPromptText =
                                        "A dreamlike world where a super cute cartoon Goku baby roams,"
                                    Constants.MODEL_IDS[0]
                                }

                                else -> model
                            }
                            lastSelectModel = reformatNameToModelId
                            generateModel.model = reformatNameToModelId
                            Log.i(
                                TAG,
                                "onUpdateModel: $reformatNameToModelId   ${generateModel.model}  $model"
                            )
                            generateModel.modelName = model
                            binding.modelName.text = Helper.reformattedModelName(this, model)
                            loadStyleImage(
                                applicationContext,
                                binding.modelImageview,
                                styleImagesX(generateModel.modelName),
                                null
                            )
                        }
                    }
                    Handler(Looper.getMainLooper()).postDelayed({
                        saveClickCounter = 0
                    }, 1000)
                }

            }

            binding.oneOne -> {

                updateAspectRatios(binding.oneOne, "1:1", R.drawable.one_one)

                if (previousSelectedView != binding.oneOne) {
                    unselectAspectView()
                    previousSelectedView = binding.oneOne
                }
            }

            binding.fourThree -> {
                if (isPremium()) {
                    updateAspectRatios(binding.fourThree, "4:3", R.drawable.four_three)
                    if (previousSelectedView != binding.fourThree) {
                        unselectAspectView()
                        previousSelectedView = binding.fourThree
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.threeTwo -> {
                if (isPremium()) {
                    updateAspectRatios(binding.threeTwo, "3:2", R.drawable.three_two)

                    if (previousSelectedView != binding.threeTwo) {
                        unselectAspectView()
                        previousSelectedView = binding.threeTwo
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.twoThree -> {

                updateAspectRatios(binding.twoThree, "2:3", R.drawable.two_three)

                if (previousSelectedView != binding.twoThree) {
                    unselectAspectView()
                    previousSelectedView = binding.twoThree
                }

            }

            binding.sixteenNine -> {
                if (isPremium()) {
                    updateAspectRatios(binding.sixteenNine, "16:9", R.drawable.sixteen_nine)

                    if (previousSelectedView != binding.sixteenNine) {
                        unselectAspectView()
                        previousSelectedView = binding.sixteenNine
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.nineSixteen -> {
                if (isPremium()) {
                    updateAspectRatios(binding.nineSixteen, "9:16", R.drawable.nine_sixteen)

                    if (previousSelectedView != binding.nineSixteen) {
                        unselectAspectView()
                        previousSelectedView = binding.nineSixteen
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.fiveFour -> {
                if (isPremium()) {
                    updateAspectRatios(binding.fiveFour, "5:4", R.drawable.five_four)

                    if (previousSelectedView != binding.fiveFour) {
                        unselectAspectView()
                        previousSelectedView = binding.fiveFour
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.fourFive -> {
                if (isPremium()) {
                    updateAspectRatios(binding.fourFive, "4:5", R.drawable.four_five)

                    if (previousSelectedView != binding.fourFive) {
                        unselectAspectView()
                        previousSelectedView = binding.fourFive
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.threeOne -> {
                if (isPremium()) {
                    updateAspectRatios(binding.threeOne, "3:1", R.drawable.three_one)

                    if (previousSelectedView != binding.threeOne) {
                        unselectAspectView()
                        previousSelectedView = binding.threeOne
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.threeFour -> {
                if (isPremium()) {
                    updateAspectRatios(binding.threeFour, "3:4", R.drawable.three_four)

                    if (previousSelectedView != binding.threeFour) {
                        unselectAspectView()
                        previousSelectedView = binding.threeFour
                    }
                } else {
                    premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                }
            }

            binding.seeAllLayout -> {
                sendFirebaseEvents("main_choose_style_arrow_clicked")
                if (saveClickCounter++ == 0) {
                    rapidClicker.publish {
                        val bottomSheet = StyleBottomFragment.newInstance(
                            fromEdit = false,
                            type = "style",
                            value = generateModel.style,
                            name = generateModel.style
                        )
                        bottomSheet.show(supportFragmentManager, bottomSheet.tag)
                    }
                    onUpdateStyle = { fromEdit, style ->
                        Log.i(TAG, "onUpdateStyle: fromEdit:$fromEdit Style:$style")
                        if (!fromEdit) {
                            generateModel.style = style
                            setUpStyle(style)
                        }
                    }
                    Handler(Looper.getMainLooper()).postDelayed({
                        saveClickCounter = 0
                    }, 1000)
                }
            }

            binding.promptTag -> {
                sendFirebaseEvents("main_keywords_icon_clicked")
                rapidClicker.publish {
                    val bottomSheet = TagsFragment.newInstance(false, "")
                    bottomSheet.show(supportFragmentManager, bottomSheet.tag)
                    bottomSheet.onTagAdded = {
                        if (bottomSheetViewModel.tagsSelectionList.size > 0) showTagButton() else showHintButton()
                        binding.tagCountTxt.text = it
                    }
                }
            }

            binding.promptHint -> {
                sendFirebaseEvents("main_idea_icon_clicked")
                if (isTags) {
                    rapidClicker.publish {
                        val bottomSheet = TagsFragment.newInstance(false, "")
                        bottomSheet.show(supportFragmentManager, bottomSheet.tag)
                        bottomSheet.onTagAdded = {
                            if (bottomSheetViewModel.tagsSelectionList.size > 0) showTagButton() else showHintButton()
                            binding.tagCountTxt.text = it
                        }
                    }
                } else {
                    binding.promptInput.setText(Helper.promptHints().random())
                    binding.promptInput.setSelection(binding.promptInput.text.length)
                }
            }

            binding.generateButton -> {
                sendFirebaseEvents("main_generate_clicked")

                if (binding.promptInput.text.trim().isEmpty()) {
                    showSnackBar(
                        resources.getString(R.string.promptCannotBeEmpty),
                        binding.nativeAdContainerForMain
                    )
                }

                // -----------------------------------------------------------
                // REQUIREMENT 2 — GENERATE COINS ENTRY POINT
                //
                // This is the first credit check when the user taps Generate.
                // It reads the current coin count and decides what to do:
                //
                //   Premium user       → skip all checks, generate directly.
                //   Credits available  → increment counter, generate directly.
                //   Credits exhausted  → check GENERATE_IMAGE_STATE for next action.
                //
                // To change the number of free generates:
                //   → Constants.kt → IMAGE_CREDIT_LIMIT
                //   Example: IMAGE_CREDIT_LIMIT = 4 gives 5 free generates (0,1,2,3,4)
                //
                // To change what happens when credits run out:
                //   → Constants.kt → GENERATE_IMAGE_STATE
                //   0 = always allow  |  1 = watch ad dialog  |  2 = go premium
                // -----------------------------------------------------------
                val currentCredits = imageCreditPreferences.getImageCreditPreferences()

                if (isPremium()) {
                    handleGenerateImage()
                } else {
                    // User still has free credits remaining → use one and generate.
                    if (currentCredits < Constants.IMAGE_CREDIT_LIMIT) {
                        Log.d(
                            TAG_ADS,
                            "User is within free limit ($currentCredits/${Constants.IMAGE_CREDIT_LIMIT}). Incrementing."
                        )

                        // Increment the coin counter for this free use.
                        imageCreditPreferences.saveImageCreditPreferences(currentCredits + 1)
                        handleGenerateImage()
                    } else {
                        // Coins exhausted. Behaviour depends on GENERATE_IMAGE_STATE.
                        // To change this behaviour → Constants.kt → GENERATE_IMAGE_STATE
                        Log.w(
                            TAG_ADS,
                            "User hit credit limit. Forcing Ad or Premium. State: ${Constants.GENERATE_IMAGE_STATE}"
                        )

                        when (Constants.GENERATE_IMAGE_STATE) {
                            // 0 → Always allow generation (useful for testing or no-ad mode).
                            0 -> handleGenerateImage()
                            // 1 → Show "Watch Ad" dialog. User watches rewarded ad to continue.
                            1 -> {
                                val watchAdDialog = WatchAdDialog({ action ->
                                    if (action == getString(R.string.watchAd)) {
                                        Log.d(TAG_ADS, "User clicked 'Watch Ad' in dialog.")
                                        handleGenerateImage()
                                    }
                                }, "MainActivity")
                                watchAdDialog.show(supportFragmentManager, watchAdDialog.tag)
                            }
                            // 2 → Send user to Premium screen directly.
                            2 -> {
                                Log.d(TAG_ADS, "State 2: Redirecting to Premium.")
                                premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
                            }

                            else -> handleGenerateImage()
                        }
                    }
                }
            }

            binding.history -> {

                sendFirebaseEvents("history_tab_opened", Bundle())

                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY.label
                val historyFragment: HistoryFragment = HistoryFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, historyFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            binding.settings -> {
                sendFirebaseEvents("settings_screen_opened")
                binding.fragmentContainer.visibility = View.VISIBLE
                userMovingScreenState = UserScreenNavigationState.MAIN_TO_SETTING.label
                val settingsFragment: SettingsFragment = SettingsFragment.newInstance()

                val fragmentManager = supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainer, settingsFragment)

                transaction.addToBackStack(null)
                transaction.commit()
            }

            binding.premium -> {
                sendFirebaseEvents("premium_activity_started", Bundle())
                premiumLauncher.launch(Intent(this, PremiumActivity::class.java))
            }
        }
    }

    private fun setUpStyle(style: String) {
        Log.i(TAG, "setUpStyle: $style")
        when (style) {

            "Digital Art" -> {
                binding.digitalArtTextview.text = getString(R.string.digitalArt)
                digitalArtLayout(true, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Neon Punk" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(true)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Color Splash" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(true)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Cosmos" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(true)
                bizarreLayout(false)
            }

            "Bizarre" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(true)
            }

            "No style" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            else -> {
                binding.digitalArtTextview.text = style
                if (style.contains("No style")) {
                    binding.digitalArtShimmer.stopShimmer()
                    binding.digitalArtShimmer.hideShimmer()
                    binding.digitalArtImageview.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.forbidden
                        )
                    )
                } else {
                    digitalArtLayout(true, style)
                    loadStyleImage(
                        applicationContext,
                        binding.digitalArtImageview,
                        styleImagesX(style),
                        binding.digitalArtShimmer
                    )
                }
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }
        }
    }

    private fun digitalArtLayout(value: Boolean, style: String) {
        if (value) {
            loadStyleImage(
                applicationContext,
                binding.digitalArtImageview,
                styleImagesX(style),
                binding.digitalArtShimmer
            )
            binding.digitalArtOverlay.visibility = View.VISIBLE
            /* val shapeAppearanceModel = ShapeAppearanceModel.builder()
                 .setAllCorners(CornerFamily.ROUNDED, 15f)
                 .build()
             binding.digitalArtImageview.shapeAppearanceModel = shapeAppearanceModel*/
            binding.digitalArtImageview.setBackgroundColor(Color.TRANSPARENT)
            binding.digitalArtLayout.background = AppCompatResources.getDrawable(
                this@MainActivity, R.drawable.white_bg_multi_border
            )
            binding.digitalArtLayout.setPadding(spToPx(this, 5F))
        } else {
            binding.digitalArtOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.digitalArtImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.digitalArtLayout.background = null
            binding.digitalArtLayout.setPadding(0)
            //loadStyleImage(applicationContext, binding.digitalArtImageview, "digital-art", binding.digitalArtShimmer)
        }
    }

    private fun neonPunkLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.neonPunkOverlay.visibility = View.VISIBLE
            /*val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            binding.neonPunkImageView.shapeAppearanceModel = shapeAppearanceModel*/
            binding.neonPunkLayout.background = AppCompatResources.getDrawable(
                this@MainActivity, R.drawable.white_bg_multi_border
            )
            binding.neonPunkLayout.setPadding(spToPx(this, 5F))
        } else {
            binding.neonPunkOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.neonPunkImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.neonPunkLayout.background = null
            binding.neonPunkLayout.setPadding(0)
        }
    }

    private fun colorSplashLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.colorSplashOverlay.visibility = View.VISIBLE
            /*val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            binding.colorSplashImageView.shapeAppearanceModel = shapeAppearanceModel*/
            binding.colorSplashLayout.background = AppCompatResources.getDrawable(
                this@MainActivity, R.drawable.white_bg_multi_border
            )
            binding.colorSplashLayout.setPadding(spToPx(this, 5F))
        } else {
            binding.colorSplashOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.colorSplashImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.colorSplashLayout.background = null
            binding.colorSplashLayout.setPadding(0)
        }
    }

    private fun cosmosLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.cosmosOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.cosmosImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.cosmosLayout.background = AppCompatResources.getDrawable(
                this@MainActivity, R.drawable.white_bg_multi_border
            )
            binding.cosmosLayout.setPadding(spToPx(this, 5F))
        } else {
            binding.cosmosOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.cosmosImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.cosmosLayout.background = null
            binding.cosmosLayout.setPadding(0)
        }
    }

    private fun bizarreLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.bizarreOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.bizarreImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.bizarreLayout.background = AppCompatResources.getDrawable(
                this@MainActivity, R.drawable.white_bg_multi_border
            )
            binding.bizarreLayout.setPadding(spToPx(this, 5F))
        } else {
            binding.bizarreOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.bizarreImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.bizarreLayout.background = null
            binding.bizarreLayout.setPadding(0)
        }
    }

    private var currentTutorial = 0

    private fun startTutorial(current: Int = 0) {

        binding.tutorialView.apply {
            isVisible = true
            window.statusBarColor =
                ContextCompat.getColor(this@MainActivity, R.color.tutorial_color)
            currentTutorial = current
            currentTutorial++
            showTutorial()
            setOnClickListener {
                if (currentTutorial == 4) {
                    binding.tagTutorialTempView.visibility = View.GONE
                    showTagButton()
                    showKeyboard()
                }
                currentTutorial++
                showTutorial()
            }
        }
    }

    private fun TutorialView.showTutorial() {

        when (currentTutorial) {
            1 -> {
                inflateTutorials(binding.inputLayout, R.layout.prompt_tutorial_layout)
            }

            2 -> {
                window.statusBarColor = statusBarColorX
                removeAllViews()
                viewScrollToPosition(binding.generateButton.y.toInt(), binding.nestedScrollView)
                HandlerX(500) {
                    inflateTutorials(binding.generateButton, R.layout.generate_tutorial_layout)
                }

                //TinyDB.getInstance(this@MainActivity).putBoolean("notShowTagTutorial", true)
                //inflateTutorials(binding.ratios, R.layout.ratio_tutorial_layout)
            }

            3 -> {
                window.statusBarColor = statusBarColorX
                sendFirebaseEvents("tutorial_complete")
                isVisible = false
                removeAllViews()
                currentTutorial = 0
                TinyDB.getInstance(this@MainActivity).putBoolean("notShowTutorial", true)

                startNotAlarmManager()
                viewScrollToPosition(binding.promptInput.y.toInt(), binding.nestedScrollView)
            }

            4 -> {
                window.statusBarColor =
                    ContextCompat.getColor(this@MainActivity, R.color.tutorial_color)
                inflateTutorials(binding.promptHint, R.layout.tag_tutorial_layout)
            }

            5 -> {
                window.statusBarColor = statusBarColorX
                isVisible = false
                removeAllViews()
                currentTutorial = 0
                TinyDB.getInstance(this@MainActivity).putBoolean("notShowTagTutorial", true)
            }

            /*3 -> {
                inflateTutorials(binding.history, R.layout.history_tutorial_layout)
            }

            4 -> {
                inflateTutorials(binding.promptHint, R.layout.hint_tutorial_layout)
            }

            5 -> {
                window.statusBarColor = statusBarColorX
                removeAllViews()
                viewScrollToPosition(binding.chooseStyle.y.toInt(), binding.nestedScrollView)
                HandlerX(500) {
                    inflateTutorials(binding.chooseStyle, R.layout.style_tutorial_layout)
                }
            }

            6 -> {
                window.statusBarColor = ContextCompat.getColor(this@MainActivity, R.color.tutorial_color)
                inflateTutorials(binding.model, R.layout.model_tutorial_layout)
            }

            7 -> {
                inflateTutorials(binding.advanceSettingsDropdown, R.layout.setting_tutorial_layout)
            }

            8 -> {
                window.statusBarColor = statusBarColorX
                removeAllViews()
                viewScrollToPosition(binding.generateButton.y.toInt(), binding.nestedScrollView)
                HandlerX(500) {
                    inflateTutorials(binding.generateButton, R.layout.generate_tutorial_layout)
                }
                //inflateTutorials(binding.generateButton, R.layout.generate_tutorial_layout)
            }

            9 -> {
                window.statusBarColor = statusBarColorX

                isVisible = false
                removeAllViews()
                currentTutorial = 0
                TinyDB.getInstance(this@MainActivity).putBoolean("notShowTutorial", true)

                startNotAlarmManager()
            }

            10 -> {
                window.statusBarColor = ContextCompat.getColor(this@MainActivity, R.color.tutorial_color)
                inflateTutorials(binding.promptHint, R.layout.tag_tutorial_layout)
            }

            11 -> {
                window.statusBarColor = statusBarColorX
                isVisible = false
                removeAllViews()
                currentTutorial = 0
                TinyDB.getInstance(this@MainActivity).putBoolean("notShowTagTutorial", true)
            }*/
        }
    }

    private fun viewScrollToPosition(mainViewHeight: Int, scrollView: NestedScrollView) {
        scrollView.post {
            scrollView.smoothScrollTo(0, mainViewHeight, 1000)
        }
    }

    private fun generateImage() {

//        sendFirebaseEvents(
//            "user_prompt",
//            Bundle().apply { putString("prompt", binding.promptInput.text.toString()) })
//        sendFirebaseEvents(
//            "negative_prompt",
//            Bundle().apply {
//                putString(
//                    "negative_prompt",
//                    generateModel.negative_prompt + generateModel.negative_prompt_tags
//                )
//            })
//        sendFirebaseEvents(
//            "cfg_scale",
//            Bundle().apply { putInt("cfg_scale", generateModel.cfgScale) })
//        sendFirebaseEvents(
//            "deNoising_steps",
//            Bundle().apply { putString("de_noising_steps", generateModel.deNoising) })

        Singleton.setPrompt(binding.promptInput.text.toString())

        rapidClicker.publish {

        }
        loaderBottomFragment = LoaderBottomFragment().apply {
            isCancelable = false
            show(supportFragmentManager, tag)
        }

        binding.generateButton.isEnabled = false
        Log.i(TAG, "generateImage: GenerateModel:$generateModel")
        aspectRatioToSize()
        tags = getTagsPrompt()
        style = setStylePrompt(generateModel.style)
        val stylePreset = if (Constants.newStyleIdList.contains(generateModel.style)) {
            setStylePrompt(generateModel.style)
        } else {
            null
        }
        requestObject = RequestModel(
            key = Constants.API_KEY,
            model_id = generateModel.model,
            prompt = style + newModelPromptText + Helper.replaceEmojisWithText(binding.promptInput.text.toString()) + tags,
            negative_prompt = getString(R.string.hardcoded_negative_prompt) + generateModel.negative_prompt + generateModel.negative_prompt_tags,
            width = generateModel.width,
            height = generateModel.height,
            samples = "1",
            num_inference_steps = generateModel.deNoising,
            seed = 0,
            guidance_scale = generateModel.cfgScale.toFloat(),
            style_preset = stylePreset,

            safety_checker = "yes",
            safety_checker_type = "sensitive_content_text",
            enhance_prompt = "no",
            tomesd = "yes",
            use_karras_sigmas = "yes",
            panorama = if (generateModel.width != "1800") {
                "no"
            } else {
                "yes"
            },
            self_attention = generateModel.hdQuality,
            clip_skip = "1",
            webhook = null,
            track_id = null
        )
        Log.i(TAG, "generateImage: $requestObject")
        //add 5s delay for non-premium user
        lifecycleScope.launch {
            if (!isPremium()) delay(5000)
            viewModel.createRequestX(requestObject, onSuccess = {
                binding.generateButton.isEnabled = true
                Log.i(TAG, "generateImage: Results: $it")
                insertDataToDb(it)
            }, onFailed = {
                errorDialog(it)
            })
        }
    }

    private fun errorDialog(it: String) {
        sendFirebaseEvents("main_error_dialog_box_displayed")

        sendFirebaseEvents("prompt_result_failed", Bundle().apply { getString("error", it) })
        Log.i("API ERROR RESPONSE", it)

        binding.generateButton.isEnabled = true

        loaderBottomFragment?.dismissAllowingStateLoss()
        ErrorBottomSheet().apply {
            onTryAgainBtnClick = {
                if (!isNetworkAvailable()) {

                    if (saveClickCounter++ == 0) {

                        Singleton.setIsInternetAvailable(false)
                        noInternetFragment.isCancelable = true
                        noInternetFragment.show(supportFragmentManager, noInternetFragment.tag)
                        Handler(Looper.getMainLooper()).postDelayed({
                            saveClickCounter = 0
                        }, 1000)
                    }
                } else {
                    Singleton.setIsInternetAvailable(true)
                    generateImage()
                }
            }
            show(supportFragmentManager, tag)
        }
    }

    private fun insertDataToDb(output: String) {
        val responseItem = HistoryModel(
            databaseHelper.getRowCount() + 1,
            databaseHelper.getRowCount() + 1,
            binding.promptInput.text.toString(),
            output,
            tags,
            generateModel.style,
            generateModel.model,
            binding.modelName.text.toString(),
            generateModel.height,
            generateModel.width,
            getString(R.string.hardcoded_negative_prompt) + generateModel.negative_prompt + generateModel.negative_prompt_tags,
            generateModel.cfgScale.toString(),
            generateModel.deNoising,
            generateModel.hdQuality,
            0,
            System.currentTimeMillis()
        )
        viewModel.insertProduct(responseItem, databaseHelper)
        loadResultImage(responseItem)
    }

    private fun loadResultImage(responseItem: HistoryModel) {
        Glide.with(this@MainActivity).load(responseItem.imageUrl).apply(
            RequestOptions().override(500, 500) // Resize the image
        ).listener(object : RequestListener<Drawable> {
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable>?,
                isFirstResource: Boolean,
            ): Boolean {
                if (isDestroyed || isFinishing) return false
                Log.i(TAG, "API ERROR URL: ${responseItem.imageUrl} ")
                lifecycleScope.launch(Dispatchers.Main) {
                    delay(2000)
                    loadResultImage(responseItem)
                }
                return false // Return false to not display the placeholder or error image
            }

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable>?,
                dataSource: DataSource?,
                isFirstResource: Boolean,
            ): Boolean {
                if (isDestroyed || isFinishing) return false
                showResultFragment(responseItem)
                return false
            }
        }).preload()
    }

    private fun showResultFragment(responseItem: HistoryModel) {

        loaderBottomFragment?.setProgressComplete()
        lifecycleScope.launch(Dispatchers.Main) {
            binding.fragmentContainer.visibility = View.VISIBLE
            sendFirebaseEvents("generate_image_result_ok", Bundle())
            userMovingScreenState = UserScreenNavigationState.MAIN_TO_RESULT.label
            Constants.sessionID = responseItem.sessionId
            Constants.imageUrl = responseItem.imageUrl
            Log.i(TAG, "showResultFragment: ${responseItem.imageUrl}")
            val resultFragment: ResultFragment =
                ResultFragment.newInstance(false, responseItem.sessionId, responseItem.imageUrl)
            val fragmentManager = supportFragmentManager
            val transaction = fragmentManager.beginTransaction()
            transaction.add(R.id.fragmentContainer, resultFragment)
            transaction.addToBackStack(null)
            transaction.commitAllowingStateLoss()
            delay(500)
            loaderBottomFragment?.dismissAllowingStateLoss()
        }
    }

    private fun getTagsPrompt(): String = bottomSheetViewModel.tagsSelectionList.joinToString(", ")

    private fun unselectAspectView() {
        if (this.previousSelectedView != null) {
            when (previousSelectedView) {
                binding.oneOne -> binding.oneOne.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.one_one_gray), null, null, null
                )

                binding.fourThree -> binding.fourThree.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.four_three_gray),
                    null,
                    null,
                    null
                )

                binding.threeTwo -> binding.threeTwo.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.three_two_gray),
                    null,
                    null,
                    null
                )

                binding.twoThree -> binding.twoThree.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.two_three_gray),
                    null,
                    null,
                    null
                )

                binding.sixteenNine -> binding.sixteenNine.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.sixteen_nine_gray),
                    null,
                    null,
                    null
                )

                binding.nineSixteen -> binding.nineSixteen.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.nine_sixteen_gray),
                    null,
                    null,
                    null
                )

                binding.fiveFour -> binding.fiveFour.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.five_four_gray),
                    null,
                    null,
                    null
                )

                binding.fourFive -> binding.fourFive.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.four_five_gray),
                    null,
                    null,
                    null
                )

                binding.threeOne -> binding.threeOne.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.three_one_gray),
                    null,
                    null,
                    null
                )

                binding.threeFour -> binding.threeFour.setCompoundDrawablesWithIntrinsicBounds(
                    AppCompatResources.getDrawable(this, R.drawable.three_four_gray),
                    null,
                    null,
                    null
                )

            }
        }
    }

    private fun updateAspectRatios(view: TextView, text: String, drawable: Int) {
        view.background =
            AppCompatResources.getDrawable(this@MainActivity, R.drawable.aspect_ratio_gradient)
        view.setCompoundDrawablesWithIntrinsicBounds(
            AppCompatResources.getDrawable(this, drawable), null, null, null
        )
        view.setTextColor(resources.getColor(R.color.white))
        view.setPadding(
            spToPx(this, 20F), spToPx(this, 10F), spToPx(this, 20F), spToPx(this, 10F)
        )

        generateModel.aspectRatio = text

        for (i in 0 until binding.ratioLayout.childCount) {
            if ((binding.ratioLayout.getChildAt(i) as MaterialTextView).text != text) {
                (binding.ratioLayout.getChildAt(i) as MaterialTextView).compoundDrawablePadding =
                    spToPx(this, 10F)
                binding.ratioLayout.getChildAt(i).background = AppCompatResources.getDrawable(
                    this@MainActivity, R.drawable.aspect_ratio_bg
                )
                (binding.ratioLayout.getChildAt(i) as MaterialTextView).setTextColor(
                    resources.getColor(
                        R.color.gray
                    )
                )
            }
        }
    }

    private fun aspectRatioToSize() {
        Log.i(
            TAG,
            "aspectRatioToSize: Model:${generateModel.model}  Ratio:${generateModel.aspectRatio}"
        )
        when (generateModel.aspectRatio) {
            "1:1" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "512"
                } else {
                    generateModel.height = "1024"
                    generateModel.width = "1024"
                }
            }

            "4:3" -> {
                when (generateModel.model) {
                    ModelsID.STABLE_DIFFUSION_XL_BETA.label -> {
                        generateModel.height = "512"
                        generateModel.width = "512"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V9.label -> {
                        generateModel.width = "1216"
                        generateModel.height = "832"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V1.label -> {
                        generateModel.width = "1216"
                        generateModel.height = "832"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V6.label -> {
                        generateModel.width = "1344"
                        generateModel.height = "768"
                    }

                    else -> {
                        generateModel.width = "1024"
                        generateModel.height = "768"
                    }
                }
            }

            "3:2" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "512"
                } else {
                    generateModel.width = "1216"
                    generateModel.height = "832"
                }
            }

            "2:3" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "512"
                } else {
                    generateModel.width = "832"
                    generateModel.height = "1216"
                }
            }

            "16:9" -> {
                when (generateModel.model) {
                    ModelsID.STABLE_DIFFUSION_XL_BETA.label -> {
                        generateModel.height = "512"
                        generateModel.width = "512"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V9.label -> {
                        generateModel.width = "1344"
                        generateModel.height = "768"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V1.label -> {
                        generateModel.width = "1344"
                        generateModel.height = "768"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V6.label -> {
                        generateModel.width = "1344"
                        generateModel.height = "768"
                    }

                    else -> {
                        generateModel.width = "1280"
                        generateModel.height = "704"
                    }
                }
            }

            "9:16" -> {
                when (generateModel.model) {
                    ModelsID.STABLE_DIFFUSION_XL_BETA.label -> {
                        generateModel.height = "512"
                        generateModel.width = "512"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V9.label -> {
                        generateModel.width = "768"
                        generateModel.height = "1344"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V1.label -> {
                        generateModel.width = "768"
                        generateModel.height = "1344"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V6.label -> {
                        generateModel.width = "768"
                        generateModel.height = "1344"
                    }

                    else -> {
                        generateModel.width = "704"
                        generateModel.height = "1280"
                    }
                }
            }

            "5:4" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "512"
                } else {
                    generateModel.width = "1280"
                    generateModel.height = "1024"
                }
            }

            "4:5" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "512"
                } else {
                    generateModel.width = "1024"
                    generateModel.height = "1280"
                }
            }

            "3:1" -> {
                if (generateModel.model == ModelsID.STABLE_DIFFUSION_XL_BETA.label) {
                    generateModel.height = "512"
                    generateModel.width = "896"
                } else {
                    generateModel.width = "1536"
                    generateModel.height = "640"
                }
            }

            "3:4" -> {
                when (generateModel.model) {
                    ModelsID.STABLE_DIFFUSION_XL_BETA.label -> {
                        generateModel.height = "896"
                        generateModel.width = "512"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V9.label -> {
                        generateModel.height = "1216"
                        generateModel.width = "832"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V1.label -> {
                        generateModel.height = "1216"
                        generateModel.width = "832"
                    }

                    ModelsID.STABLE_DIFFUSION_XL_V6.label -> {
                        generateModel.width = "768"
                        generateModel.height = "1344"
                    }

                    else -> {
                        generateModel.width = "768"
                        generateModel.height = "1024"
                    }
                }
            }
        }
    }

    override fun onItemClick(item: ShowcaseItem, position: Int) {
        if (saveClickCounter++ == 0) {
            ShowcaseItemBottomFragment.newInstance(item.image, item.prompt, position).apply {
                onShowCaseClickListener = {
                    viewScrollToPosition(
                        binding.enterPromptTextview.y.toInt(),
                        binding.nestedScrollView
                    )
                    generateModel = GenerateModel()
                    item.let {
                        binding.promptInput.setText(it.prompt)
                        binding.ratioValueTextview.text = generateModel.aspectRatio
                        binding.modelName.text =
                            Helper.reformattedModelName(this@MainActivity, it.model_id)
                        setUpStyle(it.stylePreset)
                        generateModel.model = it.model_id
                        generateModel.modelName =
                            Helper.reformattedModelName(this@MainActivity, it.model_id)
                        generateModel.style = it.stylePreset
                        generateModel.hdQuality = it.self_attention
                        loadStyleImage(
                            applicationContext,
                            binding.modelImageview,
                            styleImagesX(generateModel.modelName),
                            binding.bizarreShimmer
                        )
                    }
                }

                show(supportFragmentManager, tag)
            }
            Handler(Looper.getMainLooper()).postDelayed({
                saveClickCounter = 0
            }, 1000)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        Log.i(TAG, "onBackPressed: ${TinyDB.getInstance(this).getBoolean("notShowTutorial")}")
        if (supportFragmentManager.backStackEntryCount > 0) {
            super.onBackPressed()
        } else if (!TinyDB.getInstance(this)
                .getBoolean("notShowTutorial") || currentTutorial != 0
        ) {
            Log.i(TAG, "onBackPressed: $currentTutorial")
            if (currentTutorial == 3) {
                showTagButton()
                showKeyboard()
                binding.tagTutorialTempView.visibility = View.GONE
            }
            currentTutorial++
            binding.tutorialView.showTutorial()
        } else {
            ExitFragment().show(supportFragmentManager, null)
            /*if (SharedPreferenceHelper.isRatingDone(this@MainActivity)) {
                if (doubleBackToExitPressedOnce) {
                    finish()
                }
                this.doubleBackToExitPressedOnce = true
                showSnackBar(
                    resources.getString(R.string.pressAgainToExit),
                    binding.nativeAdContainerForMain
                )
                Handler(Looper.getMainLooper()).postDelayed({
                    doubleBackToExitPressedOnce = false
                }, 2000)
            } else {
              //  this@MainActivity.ratingDialog(onExitClick = { super.onBackPressed() }, null).show()
            }*/
        }
    }

    private fun loadNativeAdForExitDialog() {
        if (!isPremium()) {
            AdsManagerX.loadNativeAd(
                lifecycleOwner = this,
                adConfigManager = AdConfigManager.SHOW_MAIN_NATIVE_EXIT_DIALOG, null
            )
        }
    }

    private fun openVoiceToText() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak something")

        try {
            speechRecognitionLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            showSnackBar(
                resources.getString(R.string.voiceRecognitionIsNotAvilable),
                binding.nativeAdContainerForMain
            )
        }
    }

    private var speechRecognitionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data: Intent? = result.data
                val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                if (!results.isNullOrEmpty()) {

                    val spokenText = results[0]
                    sendFirebaseEvents(
                        "main_speech_to_text",
                        Bundle().apply { putString("spoken_text", spokenText) })
                    binding.promptInput.setText(spokenText)
                    binding.promptInput.setSelection(binding.promptInput.text.length)
                }
            }
        }

    var premiumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                hidePremiumUI()
                bottomSheetViewModel.premiumView()
            }
        }

    override fun onResume() {
        super.onResume()
        if (!isPremium()) {
            loadMainBnnerAd()
            loadAds() // Refresh Rewarded/Inter preloads
        }
        resumeUpdate(isForceUpdate, activityResultLauncher)
    }

    fun loadMainBnnerAd() {

        AdsManagerX.loadBannerAd(
            this,
            AdConfigManager.BANNER_AD_MAIN,
            binding.nativeAdContainerForMain,
            onAdLoaded = {
                //   isAdLoaded = true
            },
            onAdFailed = {
                //  isAdLoaded = false
                //    binding.adContainerTop.gone()
                binding.nativeAdContainerForMain.visibility = View.GONE
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        userMovingScreenState = ""
        mainNativeAd?.destroy()
        (application as AppX).mainNativeAd = null
        loaderBottomFragment?.dismissAllowingStateLoss()
        isMainActivityRunning = false
        Log.e("------>", "MainOnDestroy")
    }
}

enum class UserScreenNavigationState(val label: String) {
    MAIN_TO_HISTORY("Main to History"),
    MAIN_TO_HISTORY_TO_RESULT("Main to History to result"),
    MAIN_TO_RESULT("Main to result"),
    MAIN_TO_SETTING("Main to Setting"),
    MAIN_TO_SETTING_TO_LANGUAGE("Main to Setting to Language"),
}

enum class ModelsID(val label: String) {
    STABLE_DIFFUSION_XL_BETA("SDXL Beta"),
    STABLE_DIFFUSION_XL_V6("stable-diffusion-v1-6"),
    STABLE_DIFFUSION_XL_V9("stable-diffusion-xl-1024-v0-9"),
    STABLE_DIFFUSION_XL_V1("stable-diffusion-xl-1024-v1-0"),
}

enum class StylesID(val label: String) {
    THREE_D_MODEL("3d-model"),
    ANALOG_FILM("analog-film"),
    ANIME("anime"),
    CINEMATIC("cinematic"),
    COMIC_BOOK("comic-book"),
    DIGITAL_ART("digital-art"),
    ENHANCE("enhance"),
    FANTASY_ART("fantasy-art"),
    ISOMETRIC("isometric"),
    LINE_ART("line-art"),
    LOW_POLY("low-poly"),
    MODELING_COMPOUND("modeling-compound"),
    NEON_PUNK("neon-punk"),
    ORIGAMI("origami"),
    PHOTO_GRAPHICS("photographic"),
    PIXEL_ART("pixel-art"),
    TILE_TEXTURE("tile-texture")
}