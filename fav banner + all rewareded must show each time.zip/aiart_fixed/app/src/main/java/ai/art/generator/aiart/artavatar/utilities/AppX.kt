package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.database.DatabaseHelper
import ai.art.generator.aiart.artavatar.model.SharedPreferenceHelper
import ai.art.generator.aiart.artavatar.storage.ThemePreferences
import ai.art.generator.aiart.artavatar.utilities.Constants.defaultLanguageCode
import ai.art.generator.aiart.artavatar.utilities.Constants.themeChange
import ai.art.generator.aiart.artavatar.views.activity.LIFE_TIME
import ai.art.generator.aiart.artavatar.views.activity.MONTHLY_SUB_ID
import ai.art.generator.aiart.artavatar.views.activity.WEEKLY_SUB_ID
import ai.art.generator.aiart.artavatar.views.activity.YEARLY_SUB_ID
import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.security.ProviderInstaller
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.AdsManagerX.loadInterAd
import com.hm.admanagerx.AdsManagerX.loadRewardedAd
import com.hm.admanagerx.IS_PREMIUM
import com.hm.admanagerx.InterAdLoaderX
import com.hm.admanagerx.RewardedAdLoaderX
import com.hm.admanagerx.utility.HandlerX
import com.hm.admanagerx.utility.TinyDB
import com.limurse.iap.DataWrappers
import com.limurse.iap.IapConnector
import com.limurse.iap.PurchaseServiceListener
import com.limurse.iap.SubscriptionServiceListener
import java.util.Locale
import javax.net.ssl.SSLContext


class AppX : Application() {

    var mainNativeAd: NativeAd? = null
    var historyNativeAd: NativeAd? = null
    var rewardedAd: RewardedAdLoaderX? = null
    var interAdLoaderX: InterAdLoaderX? = null
    private lateinit var themePreferences: ThemePreferences
    private var iapConnector: IapConnector? = null

    companion object {
        @JvmField
        var localeManager: LocaleManagerX? = null
        lateinit var databaseHelper: DatabaseHelper
        var isForceUpdate: String = "normal"
    }

    fun loadAppOpenAdNew() {
        AdsManagerX.loadAppOpenAd(
            ProcessLifecycleOwner.get(),
            AdConfigManager.APP_OPEN_AIART.apply {
                adConfig.fullScreenAdLoadingLayout = com.hm.admanagerx.R.layout.ad_loading_view
            }
        )
    }
    override fun onCreate() {
        super.onCreate()

        initIap()
        FirebaseApp.initializeApp(this)

        //check theme Form PReferences and Apply it on Whole App
        themePreferences = ThemePreferences(this)
        changeTheme()

        //get Default Mobile Language
        val defaultLocale = Locale.getDefault()
        defaultLanguageCode = defaultLocale.displayName
        Constants.defaultLanguageCountry = defaultLocale.country
        Log.i(
            "getAppLanguageInfo",
            "App Level onCreate: $defaultLanguageCode  //  ${Constants.defaultLanguageCountry}"
        )
        //check and Apply language
        val getAppLanguage = SharedPreferenceHelper.getAppLanguage(this)
        val langArray = Constants.LANGUAGES
        val langCodeArray = Constants.LANGUAGES_CODE
        Log.i(
            "getAppLanguageInfo",
            "App Level onCreate: Theme:${themePreferences.getThemePreferences()}  $getAppLanguage"
        )
        try {
            setAppLocale(langCodeArray[langArray.indexOf(getAppLanguage)])
        } catch (e: Exception) {
            setAppLocale(getAppLanguage ?: "en")
        }


        databaseHelper = DatabaseHelper(this)
    /*    loadMainActivityNativeAd()
        loadRewardedAdMain()

        HandlerX(2000) {
            loadHistoryNativeAd()
        }
*/
        try {
            // Google Play will install latest OpenSSL
            ProviderInstaller.installIfNeeded(applicationContext);
            val sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, null, null);
            sslContext.createSSLEngine();
        } catch (e: Exception) {
            e.printStackTrace();
        }
    }

    private fun changeTheme() {
        when (themePreferences.getThemePreferences()) {
            AppCompatDelegate.MODE_NIGHT_NO -> AppCompatDelegate.setDefaultNightMode(
                AppCompatDelegate.MODE_NIGHT_NO
            )

            AppCompatDelegate.MODE_NIGHT_YES -> AppCompatDelegate.setDefaultNightMode(
                AppCompatDelegate.MODE_NIGHT_YES
            )

            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM -> AppCompatDelegate.setDefaultNightMode(
                AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            )
        }
    }


    private fun loadInterAdMain() {
        if (interAdLoaderX != null) {
            interAdLoaderX?.reloadAd()
        } else {
        /*    interAdLoaderX = loadInterAd(AdIdsManager.INTER_AD, onAdLoaded = {
//                Toast.makeText(this, "Inter Loaded", Toast.LENGTH_SHORT).show()
            }, onAdFailed = {
//                Toast.makeText(this, "Inter failed $it", Toast.LENGTH_SHORT).show()
            })*/
        }
    }

    override fun attachBaseContext(base: Context) {
        if (localeManager == null) localeManager = LocaleManagerX(base)
        super.attachBaseContext(base)

    }

    private fun initIap() {
        val inAppItem1 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_1)
        val inAppItem2 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_2)
        val lifeTimeId = if (inAppItem1.contains(LIFE_TIME)) {
            inAppItem1
        } else if (inAppItem2.contains(LIFE_TIME)) {
            inAppItem2
        } else {
            LIFE_TIME
        }
        val nonConsumablesList = listOf(lifeTimeId)
        val subsList = listOf(WEEKLY_SUB_ID, YEARLY_SUB_ID, MONTHLY_SUB_ID)
        iapConnector = IapConnector(
            context = this,
            nonConsumableKeys = nonConsumablesList,
            subscriptionKeys = subsList
        )
        iapConnector?.addSubscriptionListener(object : SubscriptionServiceListener {

            override fun onPricesUpdated(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
                setIsPremium(value = false)
                setPremiumValues(iapKeyPrices)
            }

            override fun onPurchaseFailed(
                purchaseInfo: DataWrappers.PurchaseInfo?,
                billingResponseCode: Int?
            ) {

            }

            override fun onSubscriptionPurchased(purchaseInfo: DataWrappers.PurchaseInfo) {}

            override fun onSubscriptionRestored(purchaseInfo: DataWrappers.PurchaseInfo) {
                when (purchaseInfo.sku) {
                    WEEKLY_SUB_ID, YEARLY_SUB_ID, MONTHLY_SUB_ID -> {
                        setIsPremium(value = true)
                    }

                    else -> {
                        setIsPremium(value = false)
                    }
                }
            }
        })

        iapConnector?.addPurchaseListener(object : PurchaseServiceListener {
            override fun onPricesUpdated(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
                setIsPremium(value = false)
                setPremiumValues(iapKeyPrices)
            }

            override fun onProductPurchased(purchaseInfo: DataWrappers.PurchaseInfo) {}

            override fun onProductRestored(purchaseInfo: DataWrappers.PurchaseInfo) {
                when (purchaseInfo.sku) {
                    lifeTimeId -> {
                        setIsPremium(value = true)
                    }

                    else -> {
                        setIsPremium(value = false)
                    }
                }
            }

            override fun onPurchaseFailed(
                purchaseInfo: DataWrappers.PurchaseInfo?,
                billingResponseCode: Int?
            ) {
            }
        })
    }

    private fun setPremiumValues(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
        iapKeyPrices.forEach {
            val item = it.value[0]
            if (it.key.contains(LIFE_TIME)) {
                val lifeTimeTrialEnable = it.value[0].price.orEmpty().contains("Free")
                val lifeTimeValue =
                    if (lifeTimeTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                TinyDB.getInstance(this).putString(LIFE_TIME, lifeTimeValue)
                TinyDB.getInstance(this).putBoolean("lifeTimeTrialEnable", lifeTimeTrialEnable)
            } else if (it.key.contains(YEARLY_SUB_ID)) {
                val yearlyTrialEnable = it.value[0].price.orEmpty().contains("Free")
                val yearlyValue =
                    if (yearlyTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                TinyDB.getInstance(this).putString(YEARLY_SUB_ID, yearlyValue)
                TinyDB.getInstance(this).putBoolean("yearlyTrialEnable", yearlyTrialEnable)
            } else if (it.key.contains(MONTHLY_SUB_ID)) {
                val monthlyTrialEnable = it.value[0].price.orEmpty().contains("Free")
                val monthlyValue =
                    if (monthlyTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                TinyDB.getInstance(this).putString(MONTHLY_SUB_ID, monthlyValue)
                TinyDB.getInstance(this).putBoolean("monthlyTrialEnable", monthlyTrialEnable)
            } else if (it.key.contains(WEEKLY_SUB_ID)) {
                val weeklyValue = item.price ?: "0.0"
                TinyDB.getInstance(this).putString(WEEKLY_SUB_ID, weeklyValue)
            }
        }

    }

    fun setIsPremium(value: Boolean) {
        TinyDB.getInstance(this).putBoolean(IS_PREMIUM, value)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        themeChange = true
        localeManager?.setLocale(this)
        changeTheme()
    }
}