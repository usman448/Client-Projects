package ai.art.generator.aiart.artavatar.utilities

import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings

fun initFirebaseRemoteConfig(onSuccess:(() -> Unit)?=null){
    val TAG = "RemoteConfigInfo"
    val remoteConfig = FirebaseRemoteConfig.getInstance()
    val configSettings = FirebaseRemoteConfigSettings.Builder()
        .setMinimumFetchIntervalInSeconds(1L)
        .build()
    remoteConfig.setConfigSettingsAsync(configSettings)

    remoteConfig.setDefaultsAsync(
        mapOf(
            IS_GENERATE_IMAGE_LIMIT to 5,
            IS_GENERATE_IMAGE_STATE to 0,
            IN_APP_ITEM_1 to "weekly",
            IN_APP_ITEM_2 to "monthly",
            IS_FORCE_UPDATE to "normal"
        )
    )

    remoteConfig.fetchAndActivate().addOnCompleteListener {
        onSuccess?.invoke()
        if (it.isSuccessful){
            Constants.IMAGE_CREDIT_LIMIT = remoteConfig.getLong(
                IS_GENERATE_IMAGE_LIMIT
            ).toInt()
            Constants.GENERATE_IMAGE_STATE = remoteConfig.getLong(
                IS_GENERATE_IMAGE_STATE
            ).toInt()
            Log.i(TAG, "initFirebaseRemoteConfig: Success:${Constants.GENERATE_IMAGE_STATE}")
        }else {
            Log.i(TAG, "initFirebaseRemoteConfig: Failure:$it")
        }
    }
}
fun String.isEnabledInAppUpdateFirebaseRemotely(): String {
    return FirebaseRemoteConfig.getInstance()
        .getString(this)
}

const val IS_GENERATE_IMAGE_LIMIT = "is_generate_image_limit"
const val IS_GENERATE_IMAGE_STATE = "is_generate_image_state"
const val IN_APP_ITEM_1 = "in_app_item_1"
const val IN_APP_ITEM_2 = "in_app_item_2"
const val IS_FORCE_UPDATE = "inapp_update_type"


