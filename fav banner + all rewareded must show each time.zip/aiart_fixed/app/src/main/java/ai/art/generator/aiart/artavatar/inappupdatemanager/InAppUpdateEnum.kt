package ai.art.generator.aiart.artavatar.inappupdatemanager

enum class InAppUpdateEnum(val type: String) {
    NORMAL("normal"),               // will work with simple flow
    FORCE("force"),                    // will force user to update app at splash
    IMMEDIATE("immediate"),   // will force user to update app at splash
    FLEXIBLE("flexible")           // will ask user to update app at Main Screen
}