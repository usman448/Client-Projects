package ai.art.generator.aiart.artavatar.adapter

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ItemModelBinding
import ai.art.generator.aiart.artavatar.databinding.StyleItemBinding
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.loadStyleImage
import ai.art.generator.aiart.artavatar.utilities.Helper.styleImagesX
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.recyclerview.widget.RecyclerView
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.material.imageview.ShapeableImageView
import com.hm.admanagerx.isPremium
import java.util.Locale

class StylesAdapter(
    private val context: Context,
    private val items: List<String>,
    private var selectedItemPosition: Int
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), Filterable {

    companion object{
        const val STYLE_VIEW_TYPE = 0
        const val MODEL_VIEW_TYPE = 1
    }
    private var onItemClickListener: OnItemClickListener? = null
    private var filteredItemList: List<String> = items

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            STYLE_VIEW_TYPE -> StyleViewHolder(StyleItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            MODEL_VIEW_TYPE -> ModelViewHolder(ItemModelBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else -> StyleViewHolder(StyleItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = filteredItemList[position]

        if(Constants.STYLE_IDS.contains(item)){
            (holder as StyleViewHolder).bind(styleImagesX(item), item)
        }else{
            (holder as ModelViewHolder).bind(styleImagesX(item), item)
        }

        holder.itemView.setOnClickListener {
            if (!Constants.PREMIUM_STYLES.contains(items[position])) {
                val previousSelectedItemPosition = selectedItemPosition
                selectedItemPosition = position
                notifyItemChanged(previousSelectedItemPosition)
                notifyItemChanged(selectedItemPosition)
            }else{
                if(context.isPremium()){
                    val previousSelectedItemPosition = selectedItemPosition
                    selectedItemPosition = position
                    notifyItemChanged(previousSelectedItemPosition)
                    notifyItemChanged(selectedItemPosition)
                }
            }
            if (position != RecyclerView.NO_POSITION) {
                onItemClickListener?.onStyleItemClick(filteredItemList[position])
            }
        }

       /* if (position == selectedItemPosition) {
            Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition $item")
            holder.topLayout.visibility = View.VISIBLE
            holder.imageLayout.setBackgroundResource(R.drawable.border)
            holder.imageLayout.setPadding(
                TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP,
                    5F,
                    context.resources.displayMetrics
                ).toInt()
            )
            *//*val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            holder.imageView.shapeAppearanceModel = shapeAppearanceModel*//*
            holder.imageView.setBackgroundColor(Color.TRANSPARENT)
        } else {
            Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition  $item")
            holder.topLayout.visibility = View.GONE
            holder.imageLayout.setBackgroundResource(R.drawable.rounded_border)
            holder.imageLayout.setPadding(
                TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP,
                    0F,
                    context.resources.displayMetrics
                ).toInt()
            )
        }

        holder.bind(styleImagesX(item), item)*/
    }

    override fun getItemCount(): Int {
        return filteredItemList.size
    }

    override fun getItemViewType(position: Int): Int {
       return if(Constants.STYLE_IDS.contains(items[position])){
            STYLE_VIEW_TYPE
        }else{
            MODEL_VIEW_TYPE
        }
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    interface OnItemClickListener {
        fun onStyleItemClick(styleName: String)
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredResults = mutableListOf<String>()

                if (constraint.isNullOrEmpty()) {
                    filteredResults.addAll(items)
                } else {
                    val filterPattern = constraint.toString().trim().lowercase(Locale.getDefault())

                    for (item in items) {
                        if (item.lowercase(Locale.getDefault()).contains(filterPattern)) {
                            filteredResults.add(item)
                        }
                    }
                }

                val results = FilterResults()
                results.values = filteredResults
                return results
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filteredItemList = results?.values as List<String>
                notifyDataSetChanged()
            }
        }
    }

    inner class StyleViewHolder(binding: StyleItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val imageView: ShapeableImageView = binding.root.findViewById(R.id.style_img)
        private val topLayout: ShapeableImageView = binding.root.findViewById(R.id.top_layout)
        private val textView: TextView = binding.root.findViewById(R.id.style_name)
        private val imageLayout: RelativeLayout = binding.root.findViewById(R.id.image_layout)
        private val premiumIcon: ImageView = binding.root.findViewById(R.id.premium_icon)
        private val shimmerLayout: ShimmerFrameLayout = binding.root.findViewById(R.id.shimmer_layout)

        fun bind(image: String, name: String) {
            shimmerLayout.startShimmer()
            if(image.contains("forbidden")){
                shimmerLayout.stopShimmer()
                shimmerLayout.hideShimmer()
                imageView.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.forbidden))
            }else{
                loadStyleImage(context, imageView, image, shimmerLayout)
            }
            textView.text = Helper.reformattedModelName(context, name)
            if (Constants.PREMIUM_STYLES.contains(name) && !context.isPremium()) {
                premiumIcon.visibility = View.VISIBLE
            } else {
                premiumIcon.visibility = View.GONE
            }

            if (position == selectedItemPosition) {
                Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition $name")
                topLayout.visibility = View.VISIBLE
                imageLayout.setBackgroundResource(R.drawable.border)
                imageLayout.setPadding(
                    TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_SP,
                        5F,
                        context.resources.displayMetrics
                    ).toInt()
                )
                /*val shapeAppearanceModel = ShapeAppearanceModel.builder()
                    .setAllCorners(CornerFamily.ROUNDED, 12f)
                    .build()
                holder.imageView.shapeAppearanceModel = shapeAppearanceModel*/
                imageView.setBackgroundColor(Color.TRANSPARENT)
            } else {
                Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition")
                topLayout.visibility = View.GONE
                imageLayout.setBackgroundResource(R.drawable.rounded_border)
                imageLayout.setPadding(
                    TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_SP,
                        0F,
                        context.resources.displayMetrics
                    ).toInt()
                )
            }
        }
    }

    inner class ModelViewHolder(binding: ItemModelBinding) : RecyclerView.ViewHolder(binding.root) {
        val imageView: ShapeableImageView = binding.root.findViewById(R.id.style_img)
        private val topLayout: ShapeableImageView = binding.root.findViewById(R.id.top_layout)
        private val textView: TextView = binding.root.findViewById(R.id.style_name)
        private val imageLayout: RelativeLayout = binding.root.findViewById(R.id.image_layout)
        private val premiumIcon: ImageView = binding.root.findViewById(R.id.premium_icon)
        private val shimmerLayout: ShimmerFrameLayout = binding.root.findViewById(R.id.shimmer_layout)

        fun bind(image: String, name: String) {
            shimmerLayout.startShimmer()
            loadStyleImage(context, imageView, image, shimmerLayout)
            textView.text = Helper.reformattedModelName(context, name)
            if (Constants.PREMIUM_STYLES.contains(name) && !context.isPremium()) {
                premiumIcon.visibility = View.VISIBLE
            } else {
                premiumIcon.visibility = View.GONE
            }

            if (position == selectedItemPosition) {
                Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition $name")
                topLayout.visibility = View.VISIBLE
                imageLayout.setBackgroundResource(R.drawable.border)
                imageLayout.setPadding(
                    TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_SP,
                        5F,
                        context.resources.displayMetrics
                    ).toInt()
                )
                /*val shapeAppearanceModel = ShapeAppearanceModel.builder()
                    .setAllCorners(CornerFamily.ROUNDED, 12f)
                    .build()
                holder.imageView.shapeAppearanceModel = shapeAppearanceModel*/
                imageView.setBackgroundColor(Color.TRANSPARENT)
            } else {
                Log.i("TAG", "onBindViewHolder: $position   $selectedItemPosition  $name")
                topLayout.visibility = View.GONE
                imageLayout.setBackgroundResource(R.drawable.rounded_border)
                imageLayout.setPadding(
                    TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_SP,
                        0F,
                        context.resources.displayMetrics
                    ).toInt()
                )
            }
        }
    }
}
