package ai.art.generator.aiart.artavatar.views.fragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.HistoryAdapter
import ai.art.generator.aiart.artavatar.adapter.ViewPagerAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentHistoryBinding
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.databaseHelper
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.Singleton
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.viewmodel.HistoryViewModel
import ai.art.generator.aiart.artavatar.viewmodel.MainViewModel
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.UserScreenNavigationState
import ai.art.generator.aiart.artavatar.views.dialoguefragments.DiscardBottomFragment
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent

var handleFav: ((HistoryModel, Boolean) -> Unit)? = null

class HistoryFragment : Fragment(), HistoryAdapter.OnItemClickListener {
    private lateinit var binding: FragmentHistoryBinding
    private lateinit var adapter1: HistoryAdapter
    private lateinit var adapter2: HistoryAdapter
    private var historyItems: ArrayList<HistoryModel> = arrayListOf()
    private var favItems: ArrayList<HistoryModel> = arrayListOf()
    private var isNativeAdLoaded = false
    private var isNativeAdLoading = false
    private val viewModel: HistoryViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()
    private val bottomSheetViewModel: BottomSheetVM by activityViewModels()
    private var isFavouriteTab = false
    private var itemToBeChanged: HistoryModel? = null
    var mContext: Context? = null
    private var mActivity: MainActivity? = null
    private lateinit var onBackPressedCallback: OnBackPressedCallback

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    companion object {
        fun newInstance() = HistoryFragment()
    }

    private fun updateEmptyState() {
        val isEmpty = if (isFavouriteTab) favItems.isEmpty() else historyItems.isEmpty()
        binding.emptyLayout.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.emptyBg.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View {
        binding = FragmentHistoryBinding.inflate(inflater, container, false)
        when (Constants.userMovingScreenState) {
            UserScreenNavigationState.MAIN_TO_HISTORY_TO_RESULT.label -> {
                mActivity?.let {
                    Singleton.setIsFromHistory(true)
                    Constants.userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY_TO_RESULT.label
                    val resultFragment = ResultFragment.newInstance(true, Constants.sessionID, Constants.imageUrl)
                    activity?.supportFragmentManager?.beginTransaction()
                        ?.add(R.id.fragmentContainer, resultFragment)
                        ?.addToBackStack(null)
                        ?.commit()
                }
            }
        }
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Constants.userMovingScreenState = ""
                requireActivity().supportFragmentManager.popBackStack()
                viewModel.updateOnBackPress()
                Singleton.setIsFromHistory(false)
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(requireActivity(), onBackPressedCallback)

        handleFav = { item, isLike ->
            val id = viewModel.getID(item.imageUrl, databaseHelper)
            val isFav: Int = if (isLike) 1 else 0
            val index = historyItems.indexOfFirst { it.id == item.id }
            item.favourite = isFav
            if (index != -1) {
                historyItems[index] = item
                itemToBeChanged = item
            }
            if (isLike) {
                requireActivity().showSnackBar(getString(R.string.add_to_favourite), binding.historyNativeAdContainer)
                mainViewModel.addToFavourite(id, databaseHelper, item)
            } else {
                requireActivity().showSnackBar(getString(R.string.remove_from_favourite), binding.historyNativeAdContainer)
                mainViewModel.removeFromFavourite(id, databaseHelper, item)
            }
            updateEmptyState()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Helper.hideKeyboard(mContext)
        setupRecyclerView()
        updateRecordList()
        clickListener()
        observers()
        handleAdsVisibility()
    }

    private fun handleAdsVisibility() {
        val isPremium = requireContext().isPremium()
        if (!isPremium) {
            loadNativeAdIfNeeded()
            if (historyItems.isNotEmpty() || favItems.isNotEmpty()) {
                binding.historyBannerContainer.visibility = View.VISIBLE
                loadAds()
            } else {
                binding.historyBannerContainer.visibility = View.GONE
            }
        } else {
            binding.historyBannerContainer.visibility = View.GONE
            binding.historyNativeAdContainer.visibility = View.GONE
        }
    }

    private fun loadNativeAdIfNeeded() {
        if (isNativeAdLoaded || isNativeAdLoading || requireContext().isPremium()) return
        isNativeAdLoading = true
        AdsManagerX.loadNativeAd(
            this,
            adConfigManager = AdConfigManager.LIST_NATIVE_AD_FOR_HISTORY,
            null,
            onAdLoaded = {
                isNativeAdLoading = false
                isNativeAdLoaded = true
                if (::adapter1.isInitialized) adapter1.notifyDataSetChanged()
                if (::adapter2.isInitialized) adapter2.notifyDataSetChanged()
            }
        )
    }

    private fun loadAds() {
        AdsManagerX.loadBannerAd(
            lifecycleOwner = viewLifecycleOwner,
            adConfigManager = AdConfigManager.HISTORY_BANNER,
            bannerAdContainer = binding.historyBannerContainer
        )
    }

    private fun observers() {
        viewModel.recordDeleted.observe(viewLifecycleOwner) { value ->
            if (value) {
                historyItems.remove(itemToBeChanged)
                adapter1.setData(historyItems.reversed())
                val iterator = favItems.iterator()
                while (iterator.hasNext()) {
                    if (iterator.next().id == itemToBeChanged?.id) iterator.remove()
                }
                adapter2.setData(favItems.reversed())
                updateEmptyState()
                removeSearch()
                handleAdsVisibility()
            }
        }

        mainViewModel.addSubItem.observe(viewLifecycleOwner) { value ->
            favItems.add(value)
            adapter2.setData(favItems.reversed())
            adapter1.setData(historyItems.reversed())
            updateEmptyState()
            handleAdsVisibility()
        }

        mainViewModel.deleteSubItem.observe(viewLifecycleOwner) { value ->
            favItems.removeAll { it.id == value.id }
            if (binding.searchEdittext.text.isEmpty()) {
                adapter2.setData(favItems.reversed())
            } else {
                adapter2.setData(favItems.reversed())
                adapter2.filter.filter(binding.searchEdittext.text)
            }
            adapter1.setData(historyItems.reversed())
            updateEmptyState()
            handleAdsVisibility()
        }

        mainViewModel.addToHistory.observe(viewLifecycleOwner) {
            updateRecordList()
        }

        bottomSheetViewModel.isPremium.observe(viewLifecycleOwner) { value ->
            if (value) {
                binding.historyNativeAdContainer.visibility = View.GONE
                binding.historyBannerContainer.visibility = View.GONE
            }
        }
    }

    private fun updateRecordList() {
        removeSearch()
        val fetchedHistory = viewModel.getHistoryItems(databaseHelper) as ArrayList<HistoryModel>
        for (i in fetchedHistory) {
            i.count = databaseHelper.getRecordsBySessionId(i.sessionId).size
        }
        historyItems = fetchedHistory
        adapter1.setData(historyItems.reversed())

        val allItems = viewModel.getItemList(databaseHelper) as ArrayList<HistoryModel>
        favItems.clear()
        favItems.addAll(allItems.filter { it.favourite == 1 })
        adapter2.setData(favItems.reversed())

        updateEmptyState()
        handleAdsVisibility()
    }

    private fun setupRecyclerView() {
        val recyclerView1 = layoutInflater.inflate(R.layout.history_recycler_view, null) as RecyclerView
        val recyclerView2 = layoutInflater.inflate(R.layout.fav_history_recycler, null) as RecyclerView

        mContext?.let { context ->
            val spanCount = 2
            val edgePadding = Helper.spToPx(context, 12f).toInt()

            // Configure All History List
            adapter1 = HistoryAdapter(requireActivity(), false, binding.emptyBg, binding.emptyLayout, viewLifecycleOwner)
            adapter1.setOnItemClickListener(this)
            val layoutManager1 = GridLayoutManager(context, spanCount)
            adapter1.setSpanSizeLookup(layoutManager1)

            recyclerView1.apply {
                layoutManager = layoutManager1
                adapter = adapter1
                // Set padding to the whole container
                setPadding(edgePadding, edgePadding, edgePadding, edgePadding)
                clipToPadding = false
            }
            adapter1.canLoadAds = !context.isPremium()

            // Configure Fav History List
            adapter2 = HistoryAdapter(requireActivity(), true, binding.emptyBg, binding.emptyLayout, viewLifecycleOwner)
            adapter2.setOnItemClickListener(this)
            val layoutManager2 = GridLayoutManager(context, spanCount)
            adapter2.setSpanSizeLookup(layoutManager2)

            recyclerView2.apply {
                layoutManager = layoutManager2
                adapter = adapter2
                // Set padding to the whole container
                setPadding(edgePadding, edgePadding, edgePadding, edgePadding)
                clipToPadding = false
            }
            adapter2.canLoadAds = !context.isPremium()

            val views = listOf(recyclerView1, recyclerView2)
            binding.pager.adapter = ViewPagerAdapter(views)
        }
    }
    override fun onItemClick(item: HistoryModel) {
        mContext?.sendFirebaseEvents("history_item_clicked")
        removeSearch()
        Singleton.setIsFromHistory(true)
        Constants.userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY_TO_RESULT.label
        Constants.sessionID = item.sessionId
        Constants.imageUrl = item.imageUrl
        val resultFragment = ResultFragment.newInstance(true, item.sessionId, item.imageUrl)
        activity?.supportFragmentManager?.beginTransaction()
            ?.add(R.id.fragmentContainer, resultFragment)
            ?.addToBackStack(null)
            ?.commit()
    }

    override fun onFavClick(item: HistoryModel, isLike: Boolean) {
        if (!isFavouriteTab) mContext?.sendFirebaseEvents("history_favourite", Bundle())
        val id = viewModel.getID(item.imageUrl, databaseHelper)
        val isFav: Int = if (isLike) 1 else 0
        val index = historyItems.indexOfFirst { it.id == item.id }
        item.favourite = isFav
        if (index != -1) {
            historyItems[index] = item
            itemToBeChanged = item
        }
        if (isLike) {
            requireActivity().showSnackBar(getString(R.string.add_to_favourite), binding.historyNativeAdContainer)
            mainViewModel.addToFavourite(id, databaseHelper, item)
        } else {
            requireActivity().showSnackBar(getString(R.string.remove_from_favourite), binding.historyNativeAdContainer)
            mainViewModel.removeFromFavourite(id, databaseHelper, item)
        }
    }

    override fun onDeleteClick(item: HistoryModel, position: Int) {
        itemToBeChanged = item
        mActivity?.let {
            DiscardBottomFragment.newInstance(item.sessionId).apply {
                onDeleteClick = { viewModel.deleteSessionRecord(item.sessionId, databaseHelper) }
                show(it.supportFragmentManager, tag)
            }
        }
    }

    override fun onDetach() {
        onBackPressedCallback.remove()
        viewModel.updateOnBackPress()
        Singleton.setIsFromHistory(false)
        super.onDetach()
    }

    private fun clickListener() {
        var isKeyboardOpen = false
        binding.clearTextButton.setOnClickListener { binding.searchEdittext.setText("") }
        binding.searchIcon.setOnClickListener {
            mContext?.sendFirebaseEvents("history_search_icon_clicked")
            binding.searchEdittext.visibility = View.VISIBLE
            binding.toolbarTitle.visibility = View.GONE
            binding.searchIcon.visibility = View.GONE
            binding.searchEdittext.requestFocus()
            showKeyboard(binding.searchEdittext)
        }

        binding.searchEdittext.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                binding.clearTextButton.visibility = View.VISIBLE
                binding.toolbarTitle.visibility = View.GONE
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (binding.pager.currentItem == 0) adapter1.filter.filter(s) else adapter2.filter.filter(s)
            }
            override fun afterTextChanged(s: Editable?) {
                binding.clearTextButton.visibility = if (binding.searchEdittext.text.isNotEmpty()) View.VISIBLE else View.GONE
            }
        })

        binding.pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, offset: Float, offsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                // 1. Clear search and hide keyboard to keep UI clean during swipe
                removeSearch()

                mContext?.let { context ->
                    // 2. Set the current tab flag
                    isFavouriteTab = position != 0

                    // 3. Update Button UI (Colors and Backgrounds)
                    val activeView = if (position == 0) binding.allHistory else binding.favourites
                    val inactiveView = if (position == 0) binding.favourites else binding.allHistory

                    // Apply "Active" Style
                    activeView.background = AppCompatResources.getDrawable(context, R.drawable.button_border)
                    activeView.setTextColor(Color.WHITE)
                    activeView.setPadding(
                        Helper.spToPx(context, 20F),
                        Helper.spToPx(context, 7F),
                        Helper.spToPx(context, 20F),
                        Helper.spToPx(context, 7F)
                    )

                    // Apply "Inactive" Style
                    inactiveView.background = AppCompatResources.getDrawable(context, R.drawable.aspect_ratio_bg)
                    inactiveView.setTextColor(resources.getColor(R.color.buttonBorderColor))
                    inactiveView.setPadding(
                        Helper.spToPx(context, 20F),
                        Helper.spToPx(context, 7F),
                        Helper.spToPx(context, 20F),
                        Helper.spToPx(context, 7F)
                    )

                    // 4. Handle Search Filtering if user was typing
                    val currentAdapter = if (position == 0) adapter1 else adapter2
                    val searchText = binding.searchEdittext.text

                    if (searchText.isNotEmpty()) {
                        currentAdapter.filter.filter(searchText)
                    }

                    // 5. Refresh the Empty View state (Icon/Background visibility)
                    updateEmptyState()
                }
            }
            override fun onPageScrollStateChanged(state: Int) {}
        })

        binding.backButtonImageView.setOnClickListener {
            if (isKeyboardOpen) Helper.hideKeyboard(mContext) else activity?.onBackPressed()
        }

        binding.allHistory.setOnClickListener { removeSearch(); binding.pager.setCurrentItem(0, true) }
        binding.favourites.setOnClickListener { removeSearch(); binding.pager.setCurrentItem(1, true) }

        KeyboardVisibilityEvent.setEventListener(context as MainActivity) { isOpen ->
            isKeyboardOpen = isOpen
            if (isOpen) binding.historyNativeAdContainer.visibility = View.GONE
            else if (mContext?.isPremium() == false) binding.historyNativeAdContainer.visibility = View.VISIBLE
        }
    }

    private fun showKeyboard(view: View) {
        val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun removeSearch() {
        Helper.hideKeyboard(context)
        binding.searchEdittext.setText("")
        binding.searchEdittext.visibility = View.GONE
        binding.clearTextButton.visibility = View.GONE
        binding.toolbarTitle.visibility = View.VISIBLE
        binding.searchIcon.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        handleFav = null
    }
}