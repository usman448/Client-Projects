package ai.art.generator.aiart.artavatar.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class LoaderViewModel: ViewModel() {
    private val _dismissLoader = MutableLiveData<Boolean>()
    val dismissLoader: LiveData<Boolean> = _dismissLoader

    fun closeLoading(){
        _dismissLoader.postValue(true)
    }
}