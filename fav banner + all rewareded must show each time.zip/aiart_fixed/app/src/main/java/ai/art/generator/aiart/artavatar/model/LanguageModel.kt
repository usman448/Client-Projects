package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep

@Keep
data class LanguageModel(var title: String, var language: String, var code: String)