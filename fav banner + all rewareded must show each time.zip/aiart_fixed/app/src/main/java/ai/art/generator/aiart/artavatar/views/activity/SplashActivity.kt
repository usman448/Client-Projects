package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.cmp.AdsConsentManagerX
import ai.art.generator.aiart.artavatar.databinding.ActivitySplashBinding
import ai.art.generator.aiart.artavatar.inappupdatemanager.InAppUpdateUtil.checkForUpdate
import ai.art.generator.aiart.artavatar.inappupdatemanager.InAppUpdateUtil.registerUpdateListener
import ai.art.generator.aiart.artavatar.model.SharedPreferenceHelper
import ai.art.generator.aiart.artavatar.utilities.AppX
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.isForceUpdate
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.IS_FORCE_UPDATE
import ai.art.generator.aiart.artavatar.utilities.hideSystemUI
import ai.art.generator.aiart.artavatar.utilities.initFirebaseRemoteConfig
import ai.art.generator.aiart.artavatar.utilities.isEnabledInAppUpdateFirebaseRemotely
import ai.art.generator.aiart.artavatar.utilities.statusBarAndNavBarColourChanger
import ai.art.generator.aiart.artavatar.utilities.transparentStatusBar
import ai.art.generator.aiart.artavatar.views.fragments.LanguageFragment
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.applovin.sdk.AppLovinPrivacySettings
import com.google.android.ump.UserMessagingPlatform
import com.hm.admanager.IS_LANG_ENABLE
import com.hm.admanager.getBooleanRemoteConfigValue
import com.hm.admanager.getLongRemoteConfigValue
import com.hm.admanager.SHOW_SUBSCRIPTION_SCREEN_RETURNING_USER
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isAppOpenAdShow
import com.hm.admanagerx.isPremium
import com.inmobi.sdk.InMobiSdk
import com.ironsource.mediationsdk.IronSource
import com.mbridge.msdk.out.MBridgeSDKFactory
import com.nined.fcm.services.FcmFireBaseMessagingService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import recovermessages.restoredeleteddata.recoverdata.notifyme.inappupdatemanager.UpdateScreenEnum
import java.util.concurrent.atomic.AtomicBoolean

@SuppressLint("CustomSplashScreen")
class SplashActivity : BaseActivityX() {

    private var splashTimerFinished = false
    private var adsConsentManagerX: AdsConsentManagerX? = null

    // Tracks whether the first-time (new user) interstitial ad failed to load.
    // Used as a fallback trigger inside decideFlowLangugeFireBased().
    private var firstInterAdFailed = false

    // -----------------------------------------------------------------------
    // REQUIREMENT 1 — FLAG SYSTEM
    // This flag tracks whether the main splash ad (SPLASH_INTER_NEW_USER) failed.
    // true  → main ad failed  → load fallback ad (LANGUAGE_INTER_SPLASH_FALLBACK)
    // false → main ad loaded  → do NOT load fallback ad at all
    // Default is false so fallback never loads unless main ad explicitly fails.
    // -----------------------------------------------------------------------
    private var isSplashAdFailed = false

    // Prevents double navigation: once set to true, navigateToMain() becomes a no-op.
    private var isSplashCompleted = false

    // Tracks whether the user went to background (onPause was called) before navigation.
    private var isComingFromBackground = false

    private lateinit var binding: ActivitySplashBinding
    private var isNewUser = false

    // AtomicBoolean ensures the returning-user ad is shown only once,
    // even if onResume fires multiple times.
    private val isAdHandled = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initFirebaseRemoteConfig {
            isForceUpdate = IS_FORCE_UPDATE.isEnabledInAppUpdateFirebaseRemotely()
            FcmFireBaseMessagingService.subscribeToTopic()
        }

        AdsManagerX.destroyAllAds()
        initializeAds()

        isAppOpenAdShow(false)

        transparentStatusBar()
        statusBarAndNavBarColourChanger(android.R.color.transparent, true)
        initUi()
        clickListeners()
        selectionScreen()

        val videoResId = R.raw.splash_video
        val videoUri = Uri.parse("android.resource://$packageName/$videoResId")
        binding.videoView.setVideoURI(videoUri)
        binding.videoView.start()
        binding.videoView.setOnCompletionListener {
            binding.videoView.start()
        }
    }

    private fun initializeAds() {
        if (isPremium()) {
            selectionScreen()
            return
        }
        AdsManagerX.loadFirebaseRemoteConfig {}
        adsConsentManagerX = AdsConsentManagerX.getInstance(this)
        adsConsentManagerX?.init(this) {
            mediationsConsent()
            AdsManagerX.init(
                application = application as AppX,
                isAppLevelAdsInitialization = true
            ) {
                AdsManagerX.destroyAllAds()
            }
        }
        isAppOpenAdShow(false)
    }

    private fun mediationsConsent() {
        intiAppLovin()
        initMintegral()
        initIronSource()
        initInMobiAds()
        initAppLovin()
    }

    private fun initAppLovin() {
        val isConsentGiven = UserMessagingPlatform.getConsentInformation(this).canRequestAds()
    }

    private fun intiAppLovin() {
        AppLovinPrivacySettings.setHasUserConsent(true, applicationContext)
    }

    private fun initMintegral() {
        val sdk = MBridgeSDKFactory.getMBridgeSDK()
    }

    private fun initIronSource() {
        IronSource.setConsent(true)
        IronSource.setMetaData("do_not_sell", "true")
    }

    private fun initInMobiAds() {
        val consentObject = JSONObject()
        try {
            consentObject.put(InMobiSdk.IM_GDPR_CONSENT_AVAILABLE, true)
            consentObject.put("gdpr", "1")
        } catch (exception: JSONException) {
            exception.printStackTrace()
        }
    }

    private fun loadAppOpenNew() {
        (application as AppX).loadAppOpenAdNew()
    }

    private fun initUi() {
        val fullString =
            "${getString(R.string.terms_conditions)} & ${getString(R.string.privacy_policy)}"
        binding.termsPrivacyPolicyTextview.underLineAndClickableTxtNew(fullString)
    }

    private fun TextView.underLineAndClickableTxtNew(fullString: String) {
        val terms = context.getString(R.string.terms_conditions)
        val privacyPolicy = context.getString(R.string.privacy_policy)
        val fullText = String.format(fullString, terms, privacyPolicy)

        val spannableString = SpannableString(fullText)

        val termsClickableSpan = object : ClickableSpan() {
            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(this@SplashActivity, R.color.black)
            }
            override fun onClick(widget: View) {
                Helper.openUrlInCustomTabs(this@SplashActivity, Constants.TERMS_AND_CONDITIONS)
            }
        }

        val privacyPolicyClickableSpan = object : ClickableSpan() {
            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(this@SplashActivity, R.color.black)
            }
            override fun onClick(widget: View) {
                Helper.openUrlInCustomTabs(this@SplashActivity, Constants.PRIVACY_POLICY)
            }
        }

        spannableString.setSpan(termsClickableSpan, fullText.indexOf(terms), fullText.indexOf(terms) + terms.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannableString.setSpan(UnderlineSpan(), fullText.indexOf(terms), fullText.indexOf(terms) + terms.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannableString.setSpan(privacyPolicyClickableSpan, fullText.indexOf(privacyPolicy), fullText.indexOf(privacyPolicy) + privacyPolicy.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannableString.setSpan(UnderlineSpan(), fullText.indexOf(privacyPolicy), fullText.indexOf(privacyPolicy) + privacyPolicy.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        this.text = spannableString
        this.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun selectionScreen() {
        isNewUser = SharedPreferenceHelper.isFirstTimeLaunch(this)

        if (isNewUser) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            binding.groupStart.visibility = View.VISIBLE
            binding.groupSplash.visibility = View.GONE

            val paint: TextPaint = binding.toArtGenerator.paint
            val width: Float = paint.measureText(binding.toArtGenerator.text.toString())
            val textShader: Shader = LinearGradient(
                0f, 0f, width, binding.toArtGenerator.textSize,
                intArrayOf(Color.parseColor("#53a1ec"), Color.parseColor("#ff1d7c"), Color.parseColor("#ebb079")),
                null, Shader.TileMode.CLAMP
            )
            binding.toArtGenerator.paint.shader = textShader

        } else {
            sendFirebaseEvents("splash_screen_displayed")

            val paint: TextPaint = binding.articraftTextview.paint
            val width: Float = paint.measureText(binding.articraftTextview.text.toString())
            val textShader: Shader = LinearGradient(
                0f, 0f, width, binding.articraftTextview.textSize,
                intArrayOf(Color.parseColor("#53a1ec"), Color.parseColor("#ff1d7c"), Color.parseColor("#ebb079")),
                null, Shader.TileMode.REPEAT
            )
            binding.articraftTextview.paint.shader = textShader

            binding.groupStart.visibility = View.INVISIBLE
            binding.groupSplash.visibility = View.VISIBLE

            loadSplashAdForReturningUser()
        }
    }

    private fun loadSplashAdForReturningUser() {
        val interConfig = AdConfigManager.SPLASH_INTER_RETURNING_USER

        lifecycleScope.launch {
            delay(1200)

            AdsManagerX.loadInterAd(
                lifecycleOwner = this@SplashActivity,
                adConfigManager = interConfig,
                onAdLoaded = {
                    if (!isFinishing) {
                        showReturningUserSplashAdThenNavigate()
                    }
                },
                onAdFailed = {
                    navigateToMain()
                }
            )
        }
    }

    private fun getAppLaunchCount(): Long {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val count = prefs.getLong("launch_count", 0L) + 1
        prefs.edit().putLong("launch_count", count).apply()
        return count
    }

    private fun is24HourPassed(): Boolean {
        val prefs = getSharedPreferences("PAYWALL_PREFS", MODE_PRIVATE)
        val last = prefs.getLong("LAST_PAYWALL_TIME", 0L)
        return System.currentTimeMillis() - last >= 86400000L
    }

    private fun saveLastPaywallTime() {
        getSharedPreferences("PAYWALL_PREFS", MODE_PRIVATE).edit()
            .putLong("LAST_PAYWALL_TIME", System.currentTimeMillis()).apply()
    }

    private fun showReturningUserSplashAdThenNavigate() {
        // Guard: run this block only once even if onResume fires again.
        if (!isAdHandled.compareAndSet(false, true)) return

        val interConfig = AdConfigManager.SPLASH_INTER_RETURNING_USER

        val navigateNext: () -> Unit = {
            val rule = SHOW_SUBSCRIPTION_SCREEN_RETURNING_USER.getLongRemoteConfigValue()
            val launchCount = getAppLaunchCount()

            val shouldShow = when {
                rule == 0L -> false
                rule > 0L -> launchCount > rule
                rule == -1L -> true
                rule == -2L -> is24HourPassed()
                else -> false
            }
            loadAppOpenNew()
            if (shouldShow) {
                saveLastPaywallTime()
                startActivity(Intent(this, PremiumActivity::class.java))
                finish()
            } else {
                navigateToMain()
            }
        }

        if (AdsManagerX.isInterAdLoaded(interConfig)) {
            AdsManagerX.showInterAd(
                activity = this,
                adConfigManager = interConfig,
                onAdClose = { navigateNext() },
                funBlock = { navigateNext() }
            )
        } else {
            navigateNext()
        }
    }

    private fun navigateToMain() {
        // Guard: prevents navigating twice (e.g. ad callback + onResume both fire).
        if (isFinishing || isSplashCompleted) return
        isSplashCompleted = true
        loadAppOpenNew()
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        finish()
    }

    private fun loadLanguageNativeAd() {
        if (isPremium()) return
        AdsManagerX.loadNativeAd(this, AdConfigManager.NATIVE_AD_LANGUAGE, null, {}, {}, {}, {})
    }

    private fun decideFlowLangugeFireBased() {
        val isLanguageEnabled = IS_LANG_ENABLE.getBooleanRemoteConfigValue()
        Log.d("lang_bool_ars", "rule value: $isLanguageEnabled")
        val fromSplash = true
        if (isLanguageEnabled) {
            binding.groupSplash.visibility = View.GONE
            binding.groupStart.visibility = View.GONE
            binding.fragmentContainer.visibility = View.VISIBLE

            loadLanguageNativeAd()

            // ---------------------------------------------------------------
            // REQUIREMENT 1 — FALLBACK AD LOGIC
            // The fallback ad (LANGUAGE_INTER_SPLASH_FALLBACK) is only loaded
            // here if the main splash ad failed (isSplashAdFailed = true).
            // If the main ad loaded successfully, this block is skipped entirely.
            // The actual showing of the fallback ad happens inside LanguageFragment
            // via showLanguageInterThenClose() when the user taps "Done".
            // ---------------------------------------------------------------
            if (isSplashAdFailed) {
                loadAdFallback()
            }

            val languageFragment = LanguageFragment.newInstance(fromSplash)
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, languageFragment)
                .commit()
        } else {
            showReturningUserSplashAdThenNavigate()
        }
    }

    // Preloads the fallback interstitial ad so it is ready when LanguageFragment needs to show it.
    private fun loadAdFallback() {
        AdsManagerX.loadInterAd(this, AdConfigManager.LANGUAGE_INTER_SPLASH_FALLBACK)
    }

    private fun clickListeners() {
        binding.btnStart.setOnClickListener {
            sendFirebaseEvents("splash_lets_get_started_btn_clicked")
            SharedPreferenceHelper.setFirstTimeLaunch(this, false)
            binding.groupStart.visibility = View.GONE
            binding.groupSplash.visibility = View.VISIBLE
            binding.videoView.start()
            handleNewUserAd()
        }
    }

    // -----------------------------------------------------------------------
    // REQUIREMENT 1 — PRIORITY FLOW + FLAG SYSTEM
    //
    // This function handles the ad logic for first-time (new) users.
    //
    // Priority:
    //   1. Try to load and show SPLASH_INTER_NEW_USER (main ad).
    //   2. If it loads → set isSplashAdFailed = false → show it → proceed.
    //   3. If it fails → set isSplashAdFailed = true → fallback will be
    //      loaded later inside decideFlowLangugeFireBased().
    //
    // The fallback (LANGUAGE_INTER_SPLASH_FALLBACK) is NEVER loaded by default.
    // It only loads when isSplashAdFailed becomes true.
    // -----------------------------------------------------------------------
    private fun handleNewUserAd() {
        val interConfig = AdConfigManager.SPLASH_INTER_NEW_USER
        loadAppOpenNew()
        AdsManagerX.loadInterAd(
            lifecycleOwner = this,
            adConfigManager = interConfig,
            onAdLoaded = {
                // Main splash ad loaded successfully.
                // Mark flag as false so fallback will NOT be loaded.
                firstInterAdFailed = false
                isSplashAdFailed = false
                AdsManagerX.showInterAd(
                    activity = this@SplashActivity,
                    adConfigManager = interConfig,
                    onAdClose = { decideFlowLangugeFireBased() },
                    funBlock = { decideFlowLangugeFireBased() }
                )
            },
            onAdFailed = {
                // Main splash ad failed to load.
                // Set flag to true so fallback WILL be loaded in decideFlowLangugeFireBased().
                firstInterAdFailed = true
                isSplashAdFailed = true
                Log.d("SplashActivity_First_int_fail", "Main splash ad failed: $interConfig")
                lifecycleScope.launch {
                    delay(500)
                    decideFlowLangugeFireBased()
                }
            }
        )
    }

    override fun onPause() {
        super.onPause()
        // Mark that user went to background so onResume can handle it correctly.
        if (!isSplashCompleted) {
            isComingFromBackground = true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isAppOpenAdShow(false)
        binding.videoView.stopPlayback()
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()

        // If splash is already completed (navigated away), do nothing.
        if (isSplashCompleted || isFinishing) return

        isAppOpenAdShow(true)
        binding.videoView.start()

        // If a returning user comes back from background, check if the ad is ready.
        if (isComingFromBackground && !isNewUser) {
            isComingFromBackground = false

            val interConfig = AdConfigManager.SPLASH_INTER_RETURNING_USER
            if (AdsManagerX.isInterAdLoaded(interConfig) && isAdHandled.compareAndSet(false, true)) {
                // Ad is loaded and not yet shown → show it now.
                val navigateNext: () -> Unit = {
                    loadAppOpenNew()
                    navigateToMain()
                }
                AdsManagerX.showInterAd(
                    activity = this,
                    adConfigManager = interConfig,
                    onAdClose = { navigateNext() },
                    funBlock = { navigateNext() }
                )
            } else if (isAdHandled.get()) {
                // Ad was already handled before going to background → just navigate.
                navigateToMain()
            }
            return
        }

        // If returning user's ad was already handled, navigate directly.
        if (!isNewUser && isAdHandled.get()) {
            navigateToMain()
        }
    }
}