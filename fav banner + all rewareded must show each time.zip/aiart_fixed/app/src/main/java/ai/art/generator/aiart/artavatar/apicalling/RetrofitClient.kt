package ai.art.generator.aiart.artavatar.apicalling

import ai.art.generator.aiart.artavatar.utilities.Constants
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    const val timeout: Long = 50
    val apiService: APIInterface by lazy {
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(timeout, TimeUnit.SECONDS) // Adjust the timeout duration
            .readTimeout(timeout, TimeUnit.SECONDS).writeTimeout(timeout, TimeUnit.SECONDS).build()

        val retrofit = Retrofit.Builder().baseUrl(Constants.AI_BASE_URL)
//            .addConverterFactory(GsonConverterFactory.create())
            .addConverterFactory(ScalarsConverterFactory.create()).client(okHttpClient).build()
        retrofit.create(APIInterface::class.java)
    }




}