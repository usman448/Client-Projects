package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.SelectedTagsAdapter
import ai.art.generator.aiart.artavatar.adapter.TagSelectionAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentTagsBinding
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_IS_FROM_EDIT
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_TAGS_STRING
import ai.art.generator.aiart.artavatar.utilities.Constants.COLORS_TAGS
import ai.art.generator.aiart.artavatar.utilities.Constants.MOOD_TAGS
import ai.art.generator.aiart.artavatar.utilities.Constants.POPULAR_TAGS
import ai.art.generator.aiart.artavatar.utilities.Constants.QUALITY_TAGS
import ai.art.generator.aiart.artavatar.utilities.Constants.STYLE_TAGS
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.RecyclerView
import com.google.android.flexbox.FlexDirection
import com.google.android.flexbox.FlexboxLayoutManager
import com.google.android.flexbox.JustifyContent
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

var selectedTabId = R.id.radio0

class TagsFragment : BottomSheetDialogFragment() {
    private var tagsSelectionList: ArrayList<String> = ArrayList()
    private lateinit var binding: FragmentTagsBinding
    private val viewModel: BottomSheetVM by activityViewModels()
    private var isFromEdit = false
    private var mContext: Context? = null
    private var mActivity: MainActivity? = null
    var onTagAdded: ((String) -> Unit)? = null
    var tagcalledfrom: String? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as? MainActivity
    }

    override fun onStart() {
        super.onStart()
        (dialog as BottomSheetDialog).behavior.state = BottomSheetBehavior.STATE_EXPANDED
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentTagsBinding.inflate(inflater, container, false)
        arguments?.let {
            isFromEdit = it.getBoolean(ARG_IS_FROM_EDIT)
            tagcalledfrom = it.getString(ARG_TAGS_STRING)
        }
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tagsSelectionList = if (isFromEdit) {
            viewModel.editTagsSelectionList
        } else {
            viewModel.tagsSelectionList
        }

        if (tagsSelectionList.isEmpty()) {
            binding.tapAddTxt.isVisible = true
            binding.selectedRv.isVisible = false
        } else {
            binding.tvAdKeyBtn.text = resources.getString(R.string.updateKeywords)
            binding.tapAddTxt.isVisible = false
        }
        val adapter = view.initTagSelectionRecyclerView()

        val selectedTagsAdapter = SelectedTagsAdapter()
        selectedTagsAdapter.listEmptyCheck = {
            binding.tapAddTxt.isVisible = true
            binding.selectedRv.isVisible = false
        }
        selectedTagsAdapter.items.addAll(tagsSelectionList)

        binding.selectedRv.adapter = selectedTagsAdapter

        adapter.onItemClock = { item, isRemove ->
            if (isRemove) {
                selectedTagsAdapter.removeItem(item)
                if (selectedTagsAdapter.items.size <= 0) {
                    binding.tapAddTxt.visibility = View.VISIBLE
                } else {
                    binding.tapAddTxt.visibility = View.GONE
                }
            } else {

                binding.tapAddTxt.isVisible = false
                binding.selectedRv.isVisible = true

                binding.selectedRv.scrollToPosition(selectedTagsAdapter.items.size)
                selectedTagsAdapter.addItem(item)

                if (selectedTagsAdapter.items.size <= 0) {
                    binding.tapAddTxt.visibility = View.VISIBLE
                } else {
                    binding.tapAddTxt.visibility = View.GONE
                }
            }
        }

        selectedTagsAdapter.onRemoveItemClick = {
            adapter.unSelected(it)
        }


        binding.tagsRadioGroupview.setOnCheckedChangeListener { _, checkedId ->

            val selectedRadioButton: RadioButton = view.findViewById(checkedId)
            selectedTabId = checkedId

            when (selectedRadioButton.text) {
                getString(R.string.popular) -> {
                    adapter.setData(POPULAR_TAGS)
                    binding.tagsTabScroll.scrollTo(0, 0)
                }

                getString(R.string.quality) -> {
                    adapter.setData(QUALITY_TAGS)
                }

                getString(R.string.color) -> {
                    adapter.setData(COLORS_TAGS)

                }

                getString(R.string.style) -> {
                    adapter.setData(STYLE_TAGS)
                }

                getString(R.string.mood) -> {
                    adapter.setData(MOOD_TAGS)
                    binding.tagsTabScroll.scrollTo(binding.tagsTabScroll.width, 0)

                }
            }
           // binding.tagsRecyclerView.scrollToPosition(0)
            binding.tagsRecyclerView.smoothScrollToPosition(0)
        }

        binding.tvAdKeyBtn.setOnClickListener {
            if (tagcalledfrom == "editPrompt") {
                mContext?.sendFirebaseEvents("edit_prompt_keywords_added")
            } else {
                mContext?.sendFirebaseEvents("add_keyword_btn_clicked")
            }

            tagsSelectionList.clear()
            tagsSelectionList.addAll(selectedTagsAdapter.items)
            val tagsCount =
                if (selectedTagsAdapter.items.size > 0) selectedTagsAdapter.items.size.toString() else ""
            onTagAdded?.invoke(tagsCount)
            dismissAllowingStateLoss()
        }

        binding.tvClearBtn.setOnClickListener {
            tagsSelectionList.clear()
            selectedTagsAdapter.clearAllSelection()
            val tagsCount =
                if (selectedTagsAdapter.items.size > 0) selectedTagsAdapter.items.size.toString() else ""
            onTagAdded?.invoke(tagsCount)
            adapter.clearAllSelection()
            dismissAllowingStateLoss()
        }
    }

    private fun View.initTagSelectionRecyclerView(): TagSelectionAdapter {

        val layoutManager = FlexboxLayoutManager(mContext)
        layoutManager.flexDirection = FlexDirection.ROW
        layoutManager.justifyContent = JustifyContent.FLEX_START

        binding.tagsRecyclerView.layoutManager = layoutManager

        val adapter: TagSelectionAdapter
        findViewById<RadioButton>(selectedTabId).isChecked = true
        when (selectedTabId) {
            R.id.radio0 -> {
                adapter = TagSelectionAdapter(POPULAR_TAGS)
            }

            R.id.radio1 -> {
                adapter = TagSelectionAdapter(QUALITY_TAGS)
            }

            R.id.radio2 -> {
                adapter = TagSelectionAdapter(COLORS_TAGS)
            }

            R.id.radio3 -> {
                adapter = TagSelectionAdapter(STYLE_TAGS)
            }

            R.id.radio4 -> {
                adapter = TagSelectionAdapter(MOOD_TAGS)
            }

            else -> {
                adapter = TagSelectionAdapter(POPULAR_TAGS)
            }
        }

        adapter.selectedItems.addAll(tagsSelectionList)
        binding.tagsRecyclerView.adapter = adapter

        binding.tagsRecyclerView.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        (dialog as? BottomSheetDialog)?.behavior?.apply {
                            isDraggable = false
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        (dialog as? BottomSheetDialog)?.behavior?.apply {
                            isDraggable = true
                        }
                    }
                }
                return false
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                // Handle touch events here if needed
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {
                // Not used in this example
            }
        })

        return adapter
    }

    companion object {
        @JvmStatic
        fun newInstance(fromEdit: Boolean, tagString: String) = TagsFragment().apply {
            arguments = Bundle().apply {
                putBoolean(ARG_IS_FROM_EDIT, fromEdit)
                putString(ARG_TAGS_STRING, tagString)
            }
        }
    }
}