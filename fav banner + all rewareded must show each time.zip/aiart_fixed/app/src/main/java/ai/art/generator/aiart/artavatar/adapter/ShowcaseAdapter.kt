package ai.art.generator.aiart.artavatar.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ItemViewBinding
import ai.art.generator.aiart.artavatar.model.ShowcaseItem
import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry
import com.facebook.shimmer.ShimmerFrameLayout
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.isPremium

class ShowcaseAdapter(private val context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val ITEM_VIEW_TYPE = 0
    private val AD_VIEW_TYPE = 1
    private val ITEMS_BEFORE_AD = 4 // 2 columns * 2 rows = 4 items

    private var onItemClickListener: OnItemClickListener? = null
    private val itemsList = mutableListOf<ShowcaseItem>()

    // Use this to make the ad full-width in MainActivity
    fun setSpanSizeLookup(layoutManager: GridLayoutManager) {
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (getItemViewType(position) == AD_VIEW_TYPE) {
                    layoutManager.spanCount // Take 2 columns
                } else {
                    1 // Take 1 column
                }
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        // If not premium, place ad at every 5th position (index 4, 9, 14...)
        return if (!context.isPremium()&& (position + 1) % (ITEMS_BEFORE_AD + 1) == 0) {
            AD_VIEW_TYPE
        } else {
            ITEM_VIEW_TYPE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == AD_VIEW_TYPE) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.native_ad_container, parent, false)
            AdViewHolder(view)
        } else {
            val binding = ItemViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            ViewHolder(binding)
        }
    }

    override fun getItemCount(): Int {
        if (itemsList.isEmpty()) return 0
        return if (context.isPremium()) {
            itemsList.size
        } else {
            // Calculate total size including ad slots
            itemsList.size + (itemsList.size / ITEMS_BEFORE_AD)
        }
    }

    private fun getDataIndex(adapterPosition: Int): Int {
        if (context.isPremium()) return adapterPosition
        val adsCountBefore = (adapterPosition + 1) / (ITEMS_BEFORE_AD + 1)
        return adapterPosition - adsCountBefore
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is AdViewHolder) {
            holder.bindAd()
        } else if (holder is ViewHolder) {
            val dataIndex = getDataIndex(position)
            if (dataIndex in itemsList.indices) {
                val item = itemsList[dataIndex]
                holder.bind(item.image, item.prompt)
            }
        }
    }

    inner class ViewHolder(private val binding: ItemViewBinding) : RecyclerView.ViewHolder(binding.root) {
        private val imageView: ImageView = binding.imageView
        private val textView: TextView = binding.inspirationsPrompt
        private val shimmer: ShimmerFrameLayout = binding.showcaseShimmer

        init {
            binding.root.setOnClickListener {
                val dataIndex = getDataIndex(adapterPosition)
                if (dataIndex in itemsList.indices) {
                    onItemClickListener?.onItemClick(itemsList[dataIndex], dataIndex)
                }
            }
        }

        fun bind(imageUrl: String, prompt: String) {
            shimmer.startShimmer()
            loadWithRetry(context, imageView, imageUrl, 500, 500, shimmer, false)
            textView.text = prompt
        }
    }

    inner class AdViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val adFrame: FrameLayout = itemView.findViewById(R.id.fl_small_native)
        fun bindAd() {
            adFrame.visibility = View.VISIBLE
            adFrame.removeAllViews()
            AdsManagerX.showNativeAd(
                adConfigManager = AdConfigManager.HOME_NATIVE_IN_BETWEEN,
                nativeAdContainer = adFrame
            )
        }
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    interface OnItemClickListener {
        fun onItemClick(item: ShowcaseItem, position: Int)
    }

    fun updateItems(list: List<ShowcaseItem>) {
        val startSize = itemCount
        itemsList.addAll(list)
        notifyItemRangeInserted(startSize, list.size + (list.size / ITEMS_BEFORE_AD))
    }
}