package ai.art.generator.aiart.artavatar.views.fragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.PreviewAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentPreviewBinding
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_IMAGE_URL
import ai.art.generator.aiart.artavatar.utilities.Constants.ARG_SELECTED_IMAGE
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PreviewFragment : Fragment(), View.OnClickListener, PreviewAdapter.OnItemClickListener {
    private lateinit var imageUrl: List<String>
    private lateinit var selectedImageUrl: String
    private lateinit var binding: FragmentPreviewBinding
    private lateinit var previewAdapter: PreviewAdapter
    var mContext: Context? = null
    private var mActivity: MainActivity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activity?.setTheme(R.style.Base_FragmentWithCustomStatusBar)
        arguments?.let {
            imageUrl = it.getStringArrayList(ARG_IMAGE_URL)!!
            selectedImageUrl = it.getString(ARG_SELECTED_IMAGE).toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPreviewBinding.inflate(inflater, container, false)
        setUI()
        clickListeners()
        return binding.root
    }

    private fun clickListeners() {
        binding.closeImage.setOnClickListener(this)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    private fun setUI() {
        lifecycleScope.launch {
            mContext?.let {
                Helper.loadBitmap(
                    it,
                    binding.selectedImage,
                    getBitmap(selectedImageUrl),
                    null
                )
            }
        }

        mContext?.let {
            previewAdapter = PreviewAdapter(it, imageUrl, this)
            binding.imageList.adapter = previewAdapter
            binding.imageList.layoutManager = LinearLayoutManager(it, LinearLayoutManager.HORIZONTAL, false)
            previewAdapter.updateSelectedPosition(imageUrl.indexOf(selectedImageUrl))
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(imageList: List<String>, selectedImage: String) =
            PreviewFragment().apply {
                arguments = Bundle().apply {
                    putStringArrayList(ARG_IMAGE_URL, ArrayList(imageList))
                    putString(ARG_SELECTED_IMAGE, selectedImage)
                }
            }
    }

    override fun onClick(v: View?) {
        when (v) {
            binding.closeImage -> {
                mActivity?.supportFragmentManager?.popBackStack()
            }
        }
    }

    private suspend fun getBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
        return@withContext Helper.addWaterMark(mContext, url)
    }

    override fun onItemClick(item: String) {
        binding.selectedImage.resetZoomAnimated()
        lifecycleScope.launch {
            mContext?.let { Helper.loadBitmap(it, binding.selectedImage, getBitmap(item), null) }
            previewAdapter.updateSelectedPosition(imageUrl.indexOf(item))
            binding.selectedImage.resetZoom()
        }
    }
}