package ai.art.generator.aiart.artavatar.cmp

import android.app.Activity
import android.content.Context
import android.provider.Settings
import com.google.android.ump.ConsentDebugSettings
import com.google.android.ump.ConsentForm.OnConsentFormDismissedListener
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.hm.admanagerx.isPremium
import java.security.NoSuchAlgorithmException

class AdsConsentManagerX private constructor(context: Context) {

    private val consentInformation: ConsentInformation = UserMessagingPlatform.getConsentInformation(context)

    fun init(
        activity: Activity,
        isInDebug:Boolean=false,
        consentCompleteListener: ConsentCompleteListener
    ) {
        if (activity.isPremium()) {
            consentCompleteListener.onConsentProcessed()
            return
        }

        val params = if (isInDebug) {
            val debugSettings =
                ConsentDebugSettings.Builder(activity)
//                .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_NOT_EEA)
                    .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA)
                    .addTestDeviceHashedId(activity.getAdmobHashId())
                    .build()

            ConsentRequestParameters.Builder().setConsentDebugSettings(debugSettings).build()
        } else {
            ConsentRequestParameters.Builder().build()
        }
        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                if (!canRequestAds) {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                        consentCompleteListener.onConsentProcessed()
                    }
                } else consentCompleteListener.onConsentProcessed()
            },
            {
                consentCompleteListener.onConsentProcessed()
            }
        )
    }

    private val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() =
            consentInformation.privacyOptionsRequirementStatus ==
                    ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptionsForm(
        activity: Activity,
        onConsentFormDismissedListener: OnConsentFormDismissedListener
    ) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity, onConsentFormDismissedListener)
    }

    fun interface ConsentCompleteListener {
        fun onConsentProcessed()
    }

    companion object {

        @Volatile
        private var instance: AdsConsentManagerX? = null

        fun getInstance(context: Context) =
            instance
                ?: synchronized(this) {
                    instance ?: AdsConsentManagerX(context).also { instance = it }
                }
    }

    private fun Context.getAdmobHashId(): String {
        try {
            // Create MD5 Hash
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            val digest = java.security.MessageDigest.getInstance("MD5")
            digest.update(androidId.toByteArray())
            val messageDigest = digest.digest()

            // Create Hex String
            val hexString = StringBuilder()
            for (i in messageDigest.indices) {
                var h = Integer.toHexString(0xFF and messageDigest[i].toInt())
                while (h.length < 2)
                    h = "0$h"
                hexString.append(h)
            }
            return hexString.toString().uppercase()

        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }
        return ""
    }
}
