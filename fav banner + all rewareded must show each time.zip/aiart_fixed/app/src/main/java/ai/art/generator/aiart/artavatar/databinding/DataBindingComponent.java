package ai.art.generator.aiart.artavatar.databinding;

public interface DataBindingComponent {
}
