package ai.art.generator.aiart.artavatar.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class ImageCreditPreferences(context: Context) {

    companion object{
        const val SHARED_PREF_NAME = "ArtiCraftTheme"
        const val IMAGE_CREDIT = "image_credit"
    }

    private val sharedPreferences: SharedPreferences  = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)

    fun saveImageCreditPreferences(credit: Int) {
        sharedPreferences.edit {
            putInt(IMAGE_CREDIT, credit)
        }
    }

    fun getImageCreditPreferences(): Int{
        return sharedPreferences.getInt(IMAGE_CREDIT, 0)
    }

    fun clearStorage() = sharedPreferences.edit().clear().apply()
}