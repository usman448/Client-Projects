package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.model.HistoryModel


object Singleton {

    private var promptData = ""
    private var addedTagsList: MutableList<String> = mutableListOf()

    fun getPrompt(): String {
        return promptData
    }

    fun setPrompt(prompt: String) {
        promptData = prompt
    }

    fun getTagList(): MutableList<String> {
        return addedTagsList
    }


    private var negText = ""

    fun setNegativeText(text: String) {
        negText = text
    }

    fun getNegativeText(): String {
        return negText
    }


    private var negTag: MutableList<String> = mutableListOf()


    fun getNegativeTag(): MutableList<String> {
        return negTag
    }

    private var isInternetAvailable = true

    fun setIsInternetAvailable(isInternet: Boolean) {
        isInternetAvailable = isInternet
    }

    fun getIsInternetAvailable(): Boolean {
        return isInternetAvailable
    }

    private var isFromHistory: Boolean = false

    fun fromHistory(): Boolean {
        return isFromHistory
    }

    fun setIsFromHistory(value: Boolean) {
        isFromHistory = value
    }

}

var editHistoryModel: HistoryModel? = null