package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep


@Keep
data class RequestModel(
    val key: String,
    val model_id: String,
    val prompt: String,
    val negative_prompt: String,
    val width: String,
    val height: String,
    val samples: String,
    val num_inference_steps: String,
    val seed: Int?,
    val style_preset: String?,
    val guidance_scale: Float,

    val safety_checker: String,
    val safety_checker_type: String,
    val enhance_prompt: String,
    val tomesd: String,
    val use_karras_sigmas: String,
    val panorama: String,
    val self_attention: String,
    val clip_skip: String,
    val webhook: String?,
    val track_id: String?
    )
