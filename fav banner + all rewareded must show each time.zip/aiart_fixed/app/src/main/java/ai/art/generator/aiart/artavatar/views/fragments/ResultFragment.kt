package ai.art.generator.aiart.artavatar.views.fragments

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.adapter.ResultAdapter
import ai.art.generator.aiart.artavatar.databinding.FragmentResultBinding
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.model.RequestModel
import ai.art.generator.aiart.artavatar.storage.ImageCreditPreferences
import ai.art.generator.aiart.artavatar.storage.ImageTypePreferences
import ai.art.generator.aiart.artavatar.utilities.AppX
import ai.art.generator.aiart.artavatar.utilities.AppX.Companion.databaseHelper
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.isNetworkAvailable
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.setStylePrompt
import ai.art.generator.aiart.artavatar.utilities.Helper.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.Helper.showToast
import ai.art.generator.aiart.artavatar.utilities.RapidClicker
import ai.art.generator.aiart.artavatar.utilities.Singleton
import ai.art.generator.aiart.artavatar.utilities.convertCommaStringToList
import ai.art.generator.aiart.artavatar.utilities.dpToPx
import ai.art.generator.aiart.artavatar.utilities.editHistoryModel
import ai.art.generator.aiart.artavatar.utilities.ratingDialog
import ai.art.generator.aiart.artavatar.utilities.sendEmailX
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.viewmodel.MainViewModel
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import ai.art.generator.aiart.artavatar.views.activity.UserScreenNavigationState
import ai.art.generator.aiart.artavatar.views.dialoguefragments.EditPromptBottomSheet
import ai.art.generator.aiart.artavatar.views.dialoguefragments.ErrorBottomSheet
import ai.art.generator.aiart.artavatar.views.dialoguefragments.LoaderBottomFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.NoInternetFragment
import ai.art.generator.aiart.artavatar.views.dialoguefragments.ReportBottomSheet
import ai.art.generator.aiart.artavatar.views.dialoguefragments.WatchAdDialog
import android.Manifest.permission
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.android.gms.ads.nativead.NativeAd
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.InterAdLoaderX
import com.hm.admanagerx.RewardedAdLoaderX
import com.hm.admanagerx.isPremium
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class ResultFragment : Fragment(), ResultAdapter.OnItemClickListener, View.OnClickListener {

    private var sessionId: Int? = null
    private var currentImage: String? = null
    private var comesFromHistory = false

    private var resultAdapter: ResultAdapter? = null
    private var imageList: MutableList<String> = arrayListOf()
    private lateinit var binding: FragmentResultBinding
    private val viewModel: BottomSheetVM by activityViewModels()
    private val resultViewModel: MainViewModel by activityViewModels()
    private lateinit var imageTypePreferences: ImageTypePreferences
    private lateinit var imageCreditPreferences: ImageCreditPreferences
    private var loaderBottomFragment: LoaderBottomFragment? = null
    private var rewardedAd: RewardedAdLoaderX? = null
    private var mainNativeAd: NativeAd? = null
    private var savedImages: MutableList<String> = arrayListOf()
    private var tags: String = ""
    private var style: String = ""
    private var isFav = false
    private var previousIndicator: ImageView? = null
    private var itemModel: HistoryModel? = null
    private var itemsList: MutableList<HistoryModel> = arrayListOf()
    private var itemPosition = 0
    var mContext: Context? = null
    var mActivity: MainActivity? = null
    private var interAd: InterAdLoaderX? = null
    private lateinit var onBackPressedCallback: OnBackPressedCallback
    private var saveClickCounter = 0
    private val rapidClicker: RapidClicker = RapidClicker(1000)

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            sessionId = it.getInt(ARG_SESSION_ID)
            currentImage = it.getString(ARG_IMAGE_URL)
            comesFromHistory = it.getBoolean("openfrom")
        }
        imageTypePreferences = ImageTypePreferences(requireContext())
        onBackPressedCallback = object : OnBackPressedCallback(true /* enabled by default */) {
            override fun handleOnBackPressed() {
                Constants.userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY.label
                val fragmentManager = requireActivity().supportFragmentManager
                fragmentManager.popBackStack()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(
            requireActivity(),
            onBackPressedCallback
        )
        if (comesFromHistory) {
            mContext?.sendFirebaseEvents("history_result_screen_opened")
        } else {
            mContext?.sendFirebaseEvents("result_screen_opened")
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentResultBinding.inflate(inflater, container, false)
        Helper.hideKeyboard(mContext)
        getDataFromDb()
        setupUI()
        clickListeners()
        imageCreditPreferences = ImageCreditPreferences(requireContext())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        observer()
        if (mActivity?.isPremium() == true) {
            binding.generateMoreBtnText.setCompoundDrawablesWithIntrinsicBounds(
                null, null, null, null
            )
        }

        // ✅ FIX: Preload rewarded ads when ResultFragment opens
        // So they are ready when user clicks Generate More
        if (mActivity?.isPremium() == false) {
            if (!AdsManagerX.isRewardedAdLoaded(AdConfigManager.REWARDED_AD_GENERATE)) {
                AdsManagerX.loadRewardedAd(
                    lifecycleOwner = viewLifecycleOwner,
                    adConfigManager = AdConfigManager.REWARDED_AD_GENERATE
                )
            }
            if (!AdsManagerX.isRewardedInterstitialAdLoaded(AdConfigManager.REWARDED_INTER_AD)) {
                AdsManagerX.loadRewardedInterstitialAd(
                    lifecycleOwner = viewLifecycleOwner,
                    adConfigManager = AdConfigManager.REWARDED_INTER_AD
                )
            }
        }
    }

    private fun loadAds() {
        mainNativeAd = (mActivity?.application as AppX).mainNativeAd
        rewardedAd = (mActivity?.application as? AppX)?.rewardedAd
        interAd = (mActivity?.application as? AppX)?.interAdLoaderX

        /*     mainNativeAd.showNativeAd(
                 com.hm.admanagerx.R.layout.native_banner_new, binding.nativeAdContainer
             ) {
                 //load ad request if add not loaded
                 ((mActivity?.application as AppX).loadMainActivityNativeAd {
                     it.showNativeAd(
                         com.hm.admanagerx.R.layout.native_banner_new, binding.nativeAdContainer
                     )

                 })
             }*/
    }

    private fun observer() {
        viewModel.isPremium.observe(viewLifecycleOwner) { value ->
            if (value) {
                binding.generateMoreBtnText.setCompoundDrawablesWithIntrinsicBounds(
                    null, null, null, null
                )
                resultAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun updateValuesOnVpChanged() {
        // Assume HistoryModel has a constructor that takes all its properties as arguments
        val selectedItem = itemsList[itemPosition]
        itemModel = HistoryModel(
            id = selectedItem.id,
            sessionId = selectedItem.sessionId,
            prompt = selectedItem.prompt,
            imageUrl = selectedItem.imageUrl,
            tags = selectedItem.tags,
            style = selectedItem.style,
            model = selectedItem.model,
            modelName = selectedItem.modelName,
            height = selectedItem.height,
            width = selectedItem.width,
            negativePrompt = selectedItem.negativePrompt,
            cfg = selectedItem.cfg,
            steps = selectedItem.steps,
            highQuality = selectedItem.highQuality,
            favourite = selectedItem.favourite,
            count = selectedItem.count,
            time = selectedItem.time
        )

        viewModel.editTagsSelectionList = convertCommaStringToList(selectedItem.tags)

        itemModel?.let {
            binding.resultPrompt.text = it.prompt.trim()
            Singleton.setPrompt(it.prompt)
            Singleton.getTagList().clear()
            val delimiter = "," // Define the delimiter used in your string
            val stringList: List<String> = it.tags.split(delimiter)
            for (i in stringList) {
                if (i != "") {
                    Singleton.getTagList().add(i)
                }
            }
            mContext?.let { context ->
                if (it.favourite == 1) {
                    isFav = true
                    binding.favorite.setImageDrawable(
                        AppCompatResources.getDrawable(
                            context, R.drawable.ic_baseline_favorite_fill_24
                        )
                    )
                    //binding.favorite.setPadding(Helper.spToPx(context, 15F))
                } else {
                    isFav = false
                    binding.favorite.setImageDrawable(
                        AppCompatResources.getDrawable(
                            context, R.drawable.ic_baseline_favorite_24
                        )
                    )
                    //binding.favorite.setPadding(Helper.spToPx(context, 15F))
                }
            }

        }
    }

    private fun getDataFromDb() {
        sessionId?.let { databaseHelper.getRecordsBySessionId(it) }?.let {
            itemsList.addAll(it.reversed())
            Log.i(TAG, "getDataFromDb: ${itemsList.size}  $itemsList")
        }

        if (itemsList.size > 0) {
            if (itemsList.size > 1) binding.indicator.visibility =
                View.VISIBLE else binding.indicator.visibility = View.GONE
            for (i in itemsList) {
                imageList.add(i.imageUrl)
            }
        }
    }

    private fun setupUI() {

        var currentItemIndex = 0
        resultAdapter = mContext?.let { ResultAdapter(it, binding.viewPager) }
        resultAdapter?.setData(itemsList)
        resultAdapter?.setOnItemClickListener(this)

        for (i in 0 until itemsList.size) {
            if (i == 0) {
                addIndicator(R.drawable.single_indicator)
                previousIndicator = binding.indicator.getChildAt(0) as ImageView?
            } else {
                addIndicator(R.drawable.dot)
            }
            mContext?.let {
                if (itemsList[i].imageUrl == currentImage) {
                    currentItemIndex = i
                    resultAdapter?.setCurrentItemPosition(i)
                    if (itemsList[i].favourite == 1) {
                        isFav = true
                        binding.favorite.setImageDrawable(
                            AppCompatResources.getDrawable(
                                it, R.drawable.ic_baseline_favorite_fill_24
                            )
                        )
                        //binding.favorite.setPadding(Helper.spToPx(it, 15F))

                        itemModel?.favourite = 1
                    } else {
                        isFav = false
                        binding.favorite.setImageDrawable(
                            AppCompatResources.getDrawable(
                                it, R.drawable.ic_baseline_favorite_24
                            )
                        )
                        // binding.favorite.setPadding(Helper.spToPx(it, 15F))

                        itemModel?.favourite = 0
                    }
                }
            }

        }

        binding.viewPager.apply {
            offscreenPageLimit = 1
            val recyclerView = getChildAt(0) as RecyclerView
            recyclerView.apply {
                setPadding(
                    7.dpToPx(requireContext()).toInt(),
                    0,
                    7.dpToPx(requireContext()).toInt(),
                    0
                )
                clipToPadding = false
            }
            adapter = resultAdapter
        }

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                itemPosition = position

                // Set the currently visible item position in the adapter
                activity?.runOnUiThread {
                    updateValuesOnVpChanged()

                    previousIndicator?.setImageResource(R.drawable.dot)

                    if (binding.indicator.childCount > 0) {
                        val indicatorImage = binding.indicator.getChildAt(position) as ImageView
                        indicatorImage.setImageResource(R.drawable.single_indicator)

                        previousIndicator = indicatorImage
                    }

                    resultAdapter?.setCurrentItemPosition(position)
                }
            }
        })

        binding.viewPager.setCurrentItem(currentItemIndex, true)

    }

    private fun addIndicator(image: Int) {

        mContext?.let {
            val imageView = ImageView(it)
            imageView.setImageResource(image)

            val layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams.setMargins(
                Helper.spToPx(it, 3F), 0, Helper.spToPx(it, 3F), 0
            )
            imageView.layoutParams = layoutParams
            binding.indicator.addView(imageView)
        }

    }

    override fun onDetach() {
        mainNativeAd?.destroy()
        (mActivity?.application as AppX).mainNativeAd = null
        onBackPressedCallback.remove()
        super.onDetach()
    }

    private fun clickListeners() {
        binding.resultPromptLayout.setOnClickListener(this)
        binding.generateMoreBtn.setOnClickListener(this)
        binding.favorite.setOnClickListener(this)
        binding.report.setOnClickListener(this)
        binding.save.setOnClickListener(this)
        binding.share.setOnClickListener(this)
        binding.resultConstraintLayout.setOnClickListener {}

        //this code is write by waKas after theme change on back button click to go back history screen
        binding.backButtonImageView.setOnClickListener {
            mContext?.sendFirebaseEvents("result_screen_back_icon_clicked")
            Constants.userMovingScreenState = UserScreenNavigationState.MAIN_TO_HISTORY.label
            val fragmentManager = requireActivity().supportFragmentManager
            fragmentManager.popBackStack()
            if (Singleton.fromHistory()) {
                if (Constants.themeChange) {
                    Constants.themeChange = false
                    activity?.onBackPressed()
                }
            }
        }
    }

    override fun onItemClick(url: String) {
        mContext?.sendFirebaseEvents("image_preview_clicked")
        // mContext?.sendFirebaseEvents("image_preview", Bundle())
        val previewFragment: PreviewFragment = PreviewFragment.newInstance(imageList, url)
        val fragmentManager = activity?.supportFragmentManager
        val transaction = fragmentManager?.beginTransaction()
        transaction?.add(R.id.fragmentContainer, previewFragment)
        transaction?.addToBackStack(null)
        transaction?.commit()
    }

    override fun onPremiumClick() {
        mContext?.sendFirebaseEvents("pro_clicked")
        mActivity?.premiumLauncher?.launch(Intent(mContext, PremiumActivity::class.java))
    }

    private fun generateImage(itemModel: HistoryModel? = null) {
        itemModel?.let {
            mContext?.let {
                loaderBottomFragment = LoaderBottomFragment().apply {
                    isCancelable = false
                    show((it as MainActivity).supportFragmentManager, tag)
                }
            }

            binding.generateMoreBtn.isEnabled = false
            tags = viewModel.editTagsSelectionList.joinToString(", ")
            style = mContext?.setStylePrompt(it.style).orEmpty()
            val stylePreset = if (Constants.newStyleIdList.contains(it.style)) {
                mContext?.setStylePrompt(it.style)
            } else {
                null
            }
            val negativePrompt = it.negativePrompt.ifEmpty {
                getString(R.string.hardcoded_negative_prompt)
            }
            val requestObject = RequestModel(
                key = Constants.API_KEY,
                model_id = it.model,
                prompt = style + Helper.replaceEmojisWithText(it.prompt) + tags,
                negative_prompt = negativePrompt,
                width = it.width,
                height = it.height,
                samples = "1",
                num_inference_steps = it.steps,
                seed = 0,
                guidance_scale = it.cfg.toFloat(),
                style_preset = stylePreset,

                safety_checker = "yes",
                safety_checker_type = "sensitive_content_text",
                enhance_prompt = "no",
                tomesd = "yes",
                use_karras_sigmas = "yes",
                panorama = if (it.width != "1800") {
                    "no"
                } else {
                    "yes"
                },
                self_attention = it.highQuality,
                clip_skip = "1",
                webhook = null,
                track_id = null
            )
            Log.i(TAG, "generateImage: $requestObject")
            //add 5s delay for non-premium user
            lifecycleScope.launch {
                if (!requireContext().isPremium()) delay(5000)
                resultViewModel.createRequestX(requestObject, onSuccess = { result ->
                    Log.i(TAG, "generateImage: $result")
                    lifecycleScope.launch(Dispatchers.Main) {
                        delay(2000)
                        loadResultImage(result)
                    }

                }, onFailed = { errorMessage ->
                    errorDialog(errorMessage)
                })
            }
        }
    }

    private fun errorDialog(
        it: String,
    ) {
        mContext?.sendFirebaseEvents(
            "prompt_result_failed",
            Bundle().apply { getString("error", it) })
        Log.i("API ERROR RESPONSE", it)
        mActivity?.let {
            loaderBottomFragment?.dismissAllowingStateLoss()
            binding.generateMoreBtn.isEnabled = true
            ErrorBottomSheet().apply {
                onTryAgainBtnClick = {
                    if (mContext?.isNetworkAvailable() != true) {
                        if (saveClickCounter++ == 0) {
                            Singleton.setIsInternetAvailable(false)
                            val noInternetFragment = NoInternetFragment()
                            noInternetFragment.isCancelable = true
                            mActivity?.supportFragmentManager?.let { it1 ->
                                noInternetFragment.show(
                                    it1, noInternetFragment.tag
                                )
                            }
                            Handler(Looper.getMainLooper()).postDelayed({
                                saveClickCounter = 0
                            }, 1000)
                        }
                    } else {
                        Singleton.setIsInternetAvailable(true)
                        generateImage(itemModel)
                    }
                }
                show(it.supportFragmentManager, tag)
            }
        }
    }


    private fun loadResultImage(imageUrl: String) {
        if (mContext == null && mActivity == null) return
        Glide.with(mContext!!)
            .load(imageUrl)
            .apply(RequestOptions().override(500, 500))
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    if (mActivity!!.isDestroyed || mActivity!!.isFinishing) return false
                    Log.i("API ERROR URL", imageUrl)
                    lifecycleScope.launch(Dispatchers.Main) {
                        delay(2000)
                        loadResultImage(imageUrl)
                    }
                    return false // Return false to not display the placeholder or error image
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean,
                ): Boolean {
                    if (mActivity!!.isDestroyed || mActivity!!.isFinishing) return false
                    insertDataToDb(imageUrl)
                    return false
                }
            }).preload()
    }


    private fun insertDataToDb(output: String) {
        loaderBottomFragment?.setProgressComplete()
        binding.generateMoreBtn.isEnabled = true

        itemModel?.let {
            val responseItem = HistoryModel(
                databaseHelper.getRowCount() + 1,
                itemModel?.sessionId ?: -1,
                Singleton.getPrompt(),
                output,
                tags,
                it.style,
                it.model,
                it.modelName,
                it.height,
                it.width,
                it.negativePrompt,
                it.cfg,
                it.steps,
                it.highQuality,
                0,
                System.currentTimeMillis()
            )
            Log.i(TAG, "insertDataToDb: ${it.model}  ${it.modelName}")
            itemModel = responseItem

            resultViewModel.insertProduct(responseItem, databaseHelper)
            binding.resultPrompt.text = responseItem.prompt.trim()
            itemsList.add(0, responseItem)
            imageList.add(0, output)
            addIndicator(R.drawable.dot)
            if (itemsList.size > 1) binding.indicator.visibility =
                View.VISIBLE else binding.indicator.visibility = View.GONE
            resultAdapter?.setData(itemsList)
            binding.viewPager.setCurrentItem(0, true)
            updateValuesOnVpChanged()
        }

        lifecycleScope.launch {
            delay(500)
            loaderBottomFragment?.dismissAllowingStateLoss()
        }

    }

    override fun onClick(v: View?) {
        when (v) {
            binding.resultPromptLayout -> {
                rapidClicker.publish {
                    if (saveClickCounter++ == 0) {
                        mContext?.sendFirebaseEvents("edit_prompt_started")
                        mActivity?.let {
                            EditPromptBottomSheet.newInstance().apply {
                                editHistoryModel = itemModel
                                onEditGenerateClick = {
                                    itemModel?.prompt = it.prompt.toString()
                                    itemModel?.style = it.style
                                    itemModel?.model = it.model
                                    itemModel?.modelName = it.modelName
                                    itemModel?.negativePrompt =
                                        it.negative_prompt + it.negative_prompt_tags
                                    itemModel?.cfg = it.cfgScale.toString()
                                    itemModel?.steps = it.deNoising
                                    itemModel?.highQuality = it.hdQuality
                                    generateImage(itemModel)
                                }
                                show(it.supportFragmentManager, tag)
                            }
                        }

                        Handler(Looper.getMainLooper()).postDelayed({
                            saveClickCounter = 0
                        }, 1000)
                    }
                }
            }

            binding.generateMoreBtn -> {
                rapidClicker.publish {

                    if (requireActivity().isPremium()) {
                        // Premium users bypass all coin checks.
                        handleGenerateMoreButton()
                    } else {
                        // -----------------------------------------------------------
                        // REQUIREMENT 2 — REGENERATE COINS ENTRY POINT
                        //
                        // This is the coin check for the Regenerate button in ResultFragment.
                        // It shares the same coin counter and limit as the Generate button.
                        //
                        // To change the number of free regenerates:
                        //   → Constants.kt → IMAGE_CREDIT_LIMIT
                        //   (same variable as Generate — they share one counter)
                        //
                        // To give Regenerate its OWN separate coin limit:
                        //   Step 1: Constants.kt → uncomment REGENERATE_CREDIT_LIMIT and set value.
                        //   Step 2: Replace Constants.IMAGE_CREDIT_LIMIT below with
                        //           Constants.REGENERATE_CREDIT_LIMIT (2 places in this block).
                        //
                        // To change what happens when coins run out:
                        //   → Constants.kt → GENERATE_IMAGE_STATE
                        //   0 = always allow  |  1 = watch ad dialog  |  2 = go premium
                        // -----------------------------------------------------------
                        Log.i(
                            TAG,
                            "Regenerate clicked. Credits: ${imageCreditPreferences.getImageCreditPreferences()} / ${Constants.IMAGE_CREDIT_LIMIT}  State: ${Constants.GENERATE_IMAGE_STATE}"
                        )

                        // User still has free coins remaining → use one and regenerate.
                        if (imageCreditPreferences.getImageCreditPreferences() < Constants.IMAGE_CREDIT_LIMIT) {
                            // Increment the coin counter for this free regenerate.
                            imageCreditPreferences.saveImageCreditPreferences(imageCreditPreferences.getImageCreditPreferences() + 1)
                            handleGenerateMoreButton()
                        } else {
                            // Coins exhausted. Behaviour depends on GENERATE_IMAGE_STATE.
                            // To change this behaviour → Constants.kt → GENERATE_IMAGE_STATE
                            when (Constants.GENERATE_IMAGE_STATE) {
                                // 0 → Always allow regeneration (no ad, no block).
                                0 -> handleGenerateMoreButton()
                                // 1 → Show "Watch Ad" dialog. User watches rewarded ad to continue.
                                1 -> {
                                    val watchAdDialog = WatchAdDialog({
                                        when (it) {
                                            getString(R.string.watchAd) -> handleGenerateMoreButton()
                                        }
                                    }, "resultfragment")
                                    watchAdDialog.show(childFragmentManager, watchAdDialog.tag)
                                }
                                // 2 → Send user to Premium screen directly.
                                2 -> mActivity?.premiumLauncher?.launch(
                                    Intent(
                                        mActivity,
                                        PremiumActivity::class.java
                                    )
                                )

                                else -> handleGenerateMoreButton()
                            }
                        }
                    }
                }
            }

            binding.favorite -> {
                rapidClicker.publish {
                    val imageUrl = if (imageList.size > 0) {
                        imageList[binding.viewPager.currentItem]
                    } else {
                        ""
                    }
                    val id = resultViewModel.getID(imageUrl, databaseHelper)

                    if (isFav) {
                        isFav = false
                        binding.favorite.setImageDrawable(mContext?.let {
                            AppCompatResources.getDrawable(
                                it, R.drawable.ic_baseline_favorite_24
                            )
                        })

                        itemModel?.favourite = 0
                        itemsList[itemPosition].favourite = 0

                        val item = itemModel?.let {
                            HistoryModel(
                                it.id,
                                it.sessionId,
                                it.prompt,
                                imageUrl,
                                it.tags,
                                it.style,
                                it.model,
                                it.modelName,
                                it.height,
                                it.width,
                                it.negativePrompt,
                                it.cfg,
                                it.steps,
                                it.highQuality,
                                0,
                                System.currentTimeMillis()
                            )
                        }

                        if (item != null) {
                            if (comesFromHistory) {
                                handleFav?.invoke(item, isFav)
                            } else {
                                resultViewModel.removeFromFavourite(id, databaseHelper, item)
                            }
                        }
                        if (!comesFromHistory)
                            binding.flBannerBtmResult.visibility = View.VISIBLE
                        loadbtmbanner()
                        /*requireActivity().showSnackBar(
                            getString(R.string.remove_from_favourite),
                            binding.nativeAdContainer
                        )*/

                    } else {
                        isFav = true
                        binding.favorite.setImageDrawable(mContext?.let {
                            AppCompatResources.getDrawable(
                                it, R.drawable.ic_baseline_favorite_fill_24
                            )
                        })

                        itemModel?.favourite = 1
                        itemsList[itemPosition].favourite = 1

                        val item = itemModel?.let {
                            HistoryModel(
                                it.id,
                                it.sessionId,
                                it.prompt,
                                imageUrl,
                                it.tags,
                                it.style,
                                it.model,
                                it.modelName,
                                it.height,
                                it.width,
                                it.negativePrompt,
                                it.cfg,
                                it.steps,
                                it.highQuality,
                                1,
                                System.currentTimeMillis()
                            )
                        }

                        if (item != null) {
                            mContext?.sendFirebaseEvents("like_button_clicked")

                            if (comesFromHistory) {
                                handleFav?.invoke(item, isFav)
                            } else {
                                resultViewModel.addToFavourite(id, databaseHelper, item)
                            }
                        }
                        if (!comesFromHistory)
                        /* requireActivity().showSnackBar(
                             getString(R.string.add_to_favourite),
                             binding.nativeAdContainer
                         )*/
                            loadbtmbanner()
                    }
                    //mContext?.let { binding.favorite.setPadding(Helper.spToPx(it, 15F)) }
                }
            }

            binding.report -> {
                val reportDialog = ReportBottomSheet { message ->
                    //feedback
                    Log.e("none", "report: $message")
                    binding?.let { bind ->
                        val prompt = bind.resultPrompt.text.toString() ?: ""
                        val url = when {
                            itemsList.isEmpty() -> ""
                            itemPosition !in itemsList.indices -> ""
                            else -> itemsList[itemPosition].imageUrl
                        }
                        val bundle = Bundle()
                        bundle.putString("prompt", prompt)
                        bundle.putString("url", url)
                        bundle.putString("message", message)
                        mContext?.sendFirebaseEvents("content_reported", bundle)
                    }
                    mContext?.let {
                        (it as MainActivity).showSnackBar(
                            getString(R.string.report_submitted),
                            binding.flBannerBtmResult
                        )
//                        showToast(it, "Report Submitted")
                    }
                    /*val title = getString(R.string.report) + " " + getString(R.string.app_name)
                    mContext?.sendEmailX(
                        Constants.FEEDBACK,
                        title,
                        message
                    )*/
                }
                reportDialog.show(childFragmentManager, reportDialog.tag)
            }

            binding.save -> {

                rapidClicker.publish {
                    mContext?.sendFirebaseEvents("save_button_clicked")

                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {

                        Permissions.check(
                            mContext,
                            permission.WRITE_EXTERNAL_STORAGE,
                            null,
                            object : PermissionHandler() {
                                override fun onGranted() {
                                    saveButtonClick()
                                }

                                override fun onBlocked(
                                    context: Context?, blockedList: ArrayList<String>?,
                                ): Boolean {
                                    return super.onBlocked(context, blockedList)
                                }
                            })
                    } else {
                        saveButtonClick()
                    }
                }
            }

            binding.share -> {
                rapidClicker.publish {
                    mContext?.sendFirebaseEvents("share_button_clicked")
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) {
                            itemModel?.let {
                                try {
                                    val imageBitmap = Helper.addWaterMark(mContext, it.imageUrl)
                                    val shareIntent = Intent(Intent.ACTION_SEND)
                                    shareIntent.type = "image/*"
                                    val imageUri =
                                        imageBitmap?.let { it1 ->
                                            getImageUriFromBitmap(
                                                it1,
                                                imageTypePreferences.getImageTypePreferences()
                                                    .lowercase()
                                            )
                                        } // Implement this function to get the Uri from the Bitmap
                                    shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
                                    startActivity(
                                        Intent.createChooser(
                                            shareIntent,
                                            resources.getString(R.string.shareImageUrl)
                                        )
                                    )
                                } catch (_: Exception) {

                                }
                            }
                        }
                    }
                }
            }
        }
    }
    fun loadbtmbanner()
    {
        AdsManagerX.loadBannerAd(
            this,
            AdConfigManager.BANNER_AD_RESULT,
            binding.flBannerBtmResult,
            onAdLoaded = {
//            isAdLoaded = true
            },
            onAdFailed = {
                //  isAdLoaded = false
                binding.flBannerBtmResult.visibility = View.GONE
            }
        )
    }
    // -----------------------------------------------------------------------
    // REQUIREMENT 2 — REGENERATE AD FLOW
    //
    // Called after the coin check above confirms credits are exhausted
    // and the user agreed to watch an ad (or GENERATE_IMAGE_STATE = 0).
    //
    // Ad priority:
    //   Step 1: Try standard Rewarded Ad (REWARDED_AD_GENERATE).
    //   Step 2: If not loaded, try Rewarded Interstitial (REWARDED_INTER_AD).
    //   Step 3: If neither is ready, preload both for next time and generate anyway.
    //
    // After the user earns a reward, coin counter resets to 0 (onUserEarnedRewarded).
    // This gives the user a fresh set of free regenerates.
    //
    // To change the ad configs used here → AdConfigManager.kt
    // -----------------------------------------------------------------------
    private fun handleGenerateMoreButton() {
        mContext?.sendFirebaseEvents("result_scr_generate_more_clicked")

        if (requireActivity().isPremium()) {
            generateImage(itemModel)
            return
        }

        // Step 1: Try standard Rewarded Ad first.
        if (AdsManagerX.isRewardedAdLoaded(AdConfigManager.REWARDED_AD_GENERATE)) {

            var rewardEarned = false

            AdsManagerX.showRewardedAd(
                activity = requireActivity() as AppCompatActivity,
                adConfigManager = AdConfigManager.REWARDED_AD_GENERATE,

                // Reward earned only if user actually watched the full ad.
                // Reset coin counter to 0 → user gets fresh free regenerates.
                // To change reset value → change the 0 below.
                onUserEarnedRewarded = {
                    rewardEarned = true
                    imageCreditPreferences.saveImageCreditPreferences(0)
                },

                // After ad closes → reload ad for next time and generate image.
                onAdClose = {
                    // Reload rewarded ad so it is ready for the user's next click.
                    AdsManagerX.loadRewardedAd(
                        lifecycleOwner = viewLifecycleOwner,
                        adConfigManager = AdConfigManager.REWARDED_AD_GENERATE
                    )
                    generateImage(itemModel)
                }
            )

        }
        // Step 2: Standard Rewarded Ad not ready → try Rewarded Interstitial as fallback.
        else if (AdsManagerX.isRewardedInterstitialAdLoaded(AdConfigManager.REWARDED_INTER_AD)) {

            var rewardEarned = false

            AdsManagerX.showRewardedInterstitialAd(
                activity = requireActivity() as AppCompatActivity,
                adConfigManager = AdConfigManager.REWARDED_INTER_AD,

                // Reward earned only if user actually watched the full ad.
                // Reset coin counter to 0 → user gets fresh free regenerates.
                // To change reset value → change the 0 below.
                onUserEarnedRewarded = {
                    rewardEarned = true
                    imageCreditPreferences.saveImageCreditPreferences(0)
                },

                // After ad closes → reload both ads for next time and generate image.
                funBlock = {
                    // Reload both ads so they are ready for the user's next click.
                    AdsManagerX.loadRewardedAd(
                        lifecycleOwner = viewLifecycleOwner,
                        adConfigManager = AdConfigManager.REWARDED_AD_GENERATE
                    )
                    AdsManagerX.loadRewardedInterstitialAd(
                        lifecycleOwner = viewLifecycleOwner,
                        adConfigManager = AdConfigManager.REWARDED_INTER_AD
                    )
                    generateImage(itemModel)
                }
            )

        }
        // Step 3: Neither ad is ready → preload both for next time and allow generation
        // so the user is never stuck on the regenerate screen with no way forward.
        else {
            AdsManagerX.loadRewardedAd(
                lifecycleOwner = viewLifecycleOwner,
                adConfigManager = AdConfigManager.REWARDED_AD_GENERATE
            )
            AdsManagerX.loadRewardedInterstitialAd(
                lifecycleOwner = viewLifecycleOwner,
                adConfigManager = AdConfigManager.REWARDED_INTER_AD
            )
            generateImage(itemModel)
        }
    }

    private fun saveButtonClick() {
        binding.save.isEnabled = false
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                itemModel?.let {
                    val parts = itemModel?.imageUrl?.split('/')
                    val name = parts?.last()?.replace(".png", "")
                    if (!isImageFileExists(
                            getString(R.string.short_app_name) + "$name",
                            imageTypePreferences.getImageTypePreferences().lowercase()
                        )
                    ) {

                        try {
                            activity?.runOnUiThread {
                                savedImages.add(it.imageUrl)
                                binding.save.isEnabled = true
                                /* requireActivity().showSnackBar(
                                     getString(R.string.image_saved_successfully),
                                     binding.nativeAdContainer
                                 )*/
                            }

                            val imageBitmap = Helper.addWaterMark(mContext, it.imageUrl)
                            imageBitmap?.let { it1 ->
                                saveImageToMediaStore(
                                    bitmap = it1,
                                    title = getString(R.string.short_app_name) + "$name",
                                    extension = imageTypePreferences.getImageTypePreferences()
                                        .lowercase()
                                )
                            }

                        } catch (e: Exception) {
                            /*  requireActivity().showSnackBar(
                                  getString(R.string.please_wait),
                                  binding.nativeAdContainer
                              )*/
                            e.printStackTrace()
                        }
                    } else {
                        activity?.runOnUiThread {
                            binding.save.isEnabled = true
                            /*   requireActivity().showSnackBar(
                                   getString(R.string.image_already_saved),
                                   binding.nativeAdContainer
                               )*/
                        }
                    }
                }
            }
        }
    }

    private fun saveImageToMediaStore(
        bitmap: Bitmap, title: String, extension: String
    ) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    isImageFileExists(title, extension)
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.TITLE, title)
                        put(MediaStore.Images.Media.DISPLAY_NAME, "$title.$extension")
                        put(MediaStore.Images.Media.DESCRIPTION, "Modified Image")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/$extension")
                        put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
                    }

                    val resolver = mContext?.contentResolver
                    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                    } else {
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    }

                    val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        // For Android 10 and above, use MediaStore to insert the image
                        values.put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "Pictures/" + getString(R.string.short_app_name)
                        )

                        values.put(MediaStore.Images.Media.IS_PENDING, 1)
                        resolver?.insert(collection, values)
                    } else {
                        // For Android 9 and below, save the image directly to the file system

                        val imagesDirectory = File(
                            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                            getString(R.string.short_app_name)
                        )

                        if (!imagesDirectory.exists()) {
                            imagesDirectory.mkdirs()
                        }

                        val imageFile = File(imagesDirectory, "$title.$extension")

                        val stream: OutputStream = FileOutputStream(imageFile)
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                        stream.flush()
                        stream.close()

                        // Notify the media scanner about the new file
                        MediaScannerConnection.scanFile(
                            context, arrayOf(imageFile.toString()), null, null
                        )
                        Uri.fromFile(imageFile)
                    }

                    // Save the image
                    uri?.let {
                        resolver?.openOutputStream(uri)?.use { outputStream ->
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            values.clear()
                            values.put(MediaStore.Images.Media.IS_PENDING, 0)
                            resolver?.update(uri, values, null, null)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }


    private fun isImageFileExists(title: String, extension: String): Boolean {
        val imagesDirectory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            getString(R.string.short_app_name)
        )
        val imageFile = File(imagesDirectory, "$title.$extension")
        return imageFile.exists()
    }

    private fun getImageUriFromBitmap(bitmap: Bitmap, type: String): Uri? {
        return mContext?.let {
            val cachePath = File(it.cacheDir, "images")
            cachePath.mkdirs()
            val imageFile = File(cachePath, "image.$type")
            val fileOutputStream = FileOutputStream(imageFile)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
            fileOutputStream.flush()
            fileOutputStream.close()
            FileProvider.getUriForFile(
                it, "${it.packageName}.provider", imageFile
            )
        }
    }

    override fun onResume() {
        super.onResume()

        if (!requireActivity().isPremium()) {
            loadbtmbanner()
        } else {
            binding.flBannerBtmResult.visibility = View.GONE
        }
    }

    companion object {
        const val TAG = "ResultFragInfo"
        const val ARG_SESSION_ID = "session_id"
        const val ARG_IMAGE_URL = "image_url"

        @JvmStatic
        fun newInstance(isfromHistoryFragment: Boolean = false, sessionId: Int, imageUrl: String) =
            ResultFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SESSION_ID, sessionId)
                    putString(ARG_IMAGE_URL, imageUrl)
                    putBoolean("openfrom", isfromHistoryFragment)
                }
            }
    }

}