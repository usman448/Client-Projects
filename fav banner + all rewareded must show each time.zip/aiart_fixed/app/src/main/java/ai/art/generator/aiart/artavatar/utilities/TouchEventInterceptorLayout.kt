package ai.art.generator.aiart.artavatar.utilities

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent

import android.widget.FrameLayout


class TouchEventInterceptorLayout(context: Context, attrs: AttributeSet?) :
    FrameLayout(context, attrs) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val handled = super.dispatchTouchEvent(ev)
        requestDisallowInterceptTouchEvent(true)
        return handled
    }
}