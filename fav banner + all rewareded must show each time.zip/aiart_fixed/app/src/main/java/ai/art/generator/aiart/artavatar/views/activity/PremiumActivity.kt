package ai.art.generator.aiart.artavatar.views.activity

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.ActivityPremiumBinding
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper.isNetworkAvailable
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.IN_APP_ITEM_1
import ai.art.generator.aiart.artavatar.utilities.IN_APP_ITEM_2
import ai.art.generator.aiart.artavatar.utilities.NetworkChangeReceiver
import ai.art.generator.aiart.artavatar.utilities.RapidClicker
import ai.art.generator.aiart.artavatar.utilities.hideSystemUI
import ai.art.generator.aiart.artavatar.utilities.initFirebaseRemoteConfig
import ai.art.generator.aiart.artavatar.utilities.onPriceUpdate
import ai.art.generator.aiart.artavatar.utilities.showSubscriptionDetailsDialog
import ai.art.generator.aiart.artavatar.utilities.statusBarAndNavBarColourChanger
import ai.art.generator.aiart.artavatar.utilities.transparentStatusBar
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.browser.customtabs.CustomTabsIntent
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.hm.admanagerx.IS_PREMIUM
import com.hm.admanagerx.isAppOpenAdShow
import com.hm.admanagerx.utility.TinyDB
import com.limurse.iap.DataWrappers
import com.limurse.iap.IapConnector
import com.limurse.iap.PurchaseServiceListener
import com.limurse.iap.SubscriptionServiceListener

const val YEARLY_SUB_ID = "yearly"
const val WEEKLY_SUB_ID = "weekly"
const val MONTHLY_SUB_ID = "monthly"
const val LIFE_TIME = "lifetime"
private const val TAG = "PremiumActivityInfo"

class PremiumActivity : BaseActivityX() {
    private var networkReceiver: NetworkChangeReceiver? = null
    private lateinit var binding: ActivityPremiumBinding
    private var iapConnector: IapConnector? = null
    private var selectedLayout: ConstraintLayout? = null
    private var subDialog: Dialog? = null
    private val rapidClicker: RapidClicker = RapidClicker(1000)
    private var lifeTimeValue = "Rs 14,199.00"
    private var yearlyValue = "Rs 8,500.00"
    private var monthlyValue = "Rs 1,150.00"
    private var weeklyValue = "Rs 1,000.00"
    private var inAppItem1 = ""
    private var inAppItem2 = ""
    private var lifeTimeTrialEnable = false
    private var yearlyTrialEnable = false
    private var monthlyTrialEnable = false
    private var lifeTimeTrialDetails = ""
    private var yearlyTrialDetails = ""
    private var monthlyTrialDetails = ""
    private var isSkuInitialized = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPremiumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selectedLayout= binding.clYearly
//        binding.tvYearlyPrice.text = getString(R.string.monthly_value, "Rs 8,500")
//        binding.tvYearlyPerMonth.visibility = View.GONE
//
//        binding.tvWeeklyPrice.text = getString(R.string.monthly_value, " Rs 1,150")
//        binding.tvWeeklyPerMonth.visibility = View.GONE

        isAppOpenAdShow(false)
        inAppItem1 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_1)
        inAppItem2 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_2)

        Log.i(TAG, "onCreate:before inAppItem1:$inAppItem1  inAppItem2:$inAppItem2")
        if (
            inAppItem1.isEmpty() || inAppItem1.isNotEmpty()
            && !inAppItem1.contains(YEARLY_SUB_ID)
            && !inAppItem1.contains(MONTHLY_SUB_ID)
            && !inAppItem1.contains(WEEKLY_SUB_ID)
            && !inAppItem1.contains(LIFE_TIME)
        ) {
            inAppItem1 = WEEKLY_SUB_ID
        }
        if (inAppItem2.isEmpty() || inAppItem2.isNotEmpty()
            && !inAppItem2.contains(YEARLY_SUB_ID)
            && !inAppItem2.contains(MONTHLY_SUB_ID)
            && !inAppItem2.contains(WEEKLY_SUB_ID)
            && !inAppItem2.contains(LIFE_TIME)
        ) {
            inAppItem2 = MONTHLY_SUB_ID
        }

        Log.i(TAG, "onCreate:after inAppItem1:$inAppItem1  inAppItem2:$inAppItem2")

        transparentStatusBar()
        statusBarAndNavBarColourChanger(android.R.color.transparent, true)
        initUI()
        initIap()
        clickListeners()
        networkObserver()
        // video animation
        val videoResId = R.raw.in_app_video
        val videoUri = Uri.parse("android.resource://$packageName/$videoResId")
        binding.videoView.setVideoURI(videoUri)
        binding.videoView.start()
        binding.videoView.setOnCompletionListener {
            binding.videoView.start()
        }
    }

    private fun toggleOverlay(selectedLayout: ConstraintLayout) {
        when (selectedLayout) {
            binding.clYearly -> {
                this.selectedLayout = binding.clYearly

            }

            binding.clWeekly -> {
                this.selectedLayout = binding.clWeekly
            }
        }

    }

    private fun networkObserver() {
        networkReceiver = NetworkChangeReceiver { isConnected ->
            if (!isConnected) {
                isSkuInitialized = false
            } else {
                if (!isSkuInitialized) {
                    isSkuInitialized = true
                    initFirebaseRemoteConfig() {
                        inAppItem1 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_1)
                        inAppItem2 = FirebaseRemoteConfig.getInstance().getString(IN_APP_ITEM_2)
                        initIap()
                    }
                }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            registerReceiver(
                networkReceiver,
                IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION),
                Context.RECEIVER_EXPORTED
            )
        } else {
            registerReceiver(networkReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
        }
    }

    private fun initIap() {
        val lifeTimeId = if (inAppItem1.contains(LIFE_TIME)) {
            inAppItem1
        } else if (inAppItem2.contains(LIFE_TIME)) {
            inAppItem2
        } else {
            LIFE_TIME
        }
        val nonConsumablesList = listOf(lifeTimeId)
        val subsList = listOf(inAppItem1, inAppItem2)
        Log.i(
            TAG,
            "initIap: inAppItem1:$inAppItem1  inAppItem2:$inAppItem2  LifeTimeId:$lifeTimeId"
        )
        iapConnector = IapConnector(
            context = this,
            nonConsumableKeys = nonConsumablesList,
            subscriptionKeys = subsList
        )
        iapConnector?.addSubscriptionListener(object : SubscriptionServiceListener {

            override fun onPricesUpdated(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
                setUiData(iapKeyPrices)
            }

            override fun onPurchaseFailed(
                purchaseInfo: DataWrappers.PurchaseInfo?,
                billingResponseCode: Int?
            ) {

            }

            override fun onSubscriptionPurchased(purchaseInfo: DataWrappers.PurchaseInfo) {
                purchaseSuccess()
            }

            override fun onSubscriptionRestored(purchaseInfo: DataWrappers.PurchaseInfo) {}
        })

        iapConnector?.addPurchaseListener(object : PurchaseServiceListener {
            override fun onPricesUpdated(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
                setUiData(iapKeyPrices)
            }

            override fun onProductPurchased(purchaseInfo: DataWrappers.PurchaseInfo) {
                purchaseSuccess()
            }

            override fun onProductRestored(purchaseInfo: DataWrappers.PurchaseInfo) {

            }

            override fun onPurchaseFailed(
                purchaseInfo: DataWrappers.PurchaseInfo?,
                billingResponseCode: Int?
            ) {

            }
        })
    }

    private fun purchaseSuccess() {
        TinyDB.getInstance(this@PremiumActivity).putBoolean(IS_PREMIUM, true)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setInitialInAppValues() {
        val lifeTimeValue = TinyDB.getInstance(this).getString(LIFE_TIME)
        lifeTimeValue?.ifEmpty { "Rs 14,199.00" }?.let { value ->
            lifeTimeTrialDetails = if (TinyDB.getInstance(this)
                    .getBoolean("lifeTimeTrialEnable")
            ) "${getString(R.string.trialDetails)} ${
                getString(
                    R.string.lifetime_value,
                    lifeTimeValue
                )
            }" else ""
            if (inAppItem1.contains("lifetime")) {
                binding.tvYearlyPrice.text = getString(R.string.lifetime_value,  value)
                binding.tvYearlyPerMonth.visibility = View.GONE
            }
            if (inAppItem2.contains("lifetime")) {
                binding.tvWeeklyPrice.text = getString(R.string.lifetime_value, value)
                binding.tvWeeklyPerMonth.visibility = View.GONE
            }
            binding.tvBullet2TextLifetime.text =
                getString(R.string.one_time_payment_of_s, lifeTimeValue)
        }
        val yearlyValue = TinyDB.getInstance(this).getString(YEARLY_SUB_ID)
        yearlyValue?.ifEmpty { "Rs 8,500.00" }?.let { value ->
            yearlyTrialDetails = if (TinyDB.getInstance(this)
                    .getBoolean("yearlyTrialEnable")
            ) "${getString(R.string.trialDetails)} ${
                getString(
                    R.string.yearly_value,
                    value
                )
            }" else ""
            val priceString = value.replace(
                "[^0-9.]".toRegex(),
                ""
            ) // Removes "Rs", "," and keeps only numbers and "."
            val priceDouble =
                priceString.toDoubleOrNull() ?: 0.0 // Handles potential conversion errors
            val monthlyPrice = priceDouble / 12
            val formattedMonthlyPrice =
                String.format("%.2f", monthlyPrice) // Formats to 2 decimal places
            if (inAppItem1.contains("yearly")) {
                binding.tvYearlyPrice.text = getString(R.string.yearly_value, value)
                binding.tvYearlyPerMonth.text =
                    getString(R.string.yearly_per_month_format, formattedMonthlyPrice)
            }
            if (inAppItem2.contains("yearly")) {
                binding.tvWeeklyPrice.text = getString(R.string.yearly_value, value)
                binding.tvWeeklyPerMonth.text =
                    getString(R.string.yearly_per_month_format, formattedMonthlyPrice)

            }
            binding.tvBullet2TextLifetime.text =
                getString(R.string.one_time_payment_of_s, lifeTimeValue)
            binding.tvBullet1TextIi.text =
                getString(R.string.subscription_detail_desc_ii, yearlyValue)
            binding.tvBullet3Text.text = getString(R.string.subscriptions_yearly, yearlyValue)
        }
        val monthlyValue = TinyDB.getInstance(this).getString(MONTHLY_SUB_ID)
        monthlyValue?.ifEmpty { "Rs 1,150.00" }.let { value ->
            monthlyTrialDetails = if (TinyDB.getInstance(this)
                    .getBoolean("monthlyTrialEnable")
            ) "${getString(R.string.trialDetails)} ${
                getString(
                    R.string.monthly_value,
                    value
                )
            }" else ""
            if (inAppItem1.contains("monthly")) {
                binding.tvYearlyPrice.text = getString(R.string.monthly_value, value)
                binding.tvYearlyPerMonth.visibility = View.GONE
            }
            if (inAppItem2.contains("monthly")) {
                binding.tvWeeklyPrice.text = getString(R.string.monthly_value, value)
                binding.tvWeeklyPerMonth.visibility = View.GONE
            }
            binding.tvBullet2TextLifetime.text =
                getString(R.string.one_time_payment_of_s, lifeTimeValue)
            binding.tvBullet1TextIi.text =
                getString(R.string.subscription_detail_desc_ii, monthlyValue)
            binding.tvBullet3Text.text = getString(R.string.subscriptions_monthly, monthlyValue)
        }
        val weeklyValue = TinyDB.getInstance(this).getString(WEEKLY_SUB_ID)
        weeklyValue?.ifEmpty { "Rs 1,000.00" }.let { value ->
            if (inAppItem1.contains("weekly")) {
                binding.tvYearlyPrice.text = getString(R.string.weekly_value, value)
                binding.tvYearlyPerMonth.visibility = View.GONE
            }
            if (inAppItem2.contains("weekly")) {
                binding.tvWeeklyPrice.text = getString(R.string.weekly_value, value)
                binding.tvWeeklyPerMonth.visibility = View.GONE
            }
            binding.tvBullet2TextLifetime.text =
                getString(R.string.one_time_payment_of_s, lifeTimeValue)
            binding.tvWeeklyBullet1Text.text = getString(R.string.subscriptions_weekly, weeklyValue)
        }


        handelInAppItem(inAppItem1)
        toggleDetailText(inAppItem1)

        var isYearly = ""
        var isWeekly = ""
        var isMonthly = ""
        var isLifeTime = ""
        when {
            inAppItem1.contains("lifetime") -> isLifeTime =
                "$lifeTimeValue ${getString(R.string.lifetime)}"

            inAppItem1.contains("yearly") -> isYearly = "$yearlyValue ${getString(R.string.yearly)}"
            inAppItem1.contains("monthly") -> isMonthly = "$monthlyValue Monthly"
            inAppItem1.contains("weekly") -> isWeekly = "$weeklyValue ${getString(R.string.weekly)}"
        }
        when {
            inAppItem2.contains("lifetime") -> isLifeTime =
                "$lifeTimeValue ${getString(R.string.lifetime)}"

            inAppItem2.contains("yearly") -> isYearly = "$yearlyValue ${getString(R.string.yearly)}"
            inAppItem2.contains("monthly") -> isMonthly = "$monthlyValue Monthly"
            inAppItem2.contains("weekly") -> isWeekly = "$weeklyValue ${getString(R.string.weekly)}"
        }

        onPriceUpdate?.invoke("${getString(R.string.subscriptions)} $isYearly, $isWeekly, $isLifeTime, $isMonthly.")

    }

    private fun setUiData(iapKeyPrices: Map<String, List<DataWrappers.ProductDetails>>) {
        iapKeyPrices.forEach {
            val item = it.value[0]
            Log.i(TAG, "setUiData: ${it.key}")
            Log.i(TAG, "setUiData: ${it.value}")
            if (it.key.contains(LIFE_TIME)) {
                lifeTimeTrialEnable = it.value[0].price.orEmpty().contains(getString(R.string.free))|| it.value[0].priceAmount==0.0
                lifeTimeValue =
                    if (lifeTimeTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                lifeTimeTrialDetails =
                    if (lifeTimeTrialEnable) "${getString(R.string.trialDetails)} ${
                        getString(
                            R.string.lifetime_value,
                            lifeTimeValue
                        )
                    }" else ""
                if (inAppItem1.contains("lifetime")) {
                    binding.tvYearlyPrice.text = getString(R.string.lifetime_value, lifeTimeValue)
                    binding.tvYearlyPerMonth.visibility = View.GONE
                }
                if (inAppItem2.contains("lifetime")) {
                    binding.tvWeeklyPrice.text = getString(R.string.lifetime_value, lifeTimeValue)
                    binding.tvWeeklyPerMonth.visibility = View.GONE
                }
            } else if (it.key.contains(YEARLY_SUB_ID)) {
                yearlyTrialEnable = it.value[0].price.orEmpty().contains(getString(R.string.free)) || it.value[0].priceAmount==0.0
                yearlyValue =
                    if (yearlyTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                yearlyTrialDetails = if (yearlyTrialEnable) "${getString(R.string.trialDetails)} ${
                    getString(
                        R.string.yearly_value,
                        yearlyValue
                    )
                }" else ""
                val priceString = yearlyValue.replace(
                    "[^0-9.]".toRegex(),
                    ""
                ) // Removes "Rs", "," and keeps only numbers and "."
                val priceDouble =
                    priceString.toDoubleOrNull() ?: 0.0 // Handles potential conversion errors
                val monthlyPrice = priceDouble / 12
                val formattedMonthlyPrice =
                    String.format("%.2f", monthlyPrice) // Formats to 2 decimal places
                if (inAppItem1.contains("yearly")) {
                    binding.tvYearlyPrice.text = getString(R.string.yearly_value, yearlyValue)
                    binding.tvYearlyPerMonth.text =
                        getString(R.string.yearly_per_month_format, formattedMonthlyPrice)
                }
                if (inAppItem2.contains("yearly")) {
                    binding.tvWeeklyPrice.text = getString(R.string.yearly_value, yearlyValue)
                    binding.tvWeeklyPerMonth.text =
                        getString(R.string.yearly_per_month_format, formattedMonthlyPrice)
                }
            } else if (it.key.contains(MONTHLY_SUB_ID)) {
                monthlyTrialEnable = it.value[0].price.orEmpty().contains(getString(R.string.free))|| it.value[0].priceAmount==0.0
                monthlyValue =
                    if (monthlyTrialEnable) it.value[1].price ?: "0.0" else item.price ?: "0.0"
                monthlyTrialDetails =
                    if (monthlyTrialEnable) "${getString(R.string.trialDetails)} ${
                        getString(
                            R.string.monthly_value,
                            monthlyValue
                        )
                    }" else ""
                if (inAppItem1.contains("monthly")) {
                    binding.tvYearlyPrice.text = getString(R.string.monthly_value, monthlyValue)
                    binding.tvYearlyPerMonth.visibility = View.GONE

                }
                if (inAppItem2.contains("monthly")) {
                    binding.tvWeeklyPrice.text = getString(R.string.monthly_value, monthlyValue)
                    binding.tvWeeklyPerMonth.visibility = View.GONE
                }
            } else if (it.key.contains(WEEKLY_SUB_ID)) {
                weeklyValue = item.price ?: "0.0"
                if (inAppItem1.contains("weekly")) {
                    binding.tvYearlyPrice.text = getString(R.string.weekly_value, weeklyValue)
                    binding.tvYearlyPerMonth.visibility = View.GONE
                }
                if (inAppItem2.contains("weekly")) {
                    binding.tvWeeklyPrice.text = getString(R.string.weekly_value, weeklyValue)
                    binding.tvWeeklyPerMonth.visibility = View.GONE
                }
            }
        }
        Log.d(TAG, "setUiData: ${selectedLayout == binding.clYearly}")
        Log.d(TAG, "setUiData: ${selectedLayout}\n${binding.clYearly}")



        var isYearly = ""
        var isWeekly = ""
        var isMonthly = ""
        var isLifeTime = ""
        when {
            inAppItem1.contains("lifetime") -> isLifeTime =
                "$lifeTimeValue ${getString(R.string.lifetime)}"

            inAppItem1.contains("yearly") -> isYearly = "$yearlyValue ${getString(R.string.yearly)}"
            inAppItem1.contains("monthly") -> isMonthly = "$monthlyValue Monthly"
            inAppItem1.contains("weekly") -> isWeekly = "$weeklyValue ${getString(R.string.weekly)}"
        }
        when {
            inAppItem2.contains("lifetime") -> isLifeTime =
                "$lifeTimeValue ${getString(R.string.lifetime)}"

            inAppItem2.contains("yearly") -> isYearly = "$yearlyValue ${getString(R.string.yearly)}"
            inAppItem2.contains("monthly") -> isMonthly = "$monthlyValue Monthly"
            inAppItem2.contains("weekly") -> isWeekly = "$weeklyValue ${getString(R.string.weekly)}"
        }
        /*if (inAppItem1.contains("lifetime")) {
            binding.nsInappLifetime.visibility = View.VISIBLE
            binding.nsInapp.visibility = View.GONE
            binding.nsInAppWeekly.visibility = View.GONE
        } else if (inAppItem1.contains("weekly")) {
            binding.nsInAppWeekly.visibility = View.VISIBLE
            binding.nsInapp.visibility = View.GONE
            binding.nsInappLifetime.visibility = View.GONE
        } else {
            binding.nsInapp.visibility = View.VISIBLE
            binding.nsInappLifetime.visibility = View.GONE
            binding.nsInAppWeekly.visibility = View.GONE
        }*/

        if (selectedLayout == binding.clYearly) {
            toggleDetailText(inAppItem1)
            handelInAppItem(inAppItem1)
        } else {
            toggleDetailText(inAppItem2)
            handelInAppItem(inAppItem2)
        }

        onPriceUpdate?.invoke("${getString(R.string.subscriptions)} $isYearly, $isWeekly, $isLifeTime, $isMonthly.")
    }

    private fun initUI() {
        setInitialInAppValues()

        toggleOverlay(selectedLayout?:binding.clYearly)
        subDialog = showSubscriptionDetailsDialog()
        val fullString =
            "${getString(R.string.continue_to_agree)} ${getString(R.string.terms)} & ${getString(R.string.privacy_policy)} ${
                getString(R.string.or_see_more)
            } ${getString(R.string.details)}"
        binding.tvPrivacyPolicy.setOnClickListener {
            openCustomTabView(Constants.PRIVACY_POLICY)
        }
        binding.tvTerms.setOnClickListener {
            openCustomTabView(Constants.TERMS_AND_CONDITIONS)
        }

        AnimationUtils.loadAnimation(this, R.anim.purchase_btn_anim)
            .also { hyperspaceJumpAnimation ->
                binding.btnContinueLayout.startAnimation(hyperspaceJumpAnimation)
            }
    }

    private fun clickListeners() {

        binding.apply {

            btnClose.setOnClickListener {
                onBackPressed()
            }

            clYearly.setOnClickListener {
                toggleDetailText(inAppItem1)
                handelInAppItem(inAppItem1)
                handelPurchaseSelection(
                    layout = clYearly,
                    radioButton = AppCompatResources.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_select_radio
                    ),
                    radioButton1 = AppCompatResources.getDrawable(
                        this@PremiumActivity,
                        R.drawable.unchecked_btn
                    ),
                    yearlyBg = ContextCompat.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_premium_yearly_button_bg
                    ),
                    yearlyTint = ContextCompat.getColorStateList(
                        this@PremiumActivity,
                        R.color.yellowColor
                    ),
                    weekBg = ContextCompat.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_weekly_bg
                    ),
                    weeklyTint = null
                )
            }
            clWeekly.setOnClickListener {
                toggleDetailText(inAppItem2)
                handelInAppItem(inAppItem2)
                handelPurchaseSelection(
                    layout = clWeekly,
                    radioButton = AppCompatResources.getDrawable(
                        this@PremiumActivity,
                        R.drawable.unchecked_btn
                    ),
                    radioButton1 = AppCompatResources.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_select_radio
                    ),
                    yearlyBg = ContextCompat.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_weekly_bg
                    ),
                    yearlyTint = null,
                    weekBg = ContextCompat.getDrawable(
                        this@PremiumActivity,
                        R.drawable.ic_premium_yearly_button_bg
                    ),
                    weeklyTint = ContextCompat.getColorStateList(
                        this@PremiumActivity,
                        R.color.yellowColor
                    )
                )
            }

            btnContinue.setOnClickListener {
                sendFirebaseEvents("premium_activity_completed")
                when (selectedLayout) {

                    binding.clYearly -> {
                        processPurchase(inAppItem1)

                    }

                    binding.clWeekly -> {
                        processPurchase(inAppItem2)

                    }
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent =
            Intent(this, MainActivity::class.java) // Replace with your actual Main Activity name
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        startActivity(intent)
        finish()
    }

    private fun toggleDetailText(item: String) {

        when {
            item.contains("lifetime") -> {
                binding.nsInappLifetime.visibility = View.VISIBLE
                binding.nsInapp.visibility = View.GONE
                binding.nsInAppWeekly.visibility = View.GONE

            }

            item.contains("weekly") -> {
                binding.nsInAppWeekly.visibility = View.VISIBLE
                binding.nsInapp.visibility = View.GONE
                binding.nsInappLifetime.visibility = View.GONE

            }
            item.contains("monthly") -> {
                binding.nsInapp.visibility = View.VISIBLE
                binding.nsInappLifetime.visibility = View.GONE
                binding.nsInAppWeekly.visibility = View.GONE

            }
            item.contains("yearly") -> {
                binding.nsInapp.visibility = View.VISIBLE
                binding.nsInappLifetime.visibility = View.GONE
                binding.nsInAppWeekly.visibility = View.GONE

            }
        }
    }

    private fun handelPurchaseSelection(
        layout: ConstraintLayout,
        radioButton: Drawable?,
        radioButton1: Drawable?,
        yearlyBg: Drawable?,
        yearlyTint: ColorStateList?,
        weekBg: Drawable?,
        weeklyTint: ColorStateList?
    ) {
        selectedLayout = layout
        binding.radioButtonImageview.setImageDrawable(radioButton)
        binding.radioButton1Imageview.setImageDrawable(radioButton1)
        binding.clYearly.background = yearlyBg
        binding.clYearly.backgroundTintList = yearlyTint
        binding.clWeekly.background = weekBg
        binding.clWeekly.backgroundTintList = weeklyTint

    }

    private fun handelInAppItem(item: String) {
        when {
            item.contains("lifetime") -> {
                binding.trialDetailsTextview.text = lifeTimeTrialDetails

                binding.btnContinue.text =
                    if (lifeTimeTrialEnable) getString(R.string.start_free_trial) else getString(R.string._continue)
                binding.tvBullet2TextLifetime.text =
                    getString(R.string.one_time_payment_of_s, lifeTimeValue)
            }

            item.contains("yearly") -> {
                binding.trialDetailsTextview.text = yearlyTrialDetails
                binding.btnContinue.text =
                    if (yearlyTrialEnable) getString(R.string.start_free_trial) else getString(R.string._continue)
                binding.tvBullet1TextIi.text =
                    getString(R.string.subscription_detail_desc_ii, yearlyValue)
                binding.tvBullet3Text.text = getString(R.string.subscriptions_yearly, yearlyValue)
            }

            item.contains("monthly") -> {
                binding.trialDetailsTextview.text = monthlyTrialDetails
                binding.btnContinue.text =
                    if (monthlyTrialEnable) getString(R.string.start_free_trial) else getString(R.string._continue)
                binding.tvBullet1TextIi.text =
                    getString(R.string.subscription_detail_desc_ii, monthlyValue)
                binding.tvBullet3Text.text = getString(R.string.subscriptions_monthly, monthlyValue)
            }

            item.contains("weekly") -> {
                binding.trialDetailsTextview.text = ""
                binding.btnContinue.text = getString(R.string._continue)
                binding.tvWeeklyBullet1Text.text = getString(R.string.subscriptions_weekly, weeklyValue)
            }
        }
    }

    private fun openCustomTabView(url: String?) {
        try {
            val builder = CustomTabsIntent.Builder()
            val customTabsIntent: CustomTabsIntent = builder.build()
            customTabsIntent.launchUrl(this, Uri.parse(url))
        } catch (ignored: java.lang.Exception) {
        }
    }

    private fun processPurchase(idSubscription: String) {

        if (isNetworkAvailable()) {
            iapConnector?.subscribe(this, idSubscription) {
                showSnackBar(
                    getString(R.string.google_billing_service_is_not_ready_yet),
                    binding.btnContinue
                )
            }
        } else {
            showSnackBar(
                getString(R.string.please_check_the_internet_connection),
                binding.btnContinue
            )
        }
    }

    private fun TextView.underLineAndClickableTxtNew(dialog: Dialog?, fullString: String) {
        // Get localized strings
        val terms = context.getString(R.string.terms)
        val privacyPolicy = context.getString(R.string.privacy_policy)
        val details = context.getString(R.string.details)
        // Create the formatted string
        val fullText = String.format(fullString, terms, privacyPolicy, details)
        // Create a SpannableString
        val spannableString = SpannableString(fullText)
        // Define ClickableSpan for "Terms"
        val termsClickableSpan = object : ClickableSpan() {
            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(this@PremiumActivity, R.color.dark_red)
            }

            override fun onClick(widget: View) {
                openCustomTabView(Constants.TERMS_AND_CONDITIONS)
            }
        }
        // Define ClickableSpan for "Privacy Policy"
        val privacyPolicyClickableSpan = object : ClickableSpan() {
            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(this@PremiumActivity, R.color.dark_red)
            }

            override fun onClick(widget: View) {
                openCustomTabView(Constants.PRIVACY_POLICY)
            }
        }
        // Define ClickableSpan for "Details"
        val detailsClickableSpan = object : ClickableSpan() {
            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(this@PremiumActivity, R.color.dark_red)
            }

            override fun onClick(widget: View) {
                rapidClicker.publish {
                    dialog?.show()
                }
            }
        }

        // UnderlineSpan for "Terms"
        val termsUnderlineSpan = UnderlineSpan()
        // UnderlineSpan for "Privacy Policy"
        val privacyPolicyUnderlineSpan = UnderlineSpan()
        // UnderlineSpan for "Details"
        val detailsUnderlineSpan = UnderlineSpan()
        // Set ClickableSpan and UnderlineSpan for "Terms"
        spannableString.setSpan(
            termsClickableSpan,
            fullText.indexOf(terms),
            fullText.indexOf(terms) + terms.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannableString.setSpan(
            termsUnderlineSpan,
            fullText.indexOf(terms),
            fullText.indexOf(terms) + terms.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        // Set ClickableSpan and UnderlineSpan for "Privacy Policy"
        spannableString.setSpan(
            privacyPolicyClickableSpan,
            fullText.indexOf(privacyPolicy),
            fullText.indexOf(privacyPolicy) + privacyPolicy.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannableString.setSpan(
            privacyPolicyUnderlineSpan,
            fullText.indexOf(privacyPolicy),
            fullText.indexOf(privacyPolicy) + privacyPolicy.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        // Set ClickableSpan and UnderlineSpan for "Details"
        spannableString.setSpan(
            detailsClickableSpan,
            fullText.indexOf(details),
            fullText.indexOf(details) + details.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannableString.setSpan(
            detailsUnderlineSpan,
            fullText.indexOf(details),
            fullText.indexOf(details) + details.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        this.text = spannableString
        this.movementMethod = LinkMovementMethod.getInstance()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.videoView.stopPlayback()


        isAppOpenAdShow(false)

        iapConnector?.destroy()
        if (networkReceiver != null) {
            unregisterReceiver(networkReceiver)
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()

        isAppOpenAdShow(false)

        binding.videoView.start()
    }

}