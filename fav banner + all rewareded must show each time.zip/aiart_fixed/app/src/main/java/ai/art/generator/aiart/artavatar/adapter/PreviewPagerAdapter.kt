package ai.art.generator.aiart.artavatar.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.PagerAdapter
import ai.art.generator.aiart.artavatar.databinding.PreviewItemBinding
import ai.art.generator.aiart.artavatar.databinding.PreviewPagerItemBinding
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.loadWithRetry


class PreviewPagerAdapter(private val context: Context, private val imageUrls: List<String>) :
    RecyclerView.Adapter<PreviewPagerAdapter.ViewHolder>() {

    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private var scaleFactor = 1.0f

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = PreviewPagerItemBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val imageUrl = imageUrls[position]

        holder.bind(imageUrl)
    }

    override fun getItemCount(): Int {
        return imageUrls.size
    }


    inner class ViewHolder(private val binding: PreviewPagerItemBinding) : RecyclerView.ViewHolder(binding.root) {

        init {
            scaleGestureDetector = ScaleGestureDetector(context, ScaleListener())

            // Attach the gesture detector to the ImageView
            binding.focusedImage.setOnTouchListener { _, event ->
                scaleGestureDetector.onTouchEvent(event)
                true
            }
        }
        fun bind(imageUrl: String) {
            Helper.loadWithRetry(context, binding.focusedImage, imageUrl, 450, 450, null, false)
        }

        private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleFactor *= detector.scaleFactor
                scaleFactor = Math.max(0.1f, Math.min(scaleFactor, 5.0f))

                // Apply the scale factor to the image
                binding.focusedImage.scaleX = scaleFactor
                binding.focusedImage.scaleY = scaleFactor

                return true
            }
        }
    }
}

