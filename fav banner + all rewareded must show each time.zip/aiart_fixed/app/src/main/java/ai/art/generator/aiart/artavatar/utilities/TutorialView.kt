package ai.art.generator.aiart.artavatar.utilities


import ai.art.generator.aiart.artavatar.R
import android.app.Activity
import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.constraintlayout.widget.ConstraintLayout

class TutorialView(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {

    fun inflateTutorials(targetView: View, tutorialLayout: Int = R.layout.prompt_tutorial_layout) {
        this.removeAllViews()
        val inflater = LayoutInflater.from(context)
        var mainView = inflater.inflate(tutorialLayout, this@TutorialView, true)

        val location = IntArray(2)
        targetView.getLocationOnScreen(location)

        if (tutorialLayout != R.layout.generate_tutorial_layout) {
            mainView?.findViewById<ConstraintLayout>(R.id.main_container)?.apply {
                y = location[1].toFloat() - getStatusBarHeight()
            }
        }
    }

    private fun getStatusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId)
        else Rect().apply { (context as Activity).window.decorView.getWindowVisibleDisplayFrame(this) }.top
    }

}

