package ai.art.generator.aiart.artavatar.viewmodel

import ai.art.generator.aiart.artavatar.apicalling.RequestBodyJson
import ai.art.generator.aiart.artavatar.apicalling.generateAiImage
import ai.art.generator.aiart.artavatar.database.DatabaseHelper
import ai.art.generator.aiart.artavatar.model.HistoryModel
import ai.art.generator.aiart.artavatar.model.RequestModel
import android.app.Application
import android.util.Base64
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _addSubItem = MutableLiveData<HistoryModel>()
    val addSubItem: LiveData<HistoryModel> = _addSubItem

    private val _deleteSubItem = MutableLiveData<HistoryModel>()
    val deleteSubItem: LiveData<HistoryModel> = _deleteSubItem

    private val _addToHistory = MutableLiveData<HistoryModel>()
    val addToHistory: LiveData<HistoryModel> = _addToHistory

    fun createRequestX(
        request: RequestModel,
        onSuccess: ((String) -> Unit)? = null,
        onFailed: ((String) -> Unit)? = null,
    ) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                generateAiImage(encryptRequest(request), onSuccess = {
                    onSuccess?.invoke(it)
                }, onFailed = {
                    onFailed?.invoke(it)
                })
            }
        }
    }


    private fun encryptRequest(request: RequestModel): RequestBodyJson {
        //Convert request object into json
        val json = Gson().toJson(request)
        Log.i("EncryptRequestInfo", "encryptRequest: $json")
        //Encrypt request
        val encryptReq = "bGCR5QK76sN2XRPmkwIkXq0ufv4tfQWW" + json.encrypt()
        Log.e("encryptReq", encryptReq)
        return RequestBodyJson(encryptReq)
    }

    private fun String.encrypt() =
        Base64.encodeToString(toByteArray(Charsets.UTF_8), Base64.DEFAULT)

    fun insertProduct(item: HistoryModel, databaseHelper: DatabaseHelper) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                databaseHelper.insertItem(item)
                _addToHistory.postValue(item)
            }
        }
    }

    fun updateHistory(item: HistoryModel) {
        _addToHistory.postValue(item)
    }

    fun addToFavourite(itemId: Int, databaseHelper: DatabaseHelper, item: HistoryModel) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                databaseHelper.updateFavouriteStatus(itemId, System.currentTimeMillis(), 1)
                _addSubItem.postValue(item)
            }
        }
    }

    fun removeFromFavourite(itemId: Int, databaseHelper: DatabaseHelper, item: HistoryModel) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                databaseHelper.updateFavouriteStatus(itemId, System.currentTimeMillis(), 0)
                _deleteSubItem.postValue(item)
            }
        }
    }

    fun getID(image: String, databaseHelper: DatabaseHelper): Int {
        return databaseHelper.getRecordIdByURL(image)
    }
}