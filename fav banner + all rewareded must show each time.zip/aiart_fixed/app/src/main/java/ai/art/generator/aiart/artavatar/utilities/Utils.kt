package ai.art.generator.aiart.artavatar.utilities

import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.model.SharedPreferenceHelper
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import android.animation.Animator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.util.AndroidRuntimeException
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.willy.ratingbar.ScaleRatingBar


fun Activity.exitDialog(onExitConfirmed: () -> Unit): BottomSheetDialog {
    val bottomSheet = BottomSheetDialog(this, R.style.SheetDialog)
    bottomSheet.apply {
        setContentView(R.layout.exit_lay)
        setCancelable(true)
        behavior.state = BottomSheetBehavior.STATE_EXPANDED

        val btnExit = findViewById<TextView>(R.id.tv_exit_confirm)
        val btnCancel = findViewById<TextView>(R.id.tv_cancel_exit)
        val adContainer = findViewById<FrameLayout>(R.id.native_ad_container_exit)

        // Load Native Ad logic
        if (adContainer != null) {
            /*    com.hm.admanagerx.AdsManagerX.loadNativeAd(
                    lifecycleOwner = this@exitDialog as androidx.lifecycle.LifecycleOwner,
                    adConfigManager = com.hm.admanagerx.AdConfigManager.NATIVE_AD_EXIT,
                    bannerAdContainer = adContainer,
                    onAdLoaded = {
                        adContainer.visibility = View.VISIBLE
                    },
                    onAdFailed = {
                        adContainer.visibility = View.GONE
                    }
                )*/
        }

        btnExit?.setOnClickListener {
            dismiss()
            onExitConfirmed()
        }

        btnCancel?.setOnClickListener {
            dismiss()
        }
    }
    return bottomSheet
}

//exit dialog ars

fun Activity.ratingDialog(onExitClick: (() -> Unit?)?, onRateClick: (() -> Unit)?): BottomSheetDialog {
    val bottomSheet = BottomSheetDialog(this, R.style.SheetDialog)
    bottomSheet.apply {
        behavior.apply {
            state = BottomSheetBehavior.STATE_EXPANDED
            isDraggable = false
        }
        setContentView(R.layout.rating_layout)
        setCancelable(true)
        window?.setGravity(Gravity.BOTTOM)

        val imgEmoji = this.findViewById<ImageView>(R.id.iv_emojis)
        val tvReaction = this.findViewById<TextView>(R.id.tv_react)
        val tvRateText = this.findViewById<TextView>(R.id.tv_ratetext)
        val ratingBar = this.findViewById<ScaleRatingBar>(R.id.srb_rating_bar)
        val lottieAnimationView = this.findViewById<LottieAnimationView>(R.id.lav_progress_bar)
        val btnRateFeed = this.findViewById<TextView>(R.id.tv_rateus)
        val btnCancel = this.findViewById<TextView>(R.id.tv_cancelBtn)


        btnRateFeed?.enableRateFeedButton(false)
        ratingBar?.setOnRatingChangeListener { _, rating, _ ->
            when {
                rating.toInt() == 0 -> {
                    imgEmoji?.setImageResource(R.drawable.zerostar)
                    tvReaction?.setText(R.string.rate_us)
                    tvRateText?.setText(R.string.we_d_love_to_hear_your_feedback)
                    btnRateFeed?.text = getString(R.string.feedback)
                    btnRateFeed?.enableRateFeedButton(false)
                }

                rating.toInt() == 1 -> {
                    imgEmoji?.setImageResource(R.drawable.onestar)
                    tvReaction?.setText(R.string.ohno)
                    tvRateText?.setText(R.string.we_d_love_to_hear_your_feedback)
                    btnRateFeed?.text = getString(R.string.feedback)
                    btnRateFeed?.background =
                        ContextCompat.getDrawable(this@ratingDialog, R.drawable.button_border)
                    btnRateFeed?.enableRateFeedButton(true)

                }

                rating.toInt() == 2 -> {
                    imgEmoji?.setImageResource(R.drawable.twostar)
                    tvReaction?.setText(R.string.ohno)
                    tvRateText?.setText(R.string.we_d_love_to_hear_your_feedback)
                    btnRateFeed?.text = getString(R.string.feedback)
                    btnRateFeed?.enableRateFeedButton(true)
                }

                rating.toInt() == 3 -> {
                    imgEmoji?.setImageResource(R.drawable.threestar)
                    tvReaction?.setText(R.string.ohwhatapit)
                    tvRateText?.setText(R.string.pleaseletusknow)
                    btnRateFeed?.text = getString(R.string.feedback)
                    btnRateFeed?.enableRateFeedButton(true)
                }

                rating <= 4 -> {
                    imgEmoji?.setImageResource(R.drawable.fourstar)
                    tvReaction?.setText(R.string.thankyou)
                    tvRateText?.setText(R.string.wewilldoourbest)
                    btnRateFeed?.text = getString(R.string.feedback)
                    btnRateFeed?.enableRateFeedButton(true)

                }

                rating.toInt() == 5 -> {
                    imgEmoji?.setImageResource(R.drawable.fivestar)
                    tvReaction?.setText(R.string.thankyou)
                    tvRateText?.setText(R.string.wereallyappricate)
                    btnRateFeed?.text = getString(R.string.rate_us)
                    btnRateFeed?.enableRateFeedButton(true)
                }

                else -> {
                    imgEmoji?.setImageResource(R.drawable.zerostar)
                    tvRateText?.setText(R.string.we_d_love_to_hear_your_feedback)
                    tvReaction?.setText(R.string.rate_us)
                    btnRateFeed?.text = getString(R.string.rate_us)
                    btnRateFeed?.enableRateFeedButton(true)
                }
            }
        }
        btnRateFeed?.setOnClickListener {
            when (btnRateFeed.text) {
                getString(R.string.feedback) -> {
                    SharedPreferenceHelper.setIsRatingDone(this.context, true)
                    onRateClick?.invoke()
                    sendEmailX(
                        Constants.FEEDBACK,
                        getString(R.string.feedback) + " " + resources.getString(R.string.app_name),
                        ""
                    )
                }

                getString(R.string.rate_us) -> {
                    sendFirebaseEvents("settings_rate_us_done")
                    SharedPreferenceHelper.setIsRatingDone(this.context, true)
                    onRateClick?.invoke()
                    rateUs(this@ratingDialog)
                }

                getString(R.string.exit) -> {
                    finish()
                }
            }
            dismiss()
        }
        btnCancel?.setOnClickListener {
            onExitClick?.invoke()
            dismiss()
        }

        val configuration = resources.configuration
        val isDarkTheme = configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        if (isDarkTheme) {
            // Perform actions for dark theme
            lottieAnimationView?.setAnimation(R.raw.ratingstar_dark)
        } else {
            // Perform actions for light theme
            lottieAnimationView?.setAnimation(R.raw.ratingstar_light)
        }
        lottieAnimationView?.addAnimatorListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(p0: Animator) {

            }

            override fun onAnimationEnd(p0: Animator) {
                lottieAnimationView.visibility = View.INVISIBLE
                ratingBar?.visibility = View.VISIBLE
            }

            override fun onAnimationCancel(p0: Animator) {

            }

            override fun onAnimationRepeat(p0: Animator) {

            }

        })
    }
    return bottomSheet
}

fun TextView.enableRateFeedButton(isEnabled: Boolean) {
    this.isEnabled = isEnabled
    if (isEnabled) {
        this.background = ContextCompat.getDrawable(this.context, R.drawable.ic_bg_rateus_x)
    } else {
        this.background = ContextCompat.getDrawable(this.context, R.drawable.ic_inactive_bgrateus_x)
    }
}

fun Context.sendEmailX(
    to: String?,
    subject: String?,
    body: String?,
) {
    val emails = arrayOf(to)
    val uri = Uri.parse(to)
        .buildUpon()
        .appendQueryParameter("subject", subject)
        .appendQueryParameter("body", body)
        .build()
    val emailIntent = Intent(Intent.ACTION_SENDTO, uri)
    emailIntent.data = Uri.parse("mailto:$to")

    emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
    emailIntent.putExtra(Intent.EXTRA_TEXT, body)
    emailIntent.putExtra(Intent.EXTRA_EMAIL, emails)
    val fIntent = Intent.createChooser(emailIntent, "Send mail...")
    if (fIntent != null) {
        try {
            ContextCompat.startActivity(this, fIntent, null)
        } catch (ignored: AndroidRuntimeException) {
            let {
                val builder =
                    AlertDialog.Builder(it)
                builder.setTitle(R.string.app_name)
                builder.setMessage("Sorry, the search encountered a problem.")
                builder.setPositiveButton("Ok", null)
                builder.show()
            }
        }
    }
}

private fun rateUs(context: Context) {
    try {
        val packageName = context.applicationContext.packageName
        val uri = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    } catch (e: Exception) {
    }
}

fun String.printIt(tag: String = "--->") = Log.e(tag, this)