package ai.art.generator.aiart.artavatar.views.dialoguefragments

import ai.art.generator.aiart.artavatar.utilities.AppX
import ai.art.generator.aiart.artavatar.R
import ai.art.generator.aiart.artavatar.databinding.FragmentEditPromptBottomSheetBinding
import ai.art.generator.aiart.artavatar.model.GenerateModel
import ai.art.generator.aiart.artavatar.storage.ImageCreditPreferences
import ai.art.generator.aiart.artavatar.utilities.Constants
import ai.art.generator.aiart.artavatar.utilities.Helper
import ai.art.generator.aiart.artavatar.utilities.Helper.loadStyleImage
import ai.art.generator.aiart.artavatar.utilities.Helper.sendFirebaseEvents
import ai.art.generator.aiart.artavatar.utilities.Helper.showSnackBar
import ai.art.generator.aiart.artavatar.utilities.RapidClicker
import ai.art.generator.aiart.artavatar.utilities.Singleton
import ai.art.generator.aiart.artavatar.utilities.convertCommaStringToList
import ai.art.generator.aiart.artavatar.utilities.editHistoryModel
import ai.art.generator.aiart.artavatar.utilities.printIt
import ai.art.generator.aiart.artavatar.viewmodel.BottomSheetVM
import ai.art.generator.aiart.artavatar.views.activity.MainActivity
import ai.art.generator.aiart.artavatar.views.activity.PremiumActivity
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.shape.CornerFamily
import com.google.android.material.shape.ShapeAppearanceModel
import com.hm.admanagerx.InterAdLoaderX
import com.hm.admanagerx.RewardedAdLoaderX
import com.hm.admanagerx.isPremium
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener
import java.util.Random

class EditPromptBottomSheet : BottomSheetDialogFragment(), View.OnClickListener {
    private lateinit var binding: FragmentEditPromptBottomSheetBinding
    private val viewModel: BottomSheetVM by activityViewModels()
    private var saveClickCounter = 0
    private var isTags: Boolean = false
    private var userDismissed: Boolean = true
    private var bottomSheetDialog: BottomSheetDialog? = null
    private var rewardedAd: RewardedAdLoaderX? = null
    private var interAd: InterAdLoaderX? = null
    var onEditGenerateClick: ((GenerateModel) -> Unit)? = null
    private var generateModel: GenerateModel = GenerateModel()
    var mContext: Context? = null
    private var mActivity: MainActivity? = null
    private var newModelPromptText: String = ""
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<FrameLayout>
    private lateinit var imageCreditPreferences: ImageCreditPreferences
    private val rapidClicker: RapidClicker = RapidClicker(1000)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetMainStyle)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
        mActivity = context as MainActivity
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val context =
            mContext ?: throw IllegalStateException("mContext is null, cannot create dialog")

        return BottomSheetDialog(context, theme).apply {
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.peekHeight = context.resources.displayMetrics.heightPixels
            bottomSheetBehavior = behavior
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View {
        binding = FragmentEditPromptBottomSheetBinding.inflate(inflater, container, false)
        setUI()
        observers()
        clickListeners()
        touchListener()

        if (mContext?.isPremium() == true) {
            hidePremiumUI()
        }
        imageCreditPreferences = ImageCreditPreferences(requireContext())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rewardedAd = (mActivity?.application as? AppX)?.rewardedAd
        interAd = (mActivity?.application as? AppX)?.interAdLoaderX

        if (viewModel.editTagsSelectionList.size > 0) {
            binding.tagCountTxt.text = viewModel.editTagsSelectionList.size.toString()
        }

        //for edittext scroll false sheet scroll behaviour
        if (binding.promptInput.isFocusable) {
            bottomSheetBehavior.isDraggable = false
        }

        binding.promptInput.clearFocus()
        binding.edittext.requestFocus()
    }


    private fun setUI() {
        Log.i("EditPromptInfo", "setUI: $editHistoryModel")
        editHistoryModel?.let {
            generateModel.style = it.style
            generateModel.model = it.model
            generateModel.modelName = it.modelName
            generateModel.hdQuality = it.highQuality
            generateModel.cfgScale = it.cfg.toInt()
            generateModel.deNoising = it.steps
            viewModel.editTagsSelectionList = convertCommaStringToList(it.tags)

            var nPrompt =
                it.negativePrompt.replace(getString(R.string.hardcoded_negative_prompt), "")
            val negativeArray = nPrompt.split(", ")
            var nTags = ""

            for (i in negativeArray) {
                if (Constants.NEGATIVE_TAGS.contains(i)) {
                    nTags = "$nTags,$i"
                    nPrompt = nPrompt.replace(
                        ", $i", ""
                    )
                }
            }

            generateModel.negative_prompt = nPrompt
            generateModel.negative_prompt_tags = nTags

            setUpStyle(it.style)
            binding.modelName.text =
                mContext?.let { it1 -> Helper.reformattedModelName(it1, it.modelName) }
        }

        /*val imageUrl = "https://ai.trustedtoolsutilities.com/ai_styles/enhance.webp"
        Glide.with(this).load(imageUrl).apply(RequestOptions.bitmapTransform(BlurTransformation(5, 1)))
            .placeholder(mContext?.let {
                AppCompatResources.getDrawable(
                    it, R.drawable.placeholder
                )
            }).into(binding.seeMoreImageView)

        binding.editColorSplash.startShimmer()
        binding.editNeonPunk.startShimmer()
        loadStyleImage(mContext, binding.colorSplashImageView, "color_splash", binding.editColorSplash)
        loadStyleImage(mContext, binding.neonPunkImageView, "neon-punk", binding.editNeonPunk)*/
        binding.promptInput.setText(Singleton.getPrompt())
        binding.cross.visibility = View.VISIBLE
        binding.wordCount.text = getString(R.string.word_count, Singleton.getPrompt().length)

        binding.digitalArtShimmer.startShimmer()
        binding.neonPunkShimmer.startShimmer()
        binding.colorSplashShimmer.startShimmer()
        binding.cosmosShimmer.startShimmer()
        binding.bizarreShimmer.startShimmer()
        if (editHistoryModel?.style.isNullOrEmpty() || editHistoryModel?.style.orEmpty()
                .contains("No style") || editHistoryModel?.style == "Color Splash" || editHistoryModel?.style == "Cosmos" || editHistoryModel?.style == "Neon Punk" || editHistoryModel?.style == "Bizarre"
        ) {
            loadStyleImage(
                mContext,
                binding.digitalArtImageview,
                "digital-art",
                binding.digitalArtShimmer
            )
        }
        loadStyleImage(
            mContext,
            binding.colorSplashImageView,
            "color_splash",
            binding.colorSplashShimmer
        )
        loadStyleImage(mContext, binding.neonPunkImageView, "neon-punk", binding.neonPunkShimmer)
        loadStyleImage(mContext, binding.cosmosImageview, "cosmic", binding.cosmosShimmer)
        loadStyleImage(mContext, binding.bizarreImageview, "bizarre", binding.bizarreShimmer)
        //setUpStyle(getString(R.string.digitalArt))
        loadStyleImage(
            requireActivity().applicationContext,
            binding.modelImageview,
            Helper.styleImagesX(generateModel.modelName),
            binding.bizarreShimmer
        )
    }

    private fun observers() {

        viewModel.isPremium.observe(this) {
            hidePremiumUI()
        }

        mActivity?.let {
            KeyboardVisibilityEvent.setEventListener(
                it
            ) { isOpen ->
                if (!isOpen) binding.promptInput.clearFocus()
            }
        }

        binding.promptInput.imeOptions = EditorInfo.IME_ACTION_DONE
        binding.promptInput.setRawInputType(
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        )

        binding.promptInput.setSelection(binding.promptInput.text.length)

    }

    private fun hidePremiumUI() {
        binding.btnAdText.visibility = View.GONE
        binding.removeAddsBtn.visibility = View.GONE
    }

    private fun showHintButton() {
        if (mContext == null) return
        isTags = false
        binding.promptTag.visibility = View.GONE
        binding.promptHint.visibility = View.VISIBLE
        binding.tagCountTxt.isVisible = false
    }

    private fun showTagButton() {
        if (mContext == null) return
        isTags = true
        binding.tagCountTxt.isVisible = true
        binding.promptTag.visibility = View.VISIBLE
        binding.promptHint.visibility = View.GONE
        val text = binding.promptInput.text.toString()
        if (text.isEmpty() || text == "") {
            binding.cross.visibility = View.GONE
        }
    }

    private fun clickListeners() {
        // remove promptInput focus when keyboard close
        if (mContext == null || mActivity == null) return
        KeyboardVisibilityEvent.setEventListener(
            mActivity!!,
            KeyboardVisibilityEventListener { isOpen ->

                if (!isOpen) {
                    if (viewModel.editTagsSelectionList.size > 0) return@KeyboardVisibilityEventListener
                    binding.promptInput.clearFocus()
                    showHintButton()
                } else {
                    "doAfterTextChanged".printIt()
                    isTags = true
                    binding.tagCountTxt.isVisible = true
                    binding.promptTag.visibility = View.VISIBLE
                    binding.promptHint.visibility = View.GONE
                }
            })

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.cross.visibility = View.VISIBLE
                if (s != null) {
                    if (s.isEmpty() || s == "") {
                        binding.cross.visibility = View.GONE
                    }
                    if (s.length <= 500) {
                        binding.wordCount.text = getString(R.string.word_count, s.length)
                    }
                } else {
                    binding.tagCountTxt.isVisible = false
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        }

        binding.promptInput.doAfterTextChanged {
            val isValueChangedByUser = binding.promptInput.hasFocus()
            if (isValueChangedByUser) {
                showTagButton()
            }
        }
        binding.promptInput.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                mContext?.sendFirebaseEvents("edit_prompt_changed")
            }
        }

        binding.promptInput.addTextChangedListener(textWatcher)

        binding.advanceSettingsDropdown.setOnClickListener(this)
        binding.model.setOnClickListener(this)
        binding.seeAllLayout.setOnClickListener(this)
        binding.promptHint.setOnClickListener(this)
        binding.generateButton.setOnClickListener(this)
        binding.promptInput.setOnClickListener(this)
        binding.cross.setOnClickListener(this)

        binding.audio.setOnClickListener(this)
        binding.digitalArtLayout.setOnClickListener(this)
        binding.neonPunkLayout.setOnClickListener(this)
        binding.colorSplashLayout.setOnClickListener(this)
        binding.cosmosLayout.setOnClickListener(this)
        binding.bizarreLayout.setOnClickListener(this)
        binding.removeAddsBtn.setOnClickListener(this)
        binding.promptTag.setOnClickListener(this)

    }

    @SuppressLint("ClickableViewAccessibility")
    private fun touchListener() {
        binding.tagScrollLayout.setOnTouchListener { v, event ->

            when (event.action) {
                MotionEvent.ACTION_MOVE -> {
                    Log.e("touch listener", "touchListener: move")
                    bottomSheetDialog?.let {
                        if (it.behavior.isDraggable) {
                            it.behavior.isDraggable = false
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    Log.e("touch listener", "touchListener: up")
                    bottomSheetDialog?.let {
                        it.behavior.isDraggable = true
                    }
                }
            }
            false
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            binding.digitalArtLayout -> {
                /*generateModel.style = getString(R.string.digitalArt)
                setUpStyle(generateModel.style)*/
                mContext?.sendFirebaseEvents("edit_prompt_style_selected_digital_art")
                when (binding.digitalArtTextview.text) {
                    getString(R.string.digitalArt) -> generateModel.style =
                        getString(R.string.digitalArt)

                    generateModel.style -> generateModel.style = "No style"
                    else -> generateModel.style =
                        Helper.styleImagesX(binding.digitalArtTextview.text.toString())
                }
                setUpStyle(generateModel.style)
            }

            binding.cosmosLayout -> {
                mContext?.sendFirebaseEvents("edit_prompt_style_selected_cosmos")
                if (generateModel.style == getString(R.string.cosmosText)) {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = getString(R.string.cosmosText)
                }
                setUpStyle(generateModel.style)
            }

            binding.neonPunkLayout -> {
                mContext?.sendFirebaseEvents("edit_prompt_style_selected_neon_punk")
                if (generateModel.style == "Neon Punk") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Neon Punk"
                }
                setUpStyle(generateModel.style)
            }

            binding.colorSplashLayout -> {
                mContext?.sendFirebaseEvents("edit_prompt_style_selected_color_splash")
                if (generateModel.style == "Color Splash") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Color Splash"
                }
                setUpStyle(generateModel.style)
            }

            binding.bizarreLayout -> {
                mContext?.sendFirebaseEvents("edit_prompt_style_selected_bizarre")
                if (generateModel.style == "Bizarre") {
                    generateModel.style = "No style"
                } else {
                    generateModel.style = "Bizarre"
                }
                setUpStyle(generateModel.style)
            }


            binding.audio -> {
                openVoiceToText()
            }

            binding.cross -> {
                binding.promptInput.setText("")
            }

            binding.advanceSettingsDropdown -> {
                userDismissed = false
                mContext?.sendFirebaseEvents("edit_prompt_advance_settings_clicked")
                if (saveClickCounter++ == 0) {

                    val bottomSheet = BottomSheetFragment.newInstance(
                        true,
                        generateModel.negative_prompt,
                        generateModel.negative_prompt_tags,
                        generateModel.cfgScale.toString(),
                        generateModel.deNoising,
                        generateModel.hdQuality
                    )
                    mActivity?.let { bottomSheet.show(it.supportFragmentManager, bottomSheet.tag) }

                    onAdvanceDismissListener =
                        { fromEdit: Boolean, negPrompt: String, negTags: String, cfg: Int, de_noising: String, hd: String ->
                            if (fromEdit) {
                                generateModel.negative_prompt = negPrompt
                                generateModel.negative_prompt_tags = negTags
                                generateModel.cfgScale = cfg
                                generateModel.deNoising = de_noising
                                generateModel.hdQuality = hd
                            }
                        }

                    Handler(Looper.getMainLooper()).postDelayed({
                        saveClickCounter = 0
                    }, 1000)
                }
            }

            binding.model -> {
                userDismissed = false
                if (saveClickCounter++ == 0) {
                    Log.i("EditPromptInfo", "onClick: Model: ${generateModel.modelName}")
                    val bottomSheet = StyleBottomFragment.newInstance(
                        true, "model", generateModel.model, generateModel.modelName
                    )
                    mActivity?.let { bottomSheet.show(it.supportFragmentManager, bottomSheet.tag) }

                    onUpdateModel = { fromEdit: Boolean, model: String ->
                        Log.i("EditPromptInfo", "onClick: onUpdateModel: $model")
                        loadStyleImage(
                            requireActivity().applicationContext,
                            binding.modelImageview,
                            Helper.styleImagesX(model),
                            null
                        )
                        if (fromEdit) {
                            val reformatNameToModelId = when (model) {
                                Constants.allModelNameList[3] -> {
                                    newModelPromptText = "generate a Cartoon image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[4] -> {
                                    newModelPromptText =
                                        "imagine Goku in a drip outfit. Epic background. Tatsuya Nagamine art-style,"
                                    Constants.MODEL_IDS[1]
                                }

                                Constants.allModelNameList[5] -> {
                                    newModelPromptText = "VIRTUAL REALITY DESIGN,"
                                    Constants.MODEL_IDS[1]
                                }

                                Constants.allModelNameList[6] -> {
                                    newModelPromptText = "generate a Real image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[7] -> {
                                    newModelPromptText =
                                        "extremely detailed illustration in anime style, cartoon, best resolution, best quality,"
                                    Constants.MODEL_IDS[2]
                                }

                                Constants.allModelNameList[8] -> {
                                    newModelPromptText = "An awe-inspiring alien cyborg image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[9] -> {
                                    newModelPromptText = "high quality, Generate real image,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[10] -> {
                                    newModelPromptText = "a portrait image with solid background,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[11] -> {
                                    newModelPromptText = "modern disney diffusion,"
                                    Constants.MODEL_IDS[0]
                                }

                                Constants.allModelNameList[12] -> {
                                    newModelPromptText =
                                        "A dreamlike world where a super cute cartoon Goku baby roams,"
                                    Constants.MODEL_IDS[0]
                                }

                                else -> model
                            }
                            generateModel.model = reformatNameToModelId
                            generateModel.modelName = model
                            binding.modelName.text =
                                mContext?.let { Helper.reformattedModelName(it, model) }
                        }
                    }

                    Handler(Looper.getMainLooper()).postDelayed({
                        saveClickCounter = 0
                    }, 1000)
                }

            }

            binding.seeAllLayout -> {

                if (saveClickCounter++ == 0) {
                    userDismissed = false
                    val bottomSheet = StyleBottomFragment.newInstance(
                        true,
                        "style",
                        generateModel.style,
                        generateModel.style
                    )
                    mActivity?.let { bottomSheet.show(it.supportFragmentManager, bottomSheet.tag) }
                    onUpdateStyle = { fromEdit, style ->
                        if (fromEdit) {
                            generateModel.style = style
                            if (activity != null) {
                                setUpStyle(style)
                            }
                        }
                    }

                    Handler(Looper.getMainLooper()).postDelayed({
                        saveClickCounter = 0
                    }, 1000)
                }
            }

            binding.promptHint -> {
                mContext?.sendFirebaseEvents("edit_prompt_idea_clicked")
                if (isTags) {

                    if (saveClickCounter++ == 0) {
                        userDismissed = false
                        val bottomSheet = TagsFragment.newInstance(true, "")
                        mActivity?.let {
                            bottomSheet.show(it.supportFragmentManager, bottomSheet.tag)
                            bottomSheet.onTagAdded = {
                                if (viewModel.editTagsSelectionList.size > 0) showTagButton() else showHintButton()
                                binding.tagCountTxt.text = it
                            }
                        }

                        Handler(Looper.getMainLooper()).postDelayed({
                            saveClickCounter = 0
                        }, 1000)
                    }

                } else {
                    //add dummy prompts to input field
                    val random = Random()
                    val hintsList = Helper.promptHints()
                    val randomIndex = random.nextInt(hintsList.size)
                    binding.promptInput.setText(hintsList[randomIndex])
                }
            }

            binding.promptTag -> {
                mContext?.sendFirebaseEvents("edit_prompt_tag_clicked")
                rapidClicker.publish {
                    userDismissed = false
                    val bottomSheet = TagsFragment.newInstance(false, "editPrompt")
                    mActivity?.let {
                        bottomSheet.show(it.supportFragmentManager, bottomSheet.tag)
                        bottomSheet.onTagAdded = { text ->
                            if (text.isEmpty()) {
                                showHintButton()
                            } else {
                                showTagButton()
                                //if (text.toInt() > 0) showTagButton() else showHintButton()
                            }
                            binding.tagCountTxt.text = text
                        }
                    }
                }
            }

            binding.generateButton -> {
                if (binding.promptInput.text.trim().isNotEmpty()) {
                    mContext?.sendFirebaseEvents("edit_prompt_generate_clicked")
//                    mContext?.sendFirebaseEvents("edit_prompt_generate", Bundle().apply {
//                        putString("edit_prompt", binding.promptInput.text.trim().toString())
//                    })
                    if (requireActivity().isPremium()) {
                        Singleton.setPrompt(binding.promptInput.text.toString())
                        userDismissed = true
                        generateModel.prompt =
                            newModelPromptText + binding.promptInput.text.toString()
                        Log.i("EditPromptInfo", "onClick: premium User Model:$generateModel")
                        onEditGenerateClick?.invoke(generateModel)
                        this.dismiss()
                    } else {
                        //below logic for image counter which get from remote config
                        if (imageCreditPreferences.getImageCreditPreferences() < Constants.IMAGE_CREDIT_LIMIT) {
                            imageCreditPreferences.saveImageCreditPreferences(imageCreditPreferences.getImageCreditPreferences() + 1)
                            handleGenerateMore()
                        } else {
                            when (Constants.GENERATE_IMAGE_STATE) {
                                0 -> handleGenerateMore()
                                1 -> {
                                    val watchAdDialog = WatchAdDialog({
                                        when (it) {
                                            getString(R.string.watchAd) -> handleGenerateMore()
                                        }
                                    }, "EditPrompt")
                                    watchAdDialog.show(childFragmentManager, watchAdDialog.tag)
                                }

                                2 -> mActivity?.premiumLauncher?.launch(
                                    Intent(
                                        mActivity,
                                        PremiumActivity::class.java
                                    )
                                )

                                else -> handleGenerateMore()
                            }
                        }
                    }
                } else {
                    requireActivity().showSnackBar(
                        resources.getString(R.string.promptCannotBeEmpty),
                        binding.editCoordinatorLayout
                    )
                }
            }

            binding.removeAddsBtn -> {
                mContext?.sendFirebaseEvents("edit_prompt_scr_remove_ad_btn_clicked")
                mActivity?.premiumLauncher?.launch(Intent(context, PremiumActivity::class.java))
            }

        }
    }

    private fun handleGenerateMore() {
       /* mContext?.let {
            rewardedAd?.showAd(it) {
                interAd?.showAd(it)
                rewardedAd?.reloadAd()
            }
        }*/
        Singleton.setPrompt(binding.promptInput.text.toString())
        userDismissed = true
        generateModel.prompt = newModelPromptText + binding.promptInput.text.toString()
        Log.i("EditPromptInfo", "onClick: $generateModel")
        onEditGenerateClick?.invoke(generateModel)
        this.dismiss()
    }

    private fun setUpStyle(style: String) {
        Log.i("EditBottomFragInfo", "setUpStyle: $style")
        when (style) {
            "Digital Art" -> {
                binding.digitalArtTextview.text = getString(R.string.digitalArt)
                digitalArtLayout(true, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Neon Punk" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(true)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Color Splash" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(true)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "Cosmos" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(true)
                bizarreLayout(false)
            }

            "Bizarre" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(true)
            }

            "No style" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            "" -> {
                digitalArtLayout(false, style)
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }

            else -> {
                binding.digitalArtTextview.text = style
                if (style.contains("No style")) {
                    binding.digitalArtShimmer.stopShimmer()
                    binding.digitalArtShimmer.hideShimmer()
                    binding.digitalArtImageview.setImageDrawable(
                        ContextCompat.getDrawable(
                            mContext!!,
                            R.drawable.forbidden
                        )
                    )
                } else {
                    digitalArtLayout(true, style)
                    loadStyleImage(
                        mContext,
                        binding.digitalArtImageview,
                        Helper.styleImagesX(style),
                        binding.digitalArtShimmer
                    )
                }
                neonPunkLayout(false)
                colorSplashLayout(false)
                cosmosLayout(false)
                bizarreLayout(false)
            }
        }
    }

    private fun digitalArtLayout(value: Boolean, style: String) {
        if (value) {
            loadStyleImage(
                mContext,
                binding.digitalArtImageview,
                Helper.styleImagesX(style),
                binding.digitalArtShimmer
            )
            binding.digitalArtOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.digitalArtImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.digitalArtImageview.setBackgroundColor(Color.TRANSPARENT)
            binding.digitalArtLayout.background = AppCompatResources.getDrawable(
                requireContext(), R.drawable.ic_style_select_gradient_box
            )
            binding.digitalArtLayout.setPadding(Helper.spToPx(requireContext(), 5F))
        } else {
            binding.digitalArtOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.digitalArtImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.digitalArtLayout.background = null
            binding.digitalArtLayout.setPadding(0)
            //loadStyleImage(mContext, binding.digitalArtImageview, "digital-art", binding.digitalArtShimmer)
        }
    }

    private fun neonPunkLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.neonPunkOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.neonPunkImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.neonPunkLayout.background = AppCompatResources.getDrawable(
                requireContext(), R.drawable.white_bg_multi_border
            )
            binding.neonPunkLayout.setPadding(Helper.spToPx(requireContext(), 5F))
        } else {
            binding.neonPunkOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.neonPunkImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.neonPunkLayout.background = null
            binding.neonPunkLayout.setPadding(0)
        }
    }

    private fun colorSplashLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.colorSplashOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.colorSplashImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.colorSplashLayout.background = AppCompatResources.getDrawable(
                requireContext(), R.drawable.white_bg_multi_border
            )
            binding.colorSplashLayout.setPadding(Helper.spToPx(requireContext(), 5F))
        } else {
            binding.colorSplashOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.colorSplashImageView.shapeAppearanceModel = shapeAppearanceModel
            binding.colorSplashLayout.background = null
            binding.colorSplashLayout.setPadding(0)
        }
    }

    private fun cosmosLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.cosmosOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.cosmosImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.cosmosLayout.background = AppCompatResources.getDrawable(
                requireContext(), R.drawable.white_bg_multi_border
            )
            binding.cosmosLayout.setPadding(Helper.spToPx(requireContext(), 5F))
        } else {
            binding.cosmosOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.cosmosImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.cosmosLayout.background = null
            binding.cosmosLayout.setPadding(0)
        }
    }

    private fun bizarreLayout(value: Boolean) {
        if (value) {
            //binding.digitalArtTextview.text = getString(R.string.digitalArt)
            binding.bizarreOverlay.visibility = View.VISIBLE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 12f)
                .build()
            //binding.bizarreImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.bizarreLayout.background = AppCompatResources.getDrawable(
                requireContext(), R.drawable.white_bg_multi_border
            )
            binding.bizarreLayout.setPadding(Helper.spToPx(requireContext(), 5F))
        } else {
            binding.bizarreOverlay.visibility = View.GONE
            val shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 24f)
                .build()
            binding.bizarreImageview.shapeAppearanceModel = shapeAppearanceModel
            binding.bizarreLayout.background = null
            binding.bizarreLayout.setPadding(0)
        }
    }

    private fun openVoiceToText() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak something")


        try {
            speechRecognitionLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            requireActivity().showSnackBar(
                resources.getString(R.string.voiceRecognitionIsNotAvilable),
                binding.editCoordinatorLayout
            )
        }
    }

    private var speechRecognitionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == AppCompatActivity.RESULT_OK) {
                val data: Intent? = result.data
                val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                if (!results.isNullOrEmpty()) {
                    val spokenText = results[0]
                    mContext?.sendFirebaseEvents("edit_prompt_speech_to_text")
                    binding.promptInput.setText(spokenText)
                }
            }
        }

    companion object {
        fun newInstance(): EditPromptBottomSheet {
            return EditPromptBottomSheet()
        }
    }
}
