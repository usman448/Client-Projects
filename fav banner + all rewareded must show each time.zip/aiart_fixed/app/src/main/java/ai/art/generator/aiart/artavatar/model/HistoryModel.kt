package ai.art.generator.aiart.artavatar.model

import androidx.annotation.Keep

@Keep
data class HistoryModel(
    val id: Int,
    val sessionId: Int,
    var prompt: String,
    val imageUrl: String,
    val tags: String,
    var style: String,
    var model: String,
    var modelName: String,
    val height: String,
    val width: String,
    var negativePrompt: String,
    var cfg: String,
    var steps: String,
    var highQuality: String,
    var favourite: Int,
    var time: Long,
    var count: Int = -1

)


