plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.hm.admanagerx"
    compileSdk = 35

    defaultConfig {
        minSdk = 21
        targetSdk = 35

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"
            )

            resValue("string", "ad_app_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "inter_am", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "native_am", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "banner_am", "ca-app-pub-3940256099942544/6300978111")
            resValue("string", "rewarded_ad_am", "ca-app-pub-3940256099942544/5224354917")
            resValue("string", "app_open_ad", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "banner_am_collapse", "ca-app-pub-3940256099942544/2014213617")
            resValue("string", "banner_result", "ca-app-pub-3940256099942544/9214589741")

            resValue("string", "rewarded_Interstial_ad", "ca-app-pub-3940256099942544/5354046379")

            resValue("string", "in_app_key", "lifetime")
        }
        debug {

            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"
            )

            resValue("string", "ad_app_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "inter_am", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "native_am", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "banner_am", "ca-app-pub-3940256099942544/6300978111")
            resValue("string", "banner_am_collapse", "ca-app-pub-3940256099942544/2014213617")
            resValue("string", "rewarded_ad_am", "ca-app-pub-3940256099942544/5224354917")
            resValue("string", "app_open_ad", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "rewarded_Interstial_ad", "ca-app-pub-3940256099942544/5354046379")
            resValue("string", "banner_result", "ca-app-pub-3940256099942544/9214589741")


            resValue("string", "in_app_key", "android.test.purchased")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
//    api("com.google.android.gms:play-services-ads-lite:23.2.0")
    api("com.google.android.gms:play-services-ads:23.2.0")

    api(platform("com.google.firebase:firebase-bom:33.1.2"))
    api("com.google.firebase:firebase-config")
    api("com.google.firebase:firebase-analytics")

    implementation("androidx.activity:activity-ktx:1.9.1")

    implementation("com.google.code.gson:gson:2.10.1")

    api("com.facebook.shimmer:shimmer:0.5.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    implementation ("com.google.android.ump:user-messaging-platform:3.0.0")

    api("androidx.lifecycle:lifecycle-process:2.8.5")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("com.intuit.sdp:sdp-android:1.1.0")
    implementation("com.intuit.ssp:ssp-android:1.0.6")

    implementation("com.applovin:applovin-sdk:13.0.1")


}