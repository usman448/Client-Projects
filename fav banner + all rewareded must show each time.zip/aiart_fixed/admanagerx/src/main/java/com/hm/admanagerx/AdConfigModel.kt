package com.hm.admanagerx

import android.util.Log
import androidx.annotation.Keep
import com.google.android.gms.ads.AdSize
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.gson.Gson

const val BANNER_AD = "banner"
const val COLLAPSIBLE_BANNER_AD = "collapsible_banner"
const val NATIVE_AD = "native"
const val INTER_AD = "inter"
const val REWARDED_AD = "rewarded"
const val REWARDED_INTERSTITIAL_AD = "rewarded_interstitial"
const val APP_OPEN_AD = "app_open"

/**
 * Collapsible banner position enum
 */
enum class CollapsiblePosition(val position: String) {
    TOP("top"),
    BOTTOM("bottom"),
    NONE("none")
}

/** Firebase remote config json template */
/*
{
  "adType": "native",
  "adId": "ca-app-pub-3940256099942544/2247696110",
  "isAdShow": true,
  "isShowLoadingBeforeAd": true,
  "beforeAdLoadingTimeInMs": 1500,
  "isAdLoadAgain": false,
  "fullScreenAdCount": 0,
  "fullScreenAdLoadOnCount": 0
  "fullScreenAdSessionCount": 0
}
*/

/**
 * remote (json) ad configuration data class
 */
@Keep
data class RemoteAdConfig(
    var isAdShow: Boolean? = null,// show or hide ad
    var adId: String? = null, // ad id : Any - Int (ad id from local string ref) String (ad id from remote config )
    var adType: String? = null, // change ad type remotely, banner , collapsible_banner, native , inter , rewarded ,  app_open
    var isShowLoadingBeforeAd: Boolean? = null,// show loading view before showing ad
    var beforeAdLoadingTimeInMs: Long? = null, // before ad loading time
    var isAdLoadAgain: Boolean? = null, // if true,send new ad request again after show
    var fullScreenAdCount: Long? = null,// Remote config count for ad control , for inter ad / rewarded ad only , 0 = no limit
    var fullScreenAdLoadOnCount: Long? = null,// LoadAd load on specific count to improve show rate, 0 = no effect , -1 = second last count load ad position  , other value = specific load position
    var fullScreenAdSessionCount: Long? = null,// Total ads show in per session , 0 = no limit
    var nativeAdLayout: Int? = null,
    var adPosition: Int? = null,// 0 means bottom , 1 means top, controls ad position in the UI
    var adDesign: Int? = null,// 0 means old design , 1 means new design, controls different native ad designs
)

/**
 * local ad configuration class
 */
@Keep
data class AdConfig(
    var isAdShow: Boolean = true, // show or hide ad
    var adId: Any = "", // ad id : Any - Int (ad id from local string ref) String (ad id from remote config )
    var adType: String = "",// change ad type remotely, banner ,  native , inter , rewarded ,  app_open
    var isShowLoadingBeforeAd: Boolean = false,// show loading view before showing ad
    var beforeAdLoadingTimeInMs: Long = 1500, // before ad loading time
    var isAdLoadAgain: Boolean = false, // if true,send new ad request again after show
    var fullScreenAdCount: Long = 0,// Remote config count for ad control , for inter ad / rewarded ad only , 0 = no limit
    var fullScreenAdLoadOnCount: Long = 0,// LoadAd load on specific count to improve show rate, 0 = no effect , -1 = second last count load ad position  , other value = specific load position
    var fullScreenAdSessionCount: Long = 0,// Total ads show in per session , 0 = no limit
    var adDesign: Int = 0,// 0 means old design , 1 means new design
    var adPosition: Int = 0,//  0 means bottom , 1 means top, controls ad position in the UI

    //offline
    var fullScreenAdLoadingLayout: Int = R.layout.ad_loading_view,// Full screen AD loading Layout
    var nativeAdLayout: Int = R.layout.native_add_banner_view, // native ad layout , only for native Ad
    var bannerAdSize: AdSize? = null, // default value is null means its auto get adaptive AdSize
    var bannerAdLoadingLayout: Int = R.layout.banner_ad_loading_view, // before loading layout of banner ad
    var isAppOpenAdAppLevel: Boolean = false,
    var collapsiblePosition: CollapsiblePosition? = null, // Collapsible banner position (TOP, BOTTOM, or NONE)
) {

    fun fetchAdConfigFromRemote(remoteConfigKey: String): AdConfig {
        val configJson = FirebaseRemoteConfig.getInstance().getString(remoteConfigKey)

        Log.d(
            "fdskjfksf9s8fshfks",
            "here is josn from remote config ${configJson.toString()} ->${remoteConfigKey}"
        )
        try {
            Gson().fromJson(configJson, RemoteAdConfig::class.java).let {
                adId = it.adId ?: adId
                isAdShow = it.isAdShow ?: isAdShow
                adType = it.adType ?: adType
                isShowLoadingBeforeAd = it.isShowLoadingBeforeAd ?: isShowLoadingBeforeAd
                beforeAdLoadingTimeInMs = it.beforeAdLoadingTimeInMs ?: beforeAdLoadingTimeInMs
                isAdLoadAgain = it.isAdLoadAgain ?: isAdLoadAgain
                fullScreenAdCount = it.fullScreenAdCount ?: fullScreenAdCount
                fullScreenAdLoadOnCount = updateFullscreenAdLoadOnCount(it.fullScreenAdLoadOnCount)
                fullScreenAdSessionCount = it.fullScreenAdSessionCount ?: fullScreenAdSessionCount
                adPosition = it.adPosition ?: adPosition
//                nativeAdLayout = it.nativeAdLayout ?: nativeAdLayout
                adDesign = it.adDesign ?: adDesign
            }
        } catch (e: Exception) {
            e.message?.printIt()
//          if configJson is empty or invalid json , update fullScreenAdLoadOnCount base on default values
            fullScreenAdLoadOnCount = updateFullscreenAdLoadOnCount(null)
        }
        return this
    }


    private fun updateFullscreenAdLoadOnCount(remoteFullScreenAdLoadOnCount: Long?): Long {
        var loadOnCount = remoteFullScreenAdLoadOnCount ?: fullScreenAdLoadOnCount
        Log.d(
            "fdskjfksf9s8fshfks",
            "here is josn before  evaluation  ${loadOnCount} -> ${loadOnCount >= fullScreenAdCount}  -> ${fullScreenAdCount}"
        )


        if (fullScreenAdCount != 0L && loadOnCount < 0L) {
            if ((kotlin.math.abs(loadOnCount) == fullScreenAdCount)) {
                loadOnCount = 1
            } else {
                loadOnCount = (fullScreenAdCount + loadOnCount) + 1
            }
        }


        /* if (loadOnCount == -1L || loadOnCount >= fullScreenAdCount) loadOnCount =
             fullScreenAdCount - 1*/

        Log.d("fdskjfksf9s8fshfks", "here is after evaluation  ${loadOnCount} ")

        return loadOnCount
    }

}
