package com.hm.admanagerx.experiments

import android.os.CountDownTimer
import android.util.Log
import android.widget.FrameLayout
import androidx.lifecycle.LifecycleOwner
import com.hm.admanagerx.AdConfig
import com.hm.admanagerx.AdConfigManager
import com.hm.admanagerx.AdsManagerX
import com.hm.admanagerx.BANNER_AD
import com.hm.admanagerx.NATIVE_AD
import com.hm.admanagerx.hide
import com.hm.admanagerx.printIt
import com.hm.admanagerx.show

object NativeBannerFullExp {

    /********************************* NATIVE VS BANNER/BANNER VS NATIVE EXP ****************************************/
    private var expCountDownTimer: CountDownTimer? = null
    private var onNativeAdFailedToLoad: (() -> Unit)? = null
    private var onBannerAdFailedToLoad: (() -> Unit)? = null
    private var loadRefreshNativeAd: (() -> Unit)? = null

    private var onAdLoadedExternal: (() -> Unit)? = null
    private var onAdFailedExternal: (() -> Unit)? = null
    private var onAdRequestDeniedExternal: (() -> Unit)? = null

    private lateinit var config: ExperimentManager
    private var isBothAdsFailed = false
    private val TAG = "AdLogsExp"

    fun initializeAds(
        experimentManager: ExperimentManager,
        lifecycleOwner: LifecycleOwner,
        adContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null
    ) {
        Log.i(TAG, "initializeAds: ")
        config = experimentManager
        this.onAdLoadedExternal = onAdLoaded
        this.onAdFailedExternal = onAdFailed
        this.onAdRequestDeniedExternal = onAdRequestDenied

        // Always update callbacks with the latest lifecycleOwner and adContainer
        val adConfigExperiment = getFreshExpConfig()
        isBothAdsFailed = false
        updateCallbacks(adConfigExperiment, lifecycleOwner, adContainer)
        if (adConfigExperiment.isAdShow) {
            loadExistingAds(adContainer) ?: loadNewAds(
                adConfigExperiment = adConfigExperiment,
                adContainer = adContainer,
                lifecycleOwner = lifecycleOwner
            )
        } else Log.i(TAG, "initializeAds: Ad is off from RC")
    }

    private fun getFreshExpConfig() =
        config.expHandler.adConfig.fetchAdConfigFromRemote(config.expHandler.name)
            ?: config.expHandler.adConfig

    private fun loadExistingAds(
        adContainer: FrameLayout?
    ): Boolean? {
        return when {
            AdsManagerX.isBannerAdLoaded(config.bannerRefreshAd) -> {
                showBannerAd(config.bannerRefreshAd, adContainer)
                onAdLoadedExternal?.invoke()
                true
            }

            AdsManagerX.isBannerAdLoaded(config.bannerNoRefreshAd) -> {
                showBannerAd(config.bannerNoRefreshAd, adContainer)
                onAdLoadedExternal?.invoke()
                true
            }

            AdsManagerX.isNativeAdLoaded(config.nativeRefreshAd) -> {
                showNativeAd(config.nativeRefreshAd, adContainer)
                onAdLoadedExternal?.invoke()
                true
            }

            AdsManagerX.isNativeAdLoaded(config.nativeNoRefreshAd) -> {
                showNativeAd(config.nativeNoRefreshAd, adContainer)
                onAdLoadedExternal?.invoke()
                true
            }

            else -> null
        }
    }

    private fun loadNewAds(
        adConfigExperiment: AdConfig,
        adContainer: FrameLayout?,
        lifecycleOwner: LifecycleOwner
    ) {
        val adConfigNative = if (adConfigExperiment.isAdLoadAgain) {
            config.nativeRefreshAd
        } else {
            config.nativeNoRefreshAd
        }

        val adConfigBanner = if (adConfigExperiment.isAdLoadAgain) {
            config.bannerRefreshAd
        } else {
            config.bannerNoRefreshAd
        }

        when (adConfigExperiment.adType) {
            BANNER_AD -> loadBannerFirst(
                adConfigBanner = adConfigBanner,
                adConfigNative = adConfigNative,
                adContainer = adContainer,
                lifecycleOwner = lifecycleOwner
            )

            else -> loadNativeFirst(
                adConfigNative = adConfigNative,
                adConfigBanner = adConfigBanner,
                adContainer = adContainer,
                lifecycleOwner = lifecycleOwner
            )
        }
    }

    private fun loadBannerFirst(
        adConfigBanner: AdConfigManager,
        adConfigNative: AdConfigManager,
        lifecycleOwner: LifecycleOwner,
        adContainer: FrameLayout?
    ) {
        loadBannerAd(
            adConfig = adConfigBanner,
            lifecycleOwner = lifecycleOwner,
            adContainer = adContainer
        )
    }

    private fun loadNativeFirst(
        adConfigNative: AdConfigManager,
        adConfigBanner: AdConfigManager,
        lifecycleOwner: LifecycleOwner,
        adContainer: FrameLayout?
    ) {
        loadNative(
            adConfigManager = adConfigNative,
            lifecycleOwner = lifecycleOwner,
            adContainer = adContainer
        )
    }

    private fun loadNative(
        adConfigManager: AdConfigManager,
        adContainer: FrameLayout?,
        lifecycleOwner: LifecycleOwner,
    ) {
        Log.i(TAG, "loadNative: Exp")
        adContainer.show()
        AdsManagerX.loadNativeAd(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            bannerAdContainer = adContainer,
            onAdLoaded = {
                Log.i(TAG, "loadNative: onAdLoaded")
                onAdLoadedExternal?.invoke()
            },
            onAdFailed = {
                Log.i(TAG, "loadNative: onAdFailed")
                if (getFreshExpConfig().adType == BANNER_AD)
                    "Both have been failed".printIt()
                else onNativeAdFailedToLoad?.invoke()
                onAdFailedExternal?.invoke()
                if (AdsManagerX.isNativeAdLoaded(adConfigManager)) return@loadNativeAd
                adContainer.hide()
            },
            onAdRequestDenied = {
                Log.i(TAG, "loadNative: onAdRequestDenied")
                onAdRequestDeniedExternal?.invoke()
                if (AdsManagerX.isNativeAdLoaded(adConfigManager)) return@loadNativeAd
                adContainer.hide()
            },
            onAdImpression = {
                Log.i(TAG, "loadNative: onAdImpression")
                setNativeRefreshAd(config.screenId, isRefreshingAd())
                if (isNativeRefreshAd(config.screenId)) {
                    setupRefreshTimer()
                }
            }
        )
    }

    private fun loadBannerAd(
        adConfig: AdConfigManager,
        lifecycleOwner: LifecycleOwner,
        adContainer: FrameLayout?
    ) {
        adContainer.show()
        AdsManagerX.loadBannerAd(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfig,
            bannerAdContainer = adContainer,
            onAdLoaded = {
                setNativeRefreshAd(config.screenId, false)
                onAdLoadedExternal?.invoke()
            },
            onAdFailed = {
                if (getFreshExpConfig().adType == NATIVE_AD)
                    "Both have been failed".printIt()
                else onBannerAdFailedToLoad?.invoke()
                onAdFailedExternal?.invoke()
                if (!AdsManagerX.isBannerAdLoaded(adConfig)) {
                    adContainer.hide()
                }
            },
            onAdImpression = {
                Log.i(TAG, "loadBannerAd: onAdImpression")
                setNativeRefreshAd(config.screenId, isRefreshingAd())
                if (isNativeRefreshAd(config.screenId)) {
                    setupRefreshTimer()
                }
            },
            onAdRequestDenied = {
                onAdRequestDeniedExternal?.invoke()
                if (!AdsManagerX.isBannerAdLoaded(adConfig)) {
                    adContainer.hide()
                }
            }
        )
    }

    private fun showNativeAd(
        adConfigManager: AdConfigManager,
        adContainer: FrameLayout?
    ) {
        AdsManagerX.showNativeAd(adConfigManager, adContainer)
    }

    private fun showBannerAd(
        adConfigManager: AdConfigManager,
        adContainer: FrameLayout?
    ) {
        AdsManagerX.showBannerAd(adConfigManager, adContainer)
    }

    private fun isRefreshingAd() = getFreshExpConfig().isAdLoadAgain

    fun pauseRefreshTimer(experimentManager: ExperimentManager) {
        config = experimentManager
        Log.i(TAG, "pauseRefreshTimer: ")
        expCountDownTimer?.cancel()
        expCountDownTimer = null
        setScreenPaused(config.screenId, true)
    }

    fun resumeRefreshTimer(experimentManager: ExperimentManager) {
        config = experimentManager
        Log.i(TAG, "resumeRefreshTimer: ")
        try {
            if (isScreenPaused(config.screenId)) {
                setScreenPaused(config.screenId, false)
                if (expCountDownTimer == null) {
                    startRefreshTimer()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupRefreshTimer() {
        val adConfig =
            config.nativeRefreshAd.adConfig.fetchAdConfigFromRemote(config.nativeRefreshAd.name)
        adConfig?.beforeAdLoadingTimeInMs?.let {
            setRefreshTime(config.screenId, it)
            startRefreshTimer()
        }
    }

    private fun startRefreshTimer() {
        expCountDownTimer?.cancel()
        if (isScreenPaused(config.screenId) || !isRefreshingAd()) return

        expCountDownTimer = null
        Log.i(TAG, "startRefreshTimer")
        expCountDownTimer = object : CountDownTimer(getRefreshTime(config.screenId), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val elapsedTime = getRefreshTime(config.screenId)
                Log.i(TAG, "onTick: $elapsedTime")
                setRefreshTime(config.screenId, elapsedTime.minus(1000))
            }

            override fun onFinish() {
                Log.i(TAG, "onFinish: ${loadRefreshNativeAd?.toString()}")
                loadRefreshNativeAd?.invoke()
            }
        }
        expCountDownTimer?.start()
    }

    private fun updateCallbacks(
        adConfigExperiment: AdConfig?,
        lifecycleOwner: LifecycleOwner,
        adContainer: FrameLayout?
    ) {
        val isAdLoadAgain =
            adConfigExperiment?.isAdLoadAgain ?: config.expHandler.adConfig.isAdLoadAgain

        val adConfigNative = if (isAdLoadAgain) {
            config.nativeRefreshAd
        } else {
            config.nativeNoRefreshAd
        }

        val adConfigBanner = if (isAdLoadAgain) {
            config.bannerRefreshAd
        } else {
            config.bannerNoRefreshAd
        }

        loadRefreshNativeAd = {
            "adType -> ${config.expHandler.adConfig.adType}".printIt()
            if (getFreshExpConfig().adType == BANNER_AD) {
                "Banner ad is already refreshing.so need to load ad".printIt()
            } else loadNative(
                adConfigManager = adConfigNative,
                adContainer = adContainer,
                lifecycleOwner = lifecycleOwner
            )
        }

        onNativeAdFailedToLoad = {
            loadBannerAd(
                adConfig = adConfigBanner,
                lifecycleOwner = lifecycleOwner,
                adContainer = adContainer
            )
        }

        onBannerAdFailedToLoad = {
            loadNative(
                adConfigManager = adConfigNative,
                adContainer = adContainer,
                lifecycleOwner = lifecycleOwner
            )
        }
    }

    /**
     * resetAll is used to reset all the ads and timer, use when app is going to be terminated.
     * */
    fun resetAll() {
        pauseRefreshTimer(config)
        onBannerAdFailedToLoad = null
        onNativeAdFailedToLoad = null
        loadRefreshNativeAd = null
        onAdLoadedExternal = null
        onAdFailedExternal = null
        onAdRequestDeniedExternal = null
        clearAll()
        destroyAllAds(config)
    }

    /**
     * destroyAllAds is used to destroy ads based on their impressions.
     * */
    fun destroyAllAds(config: ExperimentManager) {
        with(AdsManagerX) {
            "experiment_${config.screenId},config:${config}".printIt()
            if (isAdImpressionRecorded(config.bannerRefreshAd))
                destroyBannerAd(config.bannerRefreshAd)
            if (isAdImpressionRecorded(config.bannerNoRefreshAd))
                destroyBannerAd(config.bannerNoRefreshAd)
            if (isAdImpressionRecorded(config.nativeRefreshAd))
                destroyNativeAd(config.nativeRefreshAd)
            if (isAdImpressionRecorded(config.nativeNoRefreshAd))
                destroyNativeAd(config.nativeNoRefreshAd)
        }
    }

    /**
     * Exp Functions to show ads in UI based on experiment.
     * */
    fun isExpAdLoaded(config: ExperimentManager): Boolean {
        with(AdsManagerX) {
            "isExpAdLoaded ${config.screenId},config:${config}".printIt()
            val isAdLoaded = if (isBannerAdLoaded(config.bannerRefreshAd))
                true
            else if (isBannerAdLoaded(config.bannerNoRefreshAd))
                true
            else if (isNativeAdLoaded(config.nativeRefreshAd))
                true
            else if (isNativeAdLoaded(config.nativeNoRefreshAd))
                true
            else false
            "isAdLoaded,$isAdLoaded".printIt()
            return isAdLoaded
        }
    }

    private val screenRefreshTimes = mutableMapOf<String, Long>()
    private val screenPauseStates = mutableMapOf<String, Boolean>()
    private val screenNativeStates = mutableMapOf<String, Boolean>()

    private fun getRefreshTime(screenId: String): Long = screenRefreshTimes[screenId] ?: 15000L

    private fun setRefreshTime(screenId: String, time: Long) {
        screenRefreshTimes[screenId] = time
    }

    private fun isScreenPaused(screenId: String): Boolean = screenPauseStates[screenId] ?: false

    private fun setScreenPaused(screenId: String, isPaused: Boolean) {
        screenPauseStates[screenId] = isPaused
    }

    private fun isNativeRefreshAd(screenId: String): Boolean = screenNativeStates[screenId] ?: false

    private fun setNativeRefreshAd(screenId: String, isRefresh: Boolean) {
        screenNativeStates[screenId] = isRefresh
    }

    private fun clearScreen(screenId: String) {
        screenRefreshTimes.remove(screenId)
        screenPauseStates.remove(screenId)
    }

    private fun clearAll() {
        screenNativeStates.clear()
        screenPauseStates.clear()
        screenRefreshTimes.clear()
    }
}