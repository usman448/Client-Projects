package com.hm.admanager

import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.hm.admanagerx.printIt


private const val FETCH_TIME_INTERVAL = 1 * 60 * 60L   //  hours * minutes * seconds


var configMap: Map<String, Any>? = null

const val showSubscriptionScreenOnNewUser = "showSubscriptionScreenOnNewUser"
const val SHOW_SUBSCRIPTION_SCREEN_RETURNING_USER = "SHOW_SUBSCRIPTION_SCREEN_RETURNING_USER"
const val IS_LANG_ENABLE = "IS_LANG_ENABLE"

fun checkDefaultConfigValue(key: String): Boolean = configMap?.get(key) == null
fun String.getLongRemoteConfigValue(): Long {
    return FirebaseRemoteConfig.getInstance()
        .getLong(this)
}
fun String.getBooleanRemoteConfigValue(): Boolean {
    return FirebaseRemoteConfig.getInstance()
        .getBoolean(this)
}
fun isRemoteShowAd(adRemoteConfigKey: String): Boolean {
    if (checkDefaultConfigValue(adRemoteConfigKey)) return true
    return FirebaseRemoteConfig.getInstance().getBoolean(adRemoteConfigKey)
}

fun remoteCountShowAd(adRemoteConfigKey: String) =
    FirebaseRemoteConfig.getInstance().getLong(adRemoteConfigKey)

fun initFirebaseRemoteConfig(onComplete: ((Boolean) -> Unit)? = null) {

    val remoteConfig = FirebaseRemoteConfig.getInstance()
    val configSettings = FirebaseRemoteConfigSettings.Builder()
        .setMinimumFetchIntervalInSeconds(1)
        .build()
    remoteConfig.setConfigSettingsAsync(configSettings)

   /*  configMap = mapOf(
         showSubscriptionScreenOnReturningUser to 0
     ).apply {
         remoteConfig.setDefaultsAsync(this)
     }*/


    remoteConfig.fetchAndActivate().addOnCompleteListener {
        "remote ${it.isSuccessful}".printIt()
        onComplete?.invoke(it.isSuccessful)
    }
}

/*
const val IS_MAIN_NATIVE_AD_SHOW = "IS_MAIN_NATIVE_AD_SHOW"
const val IS_APP_OPEN_AD_SHOW = "IS_APP_OPEN_AD_SHOW"
const val IS_BANNER_AD_SHOW = "IS_BANNER_AD_SHOW"
const val IS_REWARDED_AD_SHOW = "IS_REWARDED_AD_SHOW"
const val IS_INTER_AD_SHOW = "IS_INTER_AD_SHOW"
const val INTER_AD_COUNT_SHOW = "INTER_AD_COUNT_SHOW"*/
