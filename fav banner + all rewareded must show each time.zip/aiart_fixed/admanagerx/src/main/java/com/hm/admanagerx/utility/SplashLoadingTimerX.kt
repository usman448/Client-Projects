package com.hm.admanagerx.utility

import android.os.Handler
import android.os.Looper

class SplashLoadingTimerX(
    private val onTickUpdate: (Int) -> Unit,
    private val onFinish: () -> Unit,
) {

    private val handler = Handler(Looper.getMainLooper())
    private var currentLoading = 0
    private var isPaused = false
    private var onLoadingPause = false
    private var runnable: Runnable? = null

    fun startTimer(maxLoadingInSec: Int) {
        runnable = Runnable {
            if (!isPaused) {
                currentLoading++
                onTickUpdate(currentLoading)
            }

            if (currentLoading < maxLoadingInSec) {
                runnable?.let { handler.postDelayed(it, 1000) }
            } else {
                onFinish()
            }
        }

        handler.postDelayed(runnable!!, 1000)
    }

    fun pauseTimer() {
        if (onLoadingPause) return
        isPaused = true
    }

    fun resumeTimer() {
        if (onLoadingPause) return
        isPaused = false
    }

    //pause on Ad loading view show
    fun pauseOnLoading() {
        pauseTimer()
        onLoadingPause = true
    }

    //pause on Ad loading view show
    fun resumeOnLoading() {
        resumeTimer()
        onLoadingPause = false

    }

    fun stopTimer() {
        runnable?.let { handler.removeCallbacks(it) }
        onFinish()
    }
}

