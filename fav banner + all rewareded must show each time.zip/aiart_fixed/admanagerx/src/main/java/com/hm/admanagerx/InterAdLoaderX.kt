package com.hm.admanagerx

import android.app.Dialog
import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.hm.admanagerx.AdsManagerX.isAppLevelAdsInitializationSuccess
import com.hm.admanagerx.adsanalysis.AdAnalyticsTracker
import com.hm.admanagerx.utility.HandlerX

class InterAdLoaderX(var context: Context) {
    private var adRequestLoading: Boolean = false
    var mInterstitialAd: InterstitialAd? = null
    private var TAG = "InterAdLoaderX"
    var isAdImpression: Boolean = false
    var onAdClose: MutableLiveData<Unit>? = null
    var onAdShow: MutableLiveData<Unit>? = null

    private var onAdLoaded: MutableLiveData<InterstitialAd>? = null
    private var onAdFailed: MutableLiveData<String>? = null
    private var onAdClicked: MutableLiveData<Unit>? = null
    private var onAdImpression: MutableLiveData<Unit>? = null
    private var funBlock: MutableLiveData<AdCheckResult>? = null
    private lateinit var adConfig: AdConfig
    private lateinit var adConfigManager: AdConfigManager
    private var adSessionCount: Long = 1

    var adShowCount: Long = 0

    private var loadingDialog: Dialog? = null

    val adAnalyticsTracker: AdAnalyticsTracker by lazy { AdAnalyticsTracker(adConfigManager.name) }

    fun getAdConfigManager() = adConfigManager


    fun loadInterAdX(
        adConfigManager: AdConfigManager,
        onAdLoaded: MutableLiveData<InterstitialAd>? = null,
        onAdFailed: MutableLiveData<String>? = null,
        onAdRequestDenied: MutableLiveData<Unit>? = null,
    ) {
        this.adConfigManager = adConfigManager
        this.adConfig = adConfigManager.adConfig
        this.onAdLoaded = onAdLoaded
        this.onAdFailed = onAdFailed
        val checkInterAd = checkInterAdLoad()

        if (checkInterAd != AdCheckResult.ReadyToGo) {
            onAdRequestDenied?.value = Unit
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} $checkInterAd".printIt(TAG)
            return
        }

        val adRequest = AdRequest.Builder().build()
        val interAdId = context.getAdId(adConfig.adId)

        "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad loaded request".printIt(TAG)
        context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_request")
        context.showToast("${adConfigManager.name} request send")
        adAnalyticsTracker.trackAdRequest()
        adRequestLoading = true
        isAdImpression = false

        InterstitialAd.load(context, interAdId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_loaded")
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad loaded".printIt(TAG)
                mInterstitialAd = null
                mInterstitialAd = ad
                mInterstitialAd?.fullScreenContentCallback = interAdCallback
                adRequestLoading = false
                onAdLoaded?.value = ad
                adAnalyticsTracker.trackAdLoaded()
            }

            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d("fdlsfsf897fjskf", "hre is called onAdFailedToLoad  ${adShowCount} ")
                context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_failed")
                "${adConfigManager.name}_${adConfigManager.adConfig.adType}" + adError.toString()
                    .printIt(TAG)
                mInterstitialAd = null
                adRequestLoading = false
                onAdFailed?.value = adError.message
                dismissDialog()
                adShowCount = 0
//                funBlock?.value = AdCheckResult.AdFailedToLoad(adError.message)
                adAnalyticsTracker.trackAdLoadFailed()
            }
        })
    }


    val interAdCallback = object : FullScreenContentCallback() {
        override fun onAdShowedFullScreenContent() {
            context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_show")
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad showed".printIt(TAG)
            mInterstitialAd = null
            adShowCount = 0
            //this for avoid app open Ad show when inter ad show
            context.isInterAdShow(true)

            onAdShow?.value = Unit
            if (adConfig.isAdLoadAgain) {
                reloadAd()
            }

            if (adConfig.fullScreenAdSessionCount > 0) adSessionCount++

            adAnalyticsTracker.trackAdShow()
            HandlerX(500) {
                dismissDialog()
            }
        }

        override fun onAdDismissedFullScreenContent() {
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad dismissed".printIt(TAG)
            onAdClose?.value = Unit
            dismissDialog()
            context.isInterAdShow(false)
            isAdImpression = false
        }

        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad failed to show ${adError.message}".printIt(
                TAG
            )
            funBlock?.value = AdCheckResult.AdFailedToShow(adError.message)
            mInterstitialAd = null
            adShowCount = 0
            dismissDialog()
            adAnalyticsTracker.trackAdShowFailed()
        }

        override fun onAdClicked() {
            super.onAdClicked()
            onAdClicked?.value = Unit
            context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_clicked")
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} onAdClicked".printIt(TAG)
            adAnalyticsTracker.trackAdClicked()
        }

        override fun onAdImpression() {
            super.onAdImpression()
            context.sendLogs("${adConfigManager.name}_${adConfigManager.adConfig.adType}_impression")
            onAdImpression?.value = Unit
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} onAdImpression".printIt(TAG)
            adAnalyticsTracker.trackAdImpression()
            isAdImpression = true
        }

    }

    private fun dismissDialog() {
        loadingDialog?.dismiss()
        loadingDialog = null
    }

    fun reloadAd() = loadInterAdX(adConfigManager, onAdLoaded, onAdFailed, null)

    fun isAdLoaded() = mInterstitialAd != null

    fun showAd(
        activity: AppCompatActivity,
        onAdClose: MutableLiveData<Unit>? = null,
        onAdShow: MutableLiveData<Unit>? = null,
        onAdClicked: MutableLiveData<Unit>? = null,
        onAdImpression: MutableLiveData<Unit>? = null,
        onLoadingShowHide: MutableLiveData<Boolean>? = null,
        funBlock: MutableLiveData<AdCheckResult>? = null,
    ) {
        if (loadingDialog?.isShowing == true) return
        this.onAdClose = onAdClose
        this.onAdShow = onAdShow
        this.onAdClicked = onAdClicked
        this.onAdImpression = onAdImpression
        this.funBlock = funBlock

        val currentState = checkInterAdShow()
        if (currentState != AdCheckResult.ReadyToGo) {
            funBlock?.value = currentState
            return
        }


        // Remote config Ad click counter logic`
        if (adShowCount < adConfig.fullScreenAdCount) {

            funBlock?.value = AdCheckResult.CounterNotReached(adShowCount)
            adShowCount++

            Log.d(
                "fdskjfksf9s8fshfks",
                "in inter ad laod call in show  -> ${adConfig.fullScreenAdLoadOnCount} -> ${adShowCount}  -> ${adConfig.fullScreenAdCount}"
            )
            "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad show denied: current count is $adShowCount".printIt()
            if (!isAdLoaded() && adConfig.fullScreenAdLoadOnCount >= 0L && adShowCount == adConfig.fullScreenAdLoadOnCount) {
                reloadAd()
            }
            return
        }

        loadingDialog = adConfig.showLoadingBeforeAd(
            isAdLoaded(), activity, adConfig.fullScreenAdLoadingLayout,
            onDone = {
                mInterstitialAd?.show(activity) ?: run {
                    "${adConfigManager.name}_${adConfigManager.adConfig.adType} Ad show denied: Ad is null"
                    funBlock?.value = AdCheckResult.None
                }
            }, onLoadingShowHide = {
                onLoadingShowHide?.value = it
            })
    }


    private fun checkInterAdShow(): AdCheckResult {
        return when {
            !context.isOnline() -> AdCheckResult.Offline
            context.isPremium() -> AdCheckResult.PremiumUser
            !adConfig.isAdShow -> AdCheckResult.AdsDisabled
            adRequestLoading -> AdCheckResult.AdLoading
            checkAdSession() -> AdCheckResult.AdSessionLimitReached
            else -> AdCheckResult.ReadyToGo
        }
    }

    private fun checkInterAdLoad(): AdCheckResult {
        val checkAdReason = checkInterAdShow()
        return when {
            checkAdReason != AdCheckResult.ReadyToGo -> checkAdReason
            isAdLoaded() -> AdCheckResult.AdAlreadyLoaded
            !isAppLevelAdsInitializationSuccess -> AdCheckResult.AdsInitializationFailed
            checkLoadAdOnCount() -> AdCheckResult.CounterNotReached(adConfig.fullScreenAdCount)
            else -> AdCheckResult.ReadyToGo
        }
    }

    private fun checkAdSession() =
        (adSessionCount > adConfig.fullScreenAdSessionCount && adConfig.fullScreenAdSessionCount != 0L)

    private fun checkLoadAdOnCount(): Boolean {

        Log.d(
            "fdskjfksf9s8fshfks",
            "in inter ad laod call -> ${adConfig.fullScreenAdLoadOnCount} -> ${adShowCount} ->${adConfig.fullScreenAdCount} "
        )

        Log.d(
            "fdskjfksf9s8fshfks",
            "in inter ad laod call -> ${adConfig.fullScreenAdLoadOnCount >= 0L} -> ${adShowCount != adConfig.fullScreenAdLoadOnCount} "
        )

        return ((adConfig.fullScreenAdLoadOnCount >= 0L && adShowCount != adConfig.fullScreenAdLoadOnCount))

    }

}

