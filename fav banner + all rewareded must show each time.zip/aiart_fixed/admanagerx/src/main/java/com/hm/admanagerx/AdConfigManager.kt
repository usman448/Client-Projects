package com.hm.admanagerx

enum class AdConfigManager(var adConfig: AdConfig) {
    SETTINGS_LANGUAGE_NATIVE(
        AdConfig(
            adId = R.string.native_am,
            nativeAdLayout = R.layout.native_ad,
            isAdLoadAgain = true,
            isShowLoadingBeforeAd = true
        )
    ),
    SHOW_MAIN_NATIVE_EXIT_DIALOG(
        AdConfig(
            adType = NATIVE_AD,
            adId = R.string.native_am,
            nativeAdLayout = R.layout.native_ad,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),

    LIST_NATIVE_AD_FOR_HISTORY(
        AdConfig(
            adType = NATIVE_AD,
            adId = R.string.native_am,
            nativeAdLayout = R.layout.native_ad,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),

    NATIVE_AD_LANGUAGE(
        AdConfig(
            adType = NATIVE_AD,
            adId = R.string.native_am,
            nativeAdLayout = R.layout.native_ad,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),

    HOME_NATIVE_IN_BETWEEN(
        AdConfig(
            adType = NATIVE_AD,
            adId = R.string.native_am,
            nativeAdLayout = R.layout.native_ad,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),
    BANNER_AD_RESULT(
        AdConfig(
            adId = R.string.banner_result,
            nativeAdLayout = R.layout.native_add_banner_view,
            isAdLoadAgain = true,
            isShowLoadingBeforeAd = true
        )
    ),
    HISTORY_BANNER(
        AdConfig(
            adId = R.string.banner_result,
            nativeAdLayout = R.layout.native_add_banner_view,
            isAdLoadAgain = true,
            isShowLoadingBeforeAd = true
        )
    ),

    BANNER_AD_MAIN(
        AdConfig(
            adId = R.string.banner_result,
            nativeAdLayout = R.layout.native_add_banner_view,
            isAdLoadAgain = true,
            isShowLoadingBeforeAd = true
        )
    ),

    INTER_AD(
        AdConfig(
            adType = com.hm.admanagerx.INTER_AD,
            adId = R.string.inter_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true,
            fullScreenAdCount = 0,
            fullScreenAdLoadOnCount = 0,
            fullScreenAdSessionCount = 0
        )
    ),

    SPLASH_INTER_RETURNING_USER(
        AdConfig(
            adId = R.string.inter_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true,
        )
    ),

    SPLASH_INTER_NEW_USER(
        AdConfig(
            adId = R.string.inter_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true,
        )
    ),

    LANGUAGE_INTER_SPLASH_FALLBACK(
        AdConfig(
            adId = R.string.inter_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true,
        )
    ),

    SETTINGS_LANGUAGE_INTER(
        AdConfig(
            adId = R.string.inter_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true
        )
    ),
    BANNER_AD_THEME_CLICK_AIART(
        AdConfig(
            adType = BANNER_AD,
            adId = R.string.banner_am,
            nativeAdLayout = R.layout.banner_ad_loading_view,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),
    BANNER_AD_IMG_TYPE
        (
        AdConfig(
            adType = BANNER_AD,
            adId = R.string.banner_am,
            nativeAdLayout = R.layout.banner_ad_loading_view,
            isAdShow = true,
            isShowLoadingBeforeAd = true,
        )
    ),

    REWARDED_AD_GENERATE(
        AdConfig(
            adType = com.hm.admanagerx.REWARDED_AD,
            adId = R.string.rewarded_ad_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true
        )
    ),

    CHOOSE_MODEL_REWARDED(
        AdConfig(
            adType = com.hm.admanagerx.REWARDED_AD,
            adId = R.string.rewarded_ad_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true
        )
    ),

    REWARDED_INTER_AD(
        AdConfig(
            adType = REWARDED_INTERSTITIAL_AD,
            adId = R.string.rewarded_ad_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true
        )
    ),
    CHOOSE_MODEL_REWARDED_INTER(
        AdConfig(
            adType = REWARDED_INTERSTITIAL_AD,
            adId = R.string.rewarded_ad_am,
            isAdLoadAgain = false,
            isShowLoadingBeforeAd = true
        )
    ),
    APP_OPEN_AIART(
        AdConfig(
            adId = R.string.app_open_ad,
            isAdLoadAgain = true,
            adType = APP_OPEN_AD,
            isAppOpenAdAppLevel = true
        )
    ),
}




