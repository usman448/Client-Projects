package com.hm.admanagerx

import android.app.Activity
import android.app.Application
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.hm.admanager.initFirebaseRemoteConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object AdsManagerX : ParentAdsManagerX() {
    var isFirebaseEventEnabled: Boolean = false
    var isAppLevelAdsInitializationSuccess = false
    //   var isLastAdFailThenReasion: Pair<String, FunBlockScenario>? = null

    /**
     * isAppLevelAdsInitialization (Optional : because ANR reported on MobileAds.initialize())
     * onInitializeComplete : callback when Google Mobile Ads SDK or mediation partner SDKs initialization complete
     */
    fun init(
        application: Application,
        isAppLevelAdsInitialization: Boolean = true,
        onAdsSdkInitializeComplete: (() -> Unit)? = null,
    ): AdsManagerX {
        this.application = application
        isAppLevelAdsInitializationSuccess = false
        application.isInterAdShow(false)





        if (isAppLevelAdsInitialization) {
            CoroutineScope(Dispatchers.IO).launch {
                MobileAds.initialize(application) {
                    CoroutineScope(Dispatchers.Main).launch {
                        isAppLevelAdsInitializationSuccess = true
                        onAdsSdkInitializeComplete?.invoke()
                        loadAdsInQueueAfterInit()
                    }
                }
            }
        } else {
            isAppLevelAdsInitializationSuccess = true
        }
        return this
    }

    /**
     * Get Firebase remote config values
     */
    fun loadFirebaseRemoteConfig(onComplete: ((Boolean) -> Unit)? = null): AdsManagerX {
        initFirebaseRemoteConfig(onComplete)
        return this
    }

    /**
     * Send ads events to Firebase Analytics
     */
    fun enableFirebaseEvent(enable: Boolean): AdsManagerX {
        isFirebaseEventEnabled = enable
        return this
    }
    /** ----- Inter Ad --------**/

    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    fun loadInterAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        adConfigManager.adConfig.adType = INTER_AD
        loadFullScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdRequestDenied = onAdRequestDenied
        )
    }


    fun showInterAd(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdShow: (() -> Unit)? = null,
        onAdClose: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,//only for rewarded ad
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: ((AdCheckResult) -> Unit)? = null
    ) {
        val newAdConfigManager =
            interAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        showFullScreenAdWithTypeCheck(
            activity = activity,
            adConfigManager = newAdConfigManager,
            onAdShow = {
                //   isLastAdFailThenReasion = null
                onAdShow?.invoke()
            },
            onAdClose = onAdClose,
            onAdClicked = onAdClicked,
            onAdImpression = {
                //   isLastAdFailThenReasion = null
                onAdImpression?.invoke()
            },
            onUserEarnedRewarded = onUserEarnedRewarded,
            onLoadingShowHide = onLoadingShowHide,
            funBlockForInter = {
                /*   if (handleFallBack) {
                       Log.d(
                           "fdsjhfsh4535jlkf",
                           "invoked fail reasion -> ${it}  "
                       )
                    //   isLastAdFailThenReasion = Pair(adConfigManager.name, it)
                   }*/
                funBlock?.invoke(it)
            }
        )
    }

    fun isInterAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            interAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return isFullScreenAdWithTypeLoaded(newAdConfigManager)
    }


    fun destroyInterAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            interAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        destroyFullScreenAdWithType(newAdConfigManager)
    }


    fun reloadInterAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            interAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        reloadFullScreenAdWithType(newAdConfigManager)
    }


    fun resetCounter(adConfigManager: AdConfigManager) {
        interAdList[adConfigManager.name]?.adShowCount = 0
    }


    /** ----- Native Ad --------**/

    fun loadNativeAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {

        adConfigManager.adConfig.adType = NATIVE_AD
        loadInScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            adContainer = bannerAdContainer,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onAdRequestDenied = onAdRequestDenied
        )
    }


    fun isNativeAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            bannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> nativeAdList[adConfigManager.name]?.isAdLoaded() ?: false
            BANNER_AD -> bannerAdList[adConfigManager.name]?.isAdLoaded ?: false
            COLLAPSIBLE_BANNER_AD -> collapsibleBannerAdList[adConfigManager.name]?.isAdLoaded
                ?: false

            else -> false
        }
    }

    /**
     * Rewarded & App Open is not supported yet!
     * **/
    fun isAdImpressionRecorded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            nativeAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> nativeAdList[adConfigManager.name]?.isAdImpression ?: false
            BANNER_AD -> bannerAdList[adConfigManager.name]?.isAdImpression ?: false
            INTER_AD -> interAdList[adConfigManager.name]?.isAdImpression ?: false
            else -> false
        }
    }

    fun showNativeAd(adConfigManager: AdConfigManager, nativeAdContainer: FrameLayout?) {
        val newAdConfigManager =
            nativeAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> showNativeAdX(
                adConfigManager = newAdConfigManager,
                nativeAdContainer = nativeAdContainer
            )

            BANNER_AD -> showBannerAdX(
                adConfigManager = newAdConfigManager,
                bannerAdContainer = nativeAdContainer
            )

            COLLAPSIBLE_BANNER_AD -> showCollapsibleBannerAdX(
                adConfigManager = newAdConfigManager,
                bannerAdContainer = nativeAdContainer
            )
        }
    }

    // Banner ad auto reload
    fun reloadNativeAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            nativeAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        nativeAdList[newAdConfigManager.name]?.reloadAd()
    }


    fun destroyNativeAd(adConfigManager: AdConfigManager) {

        val newAdConfigManager =
            nativeAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> destroyNativeAdX(newAdConfigManager)
            BANNER_AD -> destroyBannerX(newAdConfigManager)
            COLLAPSIBLE_BANNER_AD -> destroyCollapsibleBannerX(newAdConfigManager)
        }
    }


    /** ----- Banner Ad --------**/


    fun loadBannerAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        adConfigManager.adConfig.adType = BANNER_AD

        loadInScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            adContainer = bannerAdContainer,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onAdRequestDenied = onAdRequestDenied
        )
    }

    fun isBannerAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            bannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> nativeAdList[adConfigManager.name]?.isAdLoaded() ?: false
            BANNER_AD -> bannerAdList[adConfigManager.name]?.isAdLoaded ?: false
            COLLAPSIBLE_BANNER_AD -> collapsibleBannerAdList[adConfigManager.name]?.isAdLoaded
                ?: false

            else -> false
        }
    }

    fun showBannerAd(adConfigManager: AdConfigManager, nativeAdContainer: FrameLayout?) {

        val newAdConfigManager =
            bannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> showNativeAdX(
                adConfigManager = newAdConfigManager,
                nativeAdContainer = nativeAdContainer
            )

            BANNER_AD -> showBannerAdX(
                adConfigManager = newAdConfigManager,
                bannerAdContainer = nativeAdContainer
            )

            COLLAPSIBLE_BANNER_AD -> showCollapsibleBannerAdX(
                adConfigManager = newAdConfigManager,
                bannerAdContainer = nativeAdContainer
            )
        }
    }


    fun destroyBannerAd(adConfigManager: AdConfigManager) {

        val newAdConfigManager =
            bannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        when (newAdConfigManager.adConfig.adType) {
            NATIVE_AD -> destroyNativeAdX(newAdConfigManager)
            BANNER_AD -> destroyBannerX(newAdConfigManager)
            COLLAPSIBLE_BANNER_AD -> destroyCollapsibleBannerX(newAdConfigManager)
        }
    }


    /** ----- Collapsible Banner Ad --------**/

    fun loadCollapsibleBannerAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
        activity: Activity
    ) {
        adConfigManager.adConfig.adType = COLLAPSIBLE_BANNER_AD

        loadInScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            adContainer = bannerAdContainer,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onAdRequestDenied = onAdRequestDenied,
            activity = activity

        )
    }

    fun isCollapsibleBannerAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            collapsibleBannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return when (newAdConfigManager.adConfig.adType) {
            COLLAPSIBLE_BANNER_AD -> collapsibleBannerAdList[adConfigManager.name]?.isAdLoaded
                ?: false

            else -> false
        }
    }

    fun showCollapsibleBannerAd(adConfigManager: AdConfigManager, bannerAdContainer: FrameLayout?) {
        val newAdConfigManager =
            collapsibleBannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        when (newAdConfigManager.adConfig.adType) {
            COLLAPSIBLE_BANNER_AD -> showCollapsibleBannerAdX(
                adConfigManager = newAdConfigManager,
                bannerAdContainer = bannerAdContainer
            )
        }
    }

    fun destroyCollapsibleBannerAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            collapsibleBannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        when (newAdConfigManager.adConfig.adType) {
            COLLAPSIBLE_BANNER_AD -> destroyCollapsibleBannerX(newAdConfigManager)
        }
    }

    /*  fun reloadCollapsibleBannerAd(adConfigManager: AdConfigManager) {
          val newAdConfigManager =
              collapsibleBannerAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
          collapsibleBannerAdList[newAdConfigManager.name]?.loadCollapsibleBannerAdX(
              adConfigManager = newAdConfigManager,
              adSize = newAdConfigManager.adConfig.bannerAdSize,
              onAdLoaded = null,
              onAdFailed = null,
              onAdClicked = null,
              onAdImpression = null,
              onAdRequestDenied = null
          )
      }*/


    /** ----- Rewarded Ad --------**/

    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    fun loadRewardedAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,

        ) {
        adConfigManager.adConfig.adType = REWARDED_AD
        loadFullScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdRequestDenied = onAdRequestDenied
        )
    }


    fun showRewardedAd(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,//only for rewarded ad
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        val newAdConfigManager =
            rewardedAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        showFullScreenAdWithTypeCheck(
            activity = activity,
            adConfigManager = newAdConfigManager,
            onAdShow = onAdShow,
            onAdClose = onAdClose,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onUserEarnedRewarded = onUserEarnedRewarded,
            onLoadingShowHide = onLoadingShowHide,
            funBlock = funBlock
        )
    }

    fun isRewardedAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            rewardedAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return isFullScreenAdWithTypeLoaded(newAdConfigManager)
    }

    fun destroyRewardedAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            rewardedAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        destroyFullScreenAdWithType(newAdConfigManager)
    }

    fun reloadRewardedAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            rewardedAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        reloadFullScreenAdWithType(newAdConfigManager)
    }


    /** ----- Rewarded Interstitial Ad --------**/

    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    fun loadRewardedInterstitialAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,

        ) {
        adConfigManager.adConfig.adType = REWARDED_INTERSTITIAL_AD
        loadFullScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdRequestDenied = onAdRequestDenied
        )
    }


    fun showRewardedInterstitialAd(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,//only for rewarded ad
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        val newAdConfigManager =
            rewardedInterstitialAdList[adConfigManager.name]?.getAdConfigManager()
                ?: adConfigManager

        showFullScreenAdWithTypeCheck(
            activity = activity,
            adConfigManager = newAdConfigManager,
            onAdShow = onAdShow,
            onAdClose = onAdClose,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onUserEarnedRewarded = onUserEarnedRewarded,
            onLoadingShowHide = onLoadingShowHide,
            funBlock = funBlock
        )
    }

    fun isRewardedInterstitialAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            rewardedInterstitialAdList[adConfigManager.name]?.getAdConfigManager()
                ?: adConfigManager
        return isFullScreenAdWithTypeLoaded(newAdConfigManager)
    }

    fun destroyRewardedInterstitialAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            rewardedInterstitialAdList[adConfigManager.name]?.getAdConfigManager()
                ?: adConfigManager
        destroyFullScreenAdWithType(newAdConfigManager)
    }

    fun reloadRewardedInterstitialAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            rewardedInterstitialAdList[adConfigManager.name]?.getAdConfigManager()
                ?: adConfigManager
        reloadFullScreenAdWithType(newAdConfigManager)
    }


    /** ----- AppOpen Ad --------**/

    fun loadAppOpenAd(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        adConfigManager.adConfig.adType = APP_OPEN_AD
        loadFullScreenAdWithTypeCheck(
            lifecycleOwner = lifecycleOwner,
            adConfigManager = adConfigManager,
            onAdLoaded = onAdLoaded,
            onAdFailed = onAdFailed,
            onAdRequestDenied = onAdRequestDenied
        )
    }


    fun showAppOpenAd(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,//only for rewarded ad
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {

        val newAdConfigManager =
            appOpenAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager

        showFullScreenAdWithTypeCheck(
            activity = activity,
            adConfigManager = newAdConfigManager,
            onAdShow = onAdShow,
            onAdClose = onAdClose,
            onAdClicked = onAdClicked,
            onAdImpression = onAdImpression,
            onUserEarnedRewarded = onUserEarnedRewarded,
            onLoadingShowHide = onLoadingShowHide,
            funBlock = funBlock
        )
    }

    // this method only for Application level AppOpen Ad
    fun setApplicationLevelAppOpenAdListeners(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdShow: (() -> Unit)? = null,
        onAdClose: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        appOpenAdList[adConfigManager.name]?.setApplicationLevelAppOpenAdListeners(
            onAdShow = activity.listenerX { onAdShow?.invoke() },
            onAdClose = activity.listenerX { onAdClose?.invoke() },
            onAdImpression = activity.listenerX { onAdImpression?.invoke() },
            onAdClicked = activity.listenerX { onAdClicked?.invoke() },
            onLoadingShowHide = activity.listenerX { onLoadingShowHide?.invoke(it) },
            funBlock = activity.listenerX { funBlock?.invoke() },
        )
    }

    fun isAppOpenAdLoaded(adConfigManager: AdConfigManager): Boolean {
        val newAdConfigManager =
            appOpenAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        return isFullScreenAdWithTypeLoaded(newAdConfigManager)
    }

    fun destroyAppOpenAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            appOpenAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        destroyFullScreenAdWithType(newAdConfigManager)
    }

    fun getAd(adConfigManager: AdConfigManager): Any? {
        return when (adConfigManager.adConfig.adType) {
            NATIVE_AD -> nativeAdList[adConfigManager.name]?.mNativeAd
            BANNER_AD -> bannerAdList[adConfigManager.name]?.adView
            INTER_AD -> interAdList[adConfigManager.name]?.mInterstitialAd
            REWARDED_AD -> rewardedAdList[adConfigManager.name] //cant get ad
            REWARDED_INTERSTITIAL_AD -> rewardedInterstitialAdList[adConfigManager.name] //cant get ad
            else -> appOpenAdList[adConfigManager.name]?.mAppOpenAd
        }
    }


    fun reloadAppOpenAd(adConfigManager: AdConfigManager) {
        val newAdConfigManager =
            appOpenAdList[adConfigManager.name]?.getAdConfigManager() ?: adConfigManager
        reloadFullScreenAdWithType(newAdConfigManager)
    }


}