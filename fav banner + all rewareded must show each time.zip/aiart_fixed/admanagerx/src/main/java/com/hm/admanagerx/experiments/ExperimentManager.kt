package com.hm.admanagerx.experiments

import com.hm.admanagerx.AdConfigManager

data class ExperimentManager(
    val nativeRefreshAd: AdConfigManager,
    val bannerRefreshAd: AdConfigManager,
    val bannerNoRefreshAd: AdConfigManager,
    val nativeNoRefreshAd: AdConfigManager,
    val expHandler: AdConfigManager,
    val screenId: String
)