package com.hm.admanagerx

import android.app.Activity
import android.app.Application
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LifecycleOwner
import com.google.android.gms.ads.rewarded.RewardItem
import com.hm.admanagerx.adsanalysis.AdAnalyticsTracker
import java.util.concurrent.ConcurrentHashMap
import kotlin.collections.set

open class ParentAdsManagerX {

    protected lateinit var application: Application

    protected fun loadFullScreenAdWithTypeCheck(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)?,
        onAdFailed: ((String) -> Unit)?,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        val adConfig = adConfigManager.adConfig.fetchAdConfigFromRemote(adConfigManager.name)
        when (adConfig.adType) {
            INTER_AD -> loadInterAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdRequestDenied = onAdRequestDenied
            )

            REWARDED_AD -> loadRewardedAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdRequestDenied = onAdRequestDenied
            )

            REWARDED_INTERSTITIAL_AD -> loadRewardedInterstitialAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdRequestDenied = onAdRequestDenied
            )

            APP_OPEN_AD -> loadAppOpenAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdRequestDenied = onAdRequestDenied
            )
        }
    }

    protected fun loadInScreenAdWithTypeCheck(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        adContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
        activity: Activity? = null
    ) {
        val adConfig = adConfigManager.adConfig.fetchAdConfigFromRemote(adConfigManager.name)
        when (adConfig.adType) {
            BANNER_AD -> loadBannerAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                bannerAdContainer = adContainer,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onAdRequestDenied = onAdRequestDenied
            )

            COLLAPSIBLE_BANNER_AD -> loadCollapsibleBannerAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                bannerAdContainer = adContainer,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onAdRequestDenied = onAdRequestDenied, activity = activity
            )

            NATIVE_AD -> loadNativeAdX(
                lifecycleOwner = lifecycleOwner,
                adConfigManager = adConfigManager,
                nativeAdContainer = adContainer,
                onAdLoaded = onAdLoaded,
                onAdFailed = onAdFailed,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onAdRequestDenied = onAdRequestDenied
            )
        }
    }

    protected fun showFullScreenAdWithTypeCheck(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdShow: (() -> Unit)?,
        onAdClose: (() -> Unit)?,
        onAdClicked: (() -> Unit)?,
        onAdImpression: (() -> Unit)?,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,//only for rewarded ad
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlockForInter: ((AdCheckResult) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        val adType = adConfigManager.adConfig.adType

        when (adType) {
            INTER_AD -> showInterAdX(
                activity = activity,
                adConfigManager = adConfigManager,
                onAdShow = onAdShow,
                onAdClose = onAdClose,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onLoadingShowHide = onLoadingShowHide,
                funBlock = funBlockForInter
            )

            APP_OPEN_AD -> showAppOpenAdX(
                activity = activity,
                adConfigManager = adConfigManager,
                onAdShow = onAdShow,
                onAdClose = onAdClose,
                onAdImpression = onAdClicked,
                onAdClicked = onAdImpression,
                onLoadingShowHide = onLoadingShowHide,
                funBlock = funBlock
            )

            REWARDED_AD -> showRewardedAdX(
                activity = activity,
                adConfigManager = adConfigManager,
                onAdShow = onAdShow,
                onAdClose = onAdClose,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onUserEarnedRewarded = onUserEarnedRewarded,
                onLoadingShowHide = onLoadingShowHide,
                funBlock = funBlock
            )

            REWARDED_INTERSTITIAL_AD -> showRewardedInterstitialAdX(
                activity = activity,
                adConfigManager = adConfigManager,
                onAdShow = onAdShow,
                onAdClose = onAdClose,
                onAdClicked = onAdClicked,
                onAdImpression = onAdImpression,
                onUserEarnedRewarded = onUserEarnedRewarded,
                onLoadingShowHide = onLoadingShowHide,
                funBlock = funBlock
            )
        }
    }

    protected fun isFullScreenAdWithTypeLoaded(adConfigManager: AdConfigManager): Boolean {
        val adType = adConfigManager.adConfig.adType
        return when (adType) {
            INTER_AD -> interAdList[adConfigManager.name]?.isAdLoaded() ?: false
            REWARDED_AD -> rewardedAdList[adConfigManager.name]?.isAdLoaded() ?: false
            REWARDED_INTERSTITIAL_AD -> rewardedInterstitialAdList[adConfigManager.name]?.isAdLoaded()
                ?: false

            APP_OPEN_AD -> appOpenAdList[adConfigManager.name]?.isAdLoaded() ?: false
            else -> false
        }
    }

    protected fun destroyFullScreenAdWithType(adConfigManager: AdConfigManager) {
        val adType = adConfigManager.adConfig.adType
        when (adType) {
            INTER_AD -> destroyInterAdX(adConfigManager)
            APP_OPEN_AD -> destroyAppOpenAdX(adConfigManager)
            REWARDED_AD -> destroyRewardedAdX(adConfigManager)
            REWARDED_INTERSTITIAL_AD -> destroyRewardedInterstitialAdX(adConfigManager)
        }
    }

    protected fun reloadFullScreenAdWithType(adConfigManager: AdConfigManager) {
        val adType = adConfigManager.adConfig.adType
        when (adType) {
            INTER_AD -> reloadInterAdX(adConfigManager)
            APP_OPEN_AD -> reloadAppOpenAdX(adConfigManager)
            REWARDED_AD -> reloadRewardedAdX(adConfigManager)
            REWARDED_INTERSTITIAL_AD -> reloadRewardedInterstitialAdX(adConfigManager)
        }
    }


    /** ----- Inter Ad --------**/
    protected val interAdList: ConcurrentHashMap<String, InterAdLoaderX?> = ConcurrentHashMap()


    protected fun loadInterAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {

            val adConfig = adConfigManager.adConfig

            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                ("${adConfigManager.name}_${adConfigManager.adConfig.adType} " + AdCheckResult.AdsDisabled).printIt()
                return@listenerX
            }

            var interAdLoaderX = interAdList[adConfigManager.name]
            if (interAdLoaderX == null) interAdLoaderX = InterAdLoaderX(application)

            interAdLoaderX.loadInterAdX(
                adConfigManager = adConfigManager,
                onAdLoaded = lifecycleOwner.listenerX { onAdLoaded?.invoke() },
                onAdFailed = lifecycleOwner.listenerX { onAdFailed?.invoke(it) },
                onAdRequestDenied = lifecycleOwner.listenerX { onAdRequestDenied?.invoke() },
            )
            interAdList[adConfigManager.name] = interAdLoaderX
        })

    }

    protected fun showInterAdX(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: ((AdCheckResult) -> Unit)? = null,
    ) {

        interAdList[adConfigManager.name]?.showAd(
            activity = activity,
            onAdClose = activity.listenerX { onAdClose?.invoke() },
            onAdShow = activity.listenerX { onAdShow?.invoke() },
            onAdClicked = activity.listenerX { onAdClicked?.invoke() },
            onAdImpression = activity.listenerX { onAdImpression?.invoke() },
            onLoadingShowHide = activity.listenerX { onLoadingShowHide?.invoke(it) },
            funBlock = activity.listenerX { funBlock?.invoke(it) }
        ) ?: run {
            funBlock?.invoke(AdCheckResult.None)
        }
    }


    protected fun destroyInterAdX(adConfigManager: AdConfigManager) =
        interAdList.remove(adConfigManager.name)

    protected fun reloadInterAdX(adConfigManager: AdConfigManager) =
        interAdList[adConfigManager.name]?.reloadAd()

    /** ----- Native Ad --------**/

    protected val nativeAdList: ConcurrentHashMap<String, NativeAdLoaderX?> = ConcurrentHashMap()


    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    protected fun loadNativeAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        nativeAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {

        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {
            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }

            var nativeAdLoaderX = nativeAdList[adConfigManager.name]

            // clear ad container (FrameLayout) on activity destroy to avoid memory leak
            clearAdContainer(nativeAdContainer, lifecycleOwner)

            if (nativeAdLoaderX == null) nativeAdLoaderX = NativeAdLoaderX(application)

            // Show loading before ad
            if (!application.adCheckShow(adConfig) && nativeAdContainer != null && adConfig.isShowLoadingBeforeAd &&
                !nativeAdLoaderX.isAdImpression
            ) application.showAdLoadingShimmerView(nativeAdContainer, adConfig.nativeAdLayout)

            nativeAdLoaderX.loadNativeAdX(
                adConfigManager = adConfigManager,
                onAdLoaded = lifecycleOwner.listenerX {
                    onAdLoaded?.invoke()
                    nativeAdLoaderX.showNativeAd(nativeAdContainer)
                },
                onAdFailed = lifecycleOwner.listenerX {
                    nativeAdContainer?.removeAllViews()
                    onAdFailed?.invoke(it)
                },
                onAdClicked = lifecycleOwner.listenerX { onAdClicked?.invoke() },
                onAdImpression = lifecycleOwner.listenerX {
                    onAdImpression?.invoke()
                    if (adConfig.isAdLoadAgain) nativeAdLoaderX.reloadAd()
                },
                onAdRequestDenied = lifecycleOwner.listenerX {
                    nativeAdContainer?.removeAllViews()
                    onAdRequestDenied?.invoke()
                }
            )

            nativeAdList[adConfigManager.name] = nativeAdLoaderX
        })
    }


    protected fun showNativeAdX(adConfigManager: AdConfigManager, nativeAdContainer: FrameLayout?) {
        nativeAdList[adConfigManager.name]?.showNativeAd(nativeAdContainer)
    }


    protected fun destroyNativeAdX(adConfigManager: AdConfigManager) {
        nativeAdList[adConfigManager.name]?.destroyNative()
        nativeAdList.remove(adConfigManager.name)
    }


    /** ----- Banner Ad --------**/

    protected val bannerAdList: ConcurrentHashMap<String, BannerAdsLoaderX?> = ConcurrentHashMap()

    /** ----- Collapsible Banner Ad --------**/

    protected val collapsibleBannerAdList: ConcurrentHashMap<String, CollapsibleBannerAdsLoaderX?> =
        ConcurrentHashMap()


    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    protected fun loadBannerAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,

        ) {

        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {
            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }
            // clear ad container (FrameLayout) on activity destroy to avoid memory leak
            clearAdContainer(bannerAdContainer, lifecycleOwner)
            // Show loading before ad
            if (!application.adCheckShow(adConfig) && bannerAdContainer != null && adConfig.isShowLoadingBeforeAd)
                application.showAdLoadingShimmerView(
                    bannerAdContainer,
                    adConfig.bannerAdLoadingLayout
                )

            var bannerAdsLoaderX = bannerAdList[adConfigManager.name]

            if (bannerAdsLoaderX == null) bannerAdsLoaderX = BannerAdsLoaderX(application)

            var bannerAdSize = adConfig.bannerAdSize
            if (bannerAdSize == null) bannerAdSize =
                application.getAdaptiveAdSize(bannerAdContainer?.width ?: 0)

            bannerAdsLoaderX.loadBannerAdX(
                adConfigManager = adConfigManager,
                adSize = bannerAdSize,
                onAdLoaded = lifecycleOwner.listenerX {
                    bannerAdsLoaderX.showBannerAd(bannerAdContainer)
                    onAdLoaded?.invoke()
                },
                onAdFailed = lifecycleOwner.listenerX {
                    bannerAdContainer?.removeAllViews()
                    onAdFailed?.invoke(it)
                },
                onAdClicked = lifecycleOwner.listenerX { onAdClicked?.invoke() },
                onAdImpression = lifecycleOwner.listenerX { onAdImpression?.invoke() },
                onAdRequestDenied = lifecycleOwner.listenerX {
                    bannerAdContainer?.removeAllViews()
                    onAdRequestDenied?.invoke()
                }
            )
            bannerAdList[adConfigManager.name] = bannerAdsLoaderX
        })
    }


    protected fun showBannerAdX(adConfigManager: AdConfigManager, bannerAdContainer: FrameLayout?) {
        bannerAdList[adConfigManager.name]?.showBannerAd(bannerAdContainer)
    }

    protected fun destroyBannerX(adConfigManager: AdConfigManager) {
        bannerAdList[adConfigManager.name]?.destroyAd()
        bannerAdList.remove(adConfigManager.name)
    }

    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    protected fun loadCollapsibleBannerAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
        activity:  Activity? = null
    ) {

        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {
            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }
            // clear ad container (FrameLayout) on activity destroy to avoid memory leak
            clearAdContainer(bannerAdContainer, lifecycleOwner)
            // Show loading before ad
            if (!application.adCheckShow(adConfig) && bannerAdContainer != null && adConfig.isShowLoadingBeforeAd)
                application.showAdLoadingShimmerView(
                    bannerAdContainer,
                    adConfig.bannerAdLoadingLayout
                )

            var collapsibleBannerAdsLoaderX = collapsibleBannerAdList[adConfigManager.name]

            if (collapsibleBannerAdsLoaderX == null) collapsibleBannerAdsLoaderX =
                CollapsibleBannerAdsLoaderX(activity)

            var bannerAdSize = adConfig.bannerAdSize
            if (bannerAdSize == null) bannerAdSize = bannerAdContainer?.getAdaptiveAdSize()

            collapsibleBannerAdsLoaderX.loadCollapsibleBannerAdX(
                bannerAdContainer = bannerAdContainer,
                adConfigManager = adConfigManager,
                adSize = bannerAdSize,
                onAdLoaded = lifecycleOwner.listenerX {
                    collapsibleBannerAdsLoaderX.showCollapsibleBannerAd(bannerAdContainer)
                    onAdLoaded?.invoke()
                },
                onAdFailed = lifecycleOwner.listenerX {
                    bannerAdContainer?.removeAllViews()
                    onAdFailed?.invoke(it)
                },
                onAdClicked = lifecycleOwner.listenerX { onAdClicked?.invoke() },
                onAdImpression = lifecycleOwner.listenerX { onAdImpression?.invoke() },
                onAdRequestDenied = lifecycleOwner.listenerX {
                    bannerAdContainer?.removeAllViews()
                    onAdRequestDenied?.invoke()
                }
            )
            collapsibleBannerAdList[adConfigManager.name] = collapsibleBannerAdsLoaderX
        })
    }

    protected fun showCollapsibleBannerAdX(
        adConfigManager: AdConfigManager,
        bannerAdContainer: FrameLayout?
    ) {
        collapsibleBannerAdList[adConfigManager.name]?.showCollapsibleBannerAd(bannerAdContainer)
    }

    protected fun destroyCollapsibleBannerX(adConfigManager: AdConfigManager) {
        collapsibleBannerAdList[adConfigManager.name]?.destroyAd()
        collapsibleBannerAdList.remove(adConfigManager.name)
    }

    /** ----- Rewarded Ad --------**/

    protected val rewardedAdList: ConcurrentHashMap<String, RewardedAdLoaderX?> =
        ConcurrentHashMap()


    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    protected fun loadRewardedAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {
            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }

            var rewardedAdLoaderX = rewardedAdList[adConfigManager.name]

            if (rewardedAdLoaderX == null) rewardedAdLoaderX = RewardedAdLoaderX(application)

            rewardedAdLoaderX.loadRewardedAdX(
                adConfigManager = adConfigManager,
                onAdLoaded = lifecycleOwner.listenerX { onAdLoaded?.invoke() },
                onAdFailed = lifecycleOwner.listenerX { onAdFailed?.invoke(it) },
                onAdRequestDenied = lifecycleOwner.listenerX { onAdRequestDenied?.invoke() },
            )
            rewardedAdList[adConfigManager.name] = rewardedAdLoaderX
        })
    }

    protected fun showRewardedAdX(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        rewardedAdList[adConfigManager.name]?.showAd(
            activity = activity,
            onAdClose = activity.listenerX { onAdClose?.invoke() },
            onAdShow = activity.listenerX { onAdShow?.invoke() },
            onAdClicked = activity.listenerX { onAdClicked?.invoke() },
            onAdImpression = activity.listenerX { onAdImpression?.invoke() },
            onUserEarnedRewarded = activity.listenerX { onUserEarnedRewarded?.invoke(it) },
            onLoadingShowHide = activity.listenerX { onLoadingShowHide?.invoke(it) },
            funBlock = activity.listenerX { funBlock?.invoke() }
        ) ?: run { funBlock?.invoke() }
    }


    protected fun destroyRewardedAdX(adConfigManager: AdConfigManager) =
        rewardedAdList.remove(adConfigManager.name)

    protected fun reloadRewardedAdX(adConfigManager: AdConfigManager) =
        rewardedAdList[adConfigManager.name]?.reloadAd()

    /** ----- Rewarded Interstitial Ad --------**/

    protected val rewardedInterstitialAdList: ConcurrentHashMap<String, RewardedInterstitialAdLoaderX?> =
        ConcurrentHashMap()


    /**
     * lifecycleOwner : use for set listenerX (LiveData Observer) callback or  get Activity / Fragment lifecycle methods
     */
    protected fun loadRewardedInterstitialAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {
            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }

            var rewardedInterstitialAdLoaderX = rewardedInterstitialAdList[adConfigManager.name]

            if (rewardedInterstitialAdLoaderX == null) rewardedInterstitialAdLoaderX =
                RewardedInterstitialAdLoaderX(application)

            rewardedInterstitialAdLoaderX.loadRewardedInterstitialAdX(
                adConfigManager = adConfigManager,
                onAdLoaded = lifecycleOwner.listenerX { onAdLoaded?.invoke() },
                onAdFailed = lifecycleOwner.listenerX { onAdFailed?.invoke(it) },
                onAdRequestDenied = lifecycleOwner.listenerX { onAdRequestDenied?.invoke() },
            )
            rewardedInterstitialAdList[adConfigManager.name] = rewardedInterstitialAdLoaderX
        })
    }

    protected fun showRewardedInterstitialAdX(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdClose: (() -> Unit)? = null,
        onAdShow: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onUserEarnedRewarded: ((RewardItem) -> Unit)? = null,
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        rewardedInterstitialAdList[adConfigManager.name]?.showAd(
            activity = activity,
            onAdClose = activity.listenerX { onAdClose?.invoke() },
            onAdShow = activity.listenerX { onAdShow?.invoke() },
            onAdClicked = activity.listenerX { onAdClicked?.invoke() },
            onAdImpression = activity.listenerX { onAdImpression?.invoke() },
            onUserEarnedRewarded = activity.listenerX { onUserEarnedRewarded?.invoke(it) },
            onLoadingShowHide = activity.listenerX { onLoadingShowHide?.invoke(it) },
            funBlock = activity.listenerX { funBlock?.invoke() }
        ) ?: run { funBlock?.invoke() }
    }


    protected fun destroyRewardedInterstitialAdX(adConfigManager: AdConfigManager) =
        rewardedInterstitialAdList.remove(adConfigManager.name)

    protected fun reloadRewardedInterstitialAdX(adConfigManager: AdConfigManager) =
        rewardedInterstitialAdList[adConfigManager.name]?.reloadAd()


    protected val appOpenAdList: ConcurrentHashMap<String, AppOpenAdX?> = ConcurrentHashMap()

    /** ----- AppOpen Ad --------**/


    protected fun loadAppOpenAdX(
        lifecycleOwner: LifecycleOwner,
        adConfigManager: AdConfigManager,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null,
        onAdRequestDenied: (() -> Unit)? = null,
    ) {
        checkMobileAdsInit(adConfigManager, lifecycleOwner.listenerX {

            val adConfig = adConfigManager.adConfig
            if (!adConfig.isAdShow) {
                onAdRequestDenied?.invoke()
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} ${AdCheckResult.AdsDisabled}".printIt()
                return@listenerX
            }

            var appOpenAdX = appOpenAdList[adConfigManager.name]

            if (appOpenAdX == null) appOpenAdX = AppOpenAdX(application)

            appOpenAdList[adConfigManager.name] = appOpenAdX
            appOpenAdX.loadAppOpenAdX(
                adConfigManager = adConfigManager,
                onAdLoaded = lifecycleOwner.listenerX { onAdLoaded?.invoke() },
                onAdFailed = lifecycleOwner.listenerX { onAdFailed?.invoke(it) },
                onAdRequestDenied = lifecycleOwner.listenerX { onAdRequestDenied?.invoke() })
        })

    }


    protected fun showAppOpenAdX(
        activity: AppCompatActivity,
        adConfigManager: AdConfigManager,
        onAdShow: (() -> Unit)? = null,
        onAdClose: (() -> Unit)? = null,
        onAdImpression: (() -> Unit)? = null,
        onAdClicked: (() -> Unit)? = null,
        onLoadingShowHide: ((Boolean) -> Unit)? = null,
        funBlock: (() -> Unit)? = null,
    ) {
        appOpenAdList[adConfigManager.name]?.showAd(
            activity,
            onAdShow = activity.listenerX { onAdShow?.invoke() },
            onAdClose = activity.listenerX { onAdClose?.invoke() },
            onAdImpression = activity.listenerX { onAdImpression?.invoke() },
            onAdClicked = activity.listenerX { onAdClicked?.invoke() },
            onLoadingShowHide = activity.listenerX { onLoadingShowHide?.invoke(it) },
            funBlock = activity.listenerX { funBlock?.invoke() },
        ) ?: run { funBlock?.invoke() }
    }


    protected fun destroyAppOpenAdX(adConfigManager: AdConfigManager) {
        appOpenAdList[adConfigManager.name]?.destroyAd()
        appOpenAdList.remove(adConfigManager.name)
    }


    protected fun reloadAppOpenAdX(adConfigManager: AdConfigManager) =
        appOpenAdList[adConfigManager.name]?.reloadAd()


    /** ----- Ad destroy functions--------**/
    fun destroyAllAds() {
        destroyAllNativeAds()
        destroyAllBannerAds()
        destroyAllCollapsibleBannerAds()
        destroyAllInterAds()
        destroyAllRewardedAds()
        destroyAllRewardedInterstitialAds()
        destroyAllAppOpenAd()
    }

    fun destroyAllRewardedAds() = rewardedAdList.clear()

    fun destroyAllRewardedInterstitialAds() = rewardedInterstitialAdList.clear()

    fun destroyAllInterAds() = interAdList.clear()

    fun destroyAllBannerAds() {
        bannerAdList.apply {
            forEach { it.value?.destroyAd() }
            clear()
        }
    }

    fun destroyAllCollapsibleBannerAds() {
        collapsibleBannerAdList.apply {
            forEach { it.value?.destroyAd() }
            clear()
        }
    }

    fun destroyAllAppOpenAd() {
        appOpenAdList.apply {
            forEach { it.value?.destroyAd() }
            clear()
        }
    }

    fun destroyAllNativeAds() {
        nativeAdList.apply {
            forEach { it.value?.destroyNative() }
            clear()
        }
    }

    /** ----- Ad analysis functions--------**/

//TODO pending functionality

    fun bannerAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        bannerAdList[adConfigManager.name]?.adAnalyticsTracker

    fun collapsibleBannerAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        collapsibleBannerAdList[adConfigManager.name]?.adAnalyticsTracker

    fun nativeAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        nativeAdList[adConfigManager.name]?.adAnalyticsTracker

    fun interAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        interAdList[adConfigManager.name]?.adAnalyticsTracker

    fun rewardedAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        rewardedAdList[adConfigManager.name]?.adAnalyticsTracker

    fun rewardedInterstitialAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
        rewardedInterstitialAdList[adConfigManager.name]?.adAnalyticsTracker

//    fun appOpenAdAnalysis(adConfigManager: AdConfigManager): AdAnalyticsTracker? =
//        appOpenAdList[adConfigManager.name]?.adAnalyticsTracker

    protected val adsAnalyticsTrackerList: ArrayList<AdAnalyticsTracker> = ArrayList()

    fun getAllAdsAnalysis() = adsAnalyticsTrackerList.apply {
        adsAnalyticsTrackerList.clear()
        addAll(bannerAdList.mapNotNull { it.value?.adAnalyticsTracker })
        addAll(collapsibleBannerAdList.mapNotNull { it.value?.adAnalyticsTracker })
        addAll(nativeAdList.mapNotNull { it.value?.adAnalyticsTracker })
        addAll(interAdList.mapNotNull { it.value?.adAnalyticsTracker })
        addAll(rewardedAdList.mapNotNull { it.value?.adAnalyticsTracker })
        addAll(rewardedInterstitialAdList.mapNotNull { it.value?.adAnalyticsTracker })
//        addAll(appOpenAdList.mapNotNull { it.value?.adAnalyticsTracker })
    }

    fun printAdsAnalyticsTrackerReport() = getAllAdsAnalysis().forEach { it.toString().printIt() }


}
