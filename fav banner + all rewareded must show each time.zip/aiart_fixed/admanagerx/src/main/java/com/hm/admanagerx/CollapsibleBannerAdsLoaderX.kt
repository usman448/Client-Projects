package com.hm.admanagerx

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.isVisible
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.ads.mediation.admob.AdMobAdapter
import com.hm.admanagerx.adsanalysis.AdAnalyticsTracker

/**
 * Collapsible Banner Ad Loader
 *
 * Note: Collapsible banners start in a collapsed state and can expand when clicked.
 * They are useful for reducing initial ad space while still showing ads.
 *
 * Important: Collapsible banners should use Activity context, not Application context,
 * as they need to expand properly.
 */
class CollapsibleBannerAdsLoaderX(private var context: Activity?) {

    private var TAG = "CollapsibleBannerAdsLoaderX"

    private lateinit var mAdConfigManager: AdConfigManager
    private lateinit var adConfig: AdConfig

    var adView: AdView? = null

    var isAdLoaded: Boolean = false
    var isAdImpression: Boolean = false

    var onAdLoaded: MutableLiveData<AdView>? = null
    var onAdFailed: MutableLiveData<String>? = null
    var onAdClicked: MutableLiveData<Unit>? = null
    var onAdImpression: MutableLiveData<Unit>? = null
    var onAdRequestDenied: MutableLiveData<Unit>? = null
    var adSize: AdSize? = null

    fun getAdConfigManager() = mAdConfigManager

    val adAnalyticsTracker: AdAnalyticsTracker by lazy { AdAnalyticsTracker(mAdConfigManager.name) }

    fun loadCollapsibleBannerAdX(
        bannerAdContainer: FrameLayout?,
        adConfigManager: AdConfigManager,
        adSize: AdSize?,
        onAdLoaded: MutableLiveData<AdView>? = null,
        onAdFailed: MutableLiveData<String>? = null,
        onAdClicked: MutableLiveData<Unit>? = null,
        onAdImpression: MutableLiveData<Unit>? = null,
        onAdRequestDenied: MutableLiveData<Unit>? = null,
    ) {

        context?.let { cont ->

            bannerAdContainer?.removeAllViews()
            this.mAdConfigManager = adConfigManager
            this.adConfig = adConfigManager.adConfig

            this.onAdLoaded = onAdLoaded
            this.onAdFailed = onAdFailed
            this.onAdClicked = onAdClicked
            this.onAdImpression = onAdImpression
            this.onAdRequestDenied = onAdRequestDenied

            this.adSize = adSize

            val adCheckResult = checkCollapsibleBannerAdLoad(cont)
            if (adCheckResult != AdCheckResult.ReadyToGo) {
                onAdRequestDenied?.value = Unit
                "${adConfigManager.name}_${adConfigManager.adConfig.adType} $adCheckResult".printIt(
                    TAG
                )
                return
            }

            //if ad already loaded and not impression then trigger onAdLoaded for show ad and return
            if (isAdLoaded) {
                if (isAdImpression) {
                    onAdLoaded?.value = adView
                } else {
                    onAdLoaded?.value = adView
                    return
                }
            }

            isAdImpression = false
            isAdLoaded = false

            "${mAdConfigManager.name}_${adConfigManager.adConfig.adType} Ad loaded request".printIt(
                TAG
            )
            cont?.sendLogs("${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_request")

            adAnalyticsTracker.trackAdRequest()

            adView = AdView(cont)
            bannerAdContainer?.getAdaptiveAdSize()?.let { adView?.setAdSize(it) }
            adView?.adUnitId = cont.getAdId(adConfig.adId)

            // Create collapsible banner ad request based on position
            val adRequest = createCollapsibleAdRequest(adConfig.collapsiblePosition)

            adView?.loadAd(adRequest)

            adView?.adListener = object : AdListener() {

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    isAdLoaded = true
                    this@CollapsibleBannerAdsLoaderX.onAdLoaded?.value = adView
                    "${mAdConfigManager.name}_${adConfigManager.adConfig.adType} Ad loaded".printIt(
                        TAG
                    )
                    cont.sendLogs("${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_loaded")
                    adAnalyticsTracker.trackAdLoaded()
                }

                override fun onAdFailedToLoad(p0: LoadAdError) {
                    super.onAdFailedToLoad(p0)
                    isAdLoaded = false
                    this@CollapsibleBannerAdsLoaderX.onAdFailed?.value = p0.message
                    "${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_Ad failed ${p0.message}".printIt(
                        TAG
                    )
                    cont.sendLogs("${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_failed")
                    adAnalyticsTracker.trackAdLoadFailed()
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    this@CollapsibleBannerAdsLoaderX.onAdClicked?.value = Unit
                    "${mAdConfigManager.name}_${adConfigManager.adConfig.adType} onAdClicked".printIt(
                        TAG
                    )
                    cont.sendLogs("${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_clicked")
                    adAnalyticsTracker.trackAdClicked()
                }

                override fun onAdImpression() {
                    super.onAdImpression()
                    this@CollapsibleBannerAdsLoaderX.onAdImpression?.value = Unit
                    "${mAdConfigManager.name}_${adConfigManager.adConfig.adType} Ad Impression".printIt(
                        TAG
                    )
                    cont.sendLogs("${mAdConfigManager.name}_${adConfigManager.adConfig.adType}_impression")
                    isAdImpression = true
                    adAnalyticsTracker.trackAdImpression()
                }
            }
        }

    }

    /**
     * Create AdRequest with collapsible banner configuration
     * @param position The collapsible position (TOP, BOTTOM, or NONE)
     * @return AdRequest with collapsible configuration if position is specified
     */
    private fun createCollapsibleAdRequest(position: CollapsiblePosition?): AdRequest {
        return when (position) {
            CollapsiblePosition.TOP -> {
                val extras = Bundle()
                extras.putString("collapsible", "top")

                AdRequest.Builder()
                    .addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
                    .build()
            }

            CollapsiblePosition.BOTTOM -> {
                val extras = Bundle()
                extras.putString("collapsible", "bottom")
                AdRequest.Builder()
                    .addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
                    .build()
            }

            CollapsiblePosition.NONE, null -> {
                AdRequest.Builder().build()
            }
        }
    }

    fun isAdLoading() = adView?.isLoading ?: false

    fun destroyAd() = adView?.destroy()

    fun showCollapsibleBannerAd(bannerAdContainer: FrameLayout?) {

        context?.let {
            if (checkCollapsibleBannerAdLoad(it) != AdCheckResult.ReadyToGo) {
                bannerAdContainer?.removeAllViews()
                return
            }
        }
        if (adView == null) return

        val params = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        //when ad is loaded already
        bannerAdContainer?.removeAllViews()
        adView?.parent?.let { (it as? ViewGroup)?.removeView(adView) }
        bannerAdContainer?.addView(adView, params)
        bannerAdContainer?.isVisible = true
        adAnalyticsTracker.trackAdShow()
    }

    private fun checkCollapsibleBannerAdLoad(context: Activity): AdCheckResult {

        return when {
            !context.isOnline() -> AdCheckResult.Offline
            context.isPremium() -> AdCheckResult.PremiumUser
            !adConfig.isAdShow -> AdCheckResult.AdsDisabled
            isAdLoading() -> AdCheckResult.AdLoading
            else -> AdCheckResult.ReadyToGo
        }


    }
}

