package com.nined.fcm.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.nined.fcm.BuildConfig
import com.nined.fcm.R
import com.squareup.picasso.Picasso
import java.util.concurrent.atomic.AtomicInteger


open class FcmFireBaseMessagingService : FirebaseMessagingService() {

    companion object {
        val ICON_KEY = "icon"
        val APP_TITLE_KEY = "title"
        val SHORT_DESC_KEY = "short_desc"
        val LONG_DESC_KEY = "long_desc"
        val APP_FEATURE_KEY = "feature"
        val APP_URL_KEY = "app_url"
        private const val RELEASE_TOPIC = "arti_craft_ai"
        private const val DEBUG_TOPIC = "test_app"
        const val IS_PREMIUM = "is_premium"

        var destinationIntent: Intent? = null

        private val seed = AtomicInteger()

        fun getNextInt(): Int {
            return seed.incrementAndGet()
        }

        fun specifyDestinationClass(context: Context, activityName: Class<*>) {
            try {
                val intent: Intent = Intent(context, activityName)
                destinationIntent = intent
            } catch (ignored: ClassNotFoundException) {
                Log.e("TAG", "ClassNotFoundException: ")
            } catch (ex: Exception) {
                Log.e("TAG", "ClassNotFoundException: ")
            }
        }


        fun subscribeToTopic(): Boolean {
            try {
                if (BuildConfig.DEBUG)
                    FirebaseMessaging.getInstance().subscribeToTopic(DEBUG_TOPIC)
                else {
                    FirebaseMessaging.getInstance().subscribeToTopic(RELEASE_TOPIC)
                    FirebaseMessaging.getInstance().unsubscribeFromTopic(DEBUG_TOPIC)
                }
                return true
            } catch (e: Exception) {
                Log.e("FirebaseMessaging", e.toString())
                return false
            }
        }
    }


    override fun onNewToken(p0: String) {
        subscribeToTopic()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data: Map<String, String>? = remoteMessage.data

        data?.let {
            val iconURL = data[ICON_KEY]
            val title = data[APP_TITLE_KEY]
            val shortDesc = data[SHORT_DESC_KEY]
            val longDesc = data[LONG_DESC_KEY]
            val feature = data[APP_FEATURE_KEY]
            val appURL = data[APP_URL_KEY]
            val notificationID = getNextInt()

            if (title != null && shortDesc != null) {
                try {
                    /*appURL?.let {
                        val standard = "https://play.google.com/store/apps/details?id="
                        val id = appURL.substring(standard.length)
                        if (BuildConfig.DEBUG) Log.e("package sent ", id)

                        if (!isAppInstalled(
                                id,
                                this
                            )
                        ) {
                            Handler(this.mainLooper).post {
                                customAppUpdateNotification(
                                    iconURL,
                                    title, shortDesc, longDesc,
                                    feature, appURL, notificationID
                                )
                            }
                        }
                    } ?: run {
                        Handler(this.mainLooper).post {
                            customAppUpdateNotification(
                                iconURL,
                                title, shortDesc, longDesc,
                                feature, null, notificationID
                            )
                        }
                    }*/
                    Handler(this.mainLooper).post {
                        customAppUpdateNotification(
                            iconURL,
                            title, shortDesc, longDesc,
                            feature, appURL, notificationID
                        )
                    }
                } catch (e: Exception) {
                    if (BuildConfig.DEBUG) Log.e("FcmFireBase", "package not valid")
                }
            }

        }

        if (remoteMessage.notification != null) {
//            if (BuildConfig.DEBUG)
//                remoteMessage.notification?.body?.let {
//                Log.e(
//                    "Message  Body:",
//                    it
//                )
//            }
        }
    }

    private fun getLauncherActivityIntent(): Intent? {
        val intent = this.packageManager.getLaunchIntentForPackage(this.packageName)
        return intent
    }

    private fun customAppUpdateNotification(
        iconURL: String?, title: String, shortDesc: String, longDesc: String?,
        feature: String?, appURL: String?, notificationID: Int,
    ) {

        val flagsX = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        if (destinationIntent == null)
            destinationIntent = getLauncherActivityIntent()

        destinationIntent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)

        val pendingIntent =
            PendingIntent.getActivity(this, notificationID, destinationIntent, flagsX)


        val remoteViews = RemoteViews(packageName, R.layout.notification_app)

        remoteViews.setTextViewText(R.id.tv_title, title)
        remoteViews.setTextViewText(R.id.tv_short_desc, shortDesc)
        remoteViews.setTextViewText(R.id.tv_long_desc, longDesc)

        remoteViews.setViewVisibility(
            R.id.tv_long_desc,
            if (!longDesc.isNullOrEmpty()) View.VISIBLE else View.GONE
        )

        remoteViews.setViewVisibility(
            R.id.iv_feature,
            if (!feature.isNullOrEmpty()) View.VISIBLE else View.GONE
        )

        remoteViews.setViewVisibility(
            R.id.iv_icon,
            if (!iconURL.isNullOrEmpty()) View.VISIBLE else View.GONE
        )

        val builder = NotificationCompat.Builder(this, title)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .setSmallIcon(R.drawable.ic_ad_small)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOnlyAlertOnce(true)
            .setCustomContentView(remoteViews)
            .setCustomBigContentView(remoteViews)
            .setAutoCancel(true)

        val mNotificationManager =
            getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                title,
                "Channel human readable title",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            mNotificationManager.createNotificationChannel(channel)
        }

        mNotificationManager.notify(notificationID, builder.build())

        iconURL?.let {
            if (iconURL.isNotEmpty())
                Picasso.get()
                    .load(iconURL)
                    .into(remoteViews, R.id.iv_icon, notificationID, builder.build())

        }

        feature?.let {
            if (feature.isNotEmpty())
                Picasso.get()
                    .load(feature)
                    .into(remoteViews, R.id.iv_feature, notificationID, builder.build())
        }
    }

    private fun isAppInstalled(uri: String, context: Context): Boolean {
        val pm = context.packageManager
        return try {
            val applicationInfo = pm.getApplicationInfo(uri, 0)
            //            packageInfo
            applicationInfo.enabled
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }

    }
}